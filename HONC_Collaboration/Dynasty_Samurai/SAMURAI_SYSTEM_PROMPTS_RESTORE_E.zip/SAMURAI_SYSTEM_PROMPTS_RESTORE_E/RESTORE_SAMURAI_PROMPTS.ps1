$ErrorActionPreference = "Stop"

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$GeminiHome = "C:\Users\VAL\.gemini"
$RuntimeRoot = "E:\Gemini"
$Doctrine = "E:\Gemini\SAMURAI\doctrine"

New-Item -ItemType Directory -Force -Path $GeminiHome | Out-Null
New-Item -ItemType Directory -Force -Path $RuntimeRoot | Out-Null
New-Item -ItemType Directory -Force -Path $Doctrine | Out-Null

Copy-Item -Force "$Here\C_Users_VAL_.gemini\GEMINI.md" "$GeminiHome\GEMINI.md"
Copy-Item -Force "$Here\E_Gemini\System_Prompt.md" "$RuntimeRoot\System_Prompt.md"
Copy-Item -Force "$Here\E_Gemini\SAMURAI\doctrine\CODING_PHILOSOPHY.md" "$Doctrine\CODING_PHILOSOPHY.md"

Write-Host ""
Write-Host "RESTORED:"
Write-Host "  C:\Users\VAL\.gemini\GEMINI.md"
Write-Host "  E:\Gemini\System_Prompt.md"
Write-Host "  E:\Gemini\SAMURAI\doctrine\CODING_PHILOSOPHY.md"
Write-Host ""
Write-Host "NOT INSTALLED: legacy SAMURAI_RUNTIME_REMINDER.md"
Write-Host "NOT RESTORED: project-local Current_Prompt / STEP / SPEC"
