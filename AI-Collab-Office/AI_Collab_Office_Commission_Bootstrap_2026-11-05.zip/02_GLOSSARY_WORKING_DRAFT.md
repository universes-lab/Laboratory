# Unified AI-Collab Glossary — Integrator working draft v0.1

**CREATED_AT:** 2026-11-05T18:26:17+01:00  
**FROM:** Chief Integrator / Methodologist  
**TO:** Doctor; Ontology Keeper; Chief Prompter; Claude Developer  
**STATUS:** WORKING / NOT CANON / AWAITING KEEPER SOURCE REVIEW & DOCTOR CLINICAL PACKET

The definitions below are **candidate integrated meanings**, not claims that all historical contracts already use them. The primary collision `OCCUPANT` is intentionally unresolved for legacy compatibility. Sources available for this initial draft: Author/Doctor instructions in the 2026-11-05 exchange; `HONC_Collaboration/ZOV_FINE_TUNING_WORKING_INSTRUCTION.md`; `CHARTERS.md`; `DOCTOR_AI_BIRTH_REGISTRY.md`; `DOCTOR_AUTUMN_DYNASTIC_MATERNITY_WARD_CHRONICLE_2026-11-01.md`; Claude's `CLAUDE_ARCHITECTURAL_CONCLUSION_ON_PIVOT_V1_1.md`. Further source audit is delegated to Doctor and Keeper.

| TERM | WORKING MEANING | SOURCE/STATUS | OPEN ISSUE |
|---|---|---|---|
| PROVIDER | Service/operator offering access to AI models | Inferred for schema; working | distinguish platform/account |
| MODEL | Identifiable model family/version used by an executor | Working | displayed label vs verified backend |
| OFFICE | Continuing professional post independent of its occupant | Doctor/Chronicle; candidate norm | none material |
| ROLE | Professional function/competence with defined responsibilities | CHARTERS; candidate | distinguish Office vs function |
| OCCUPANT | Specific AI executor currently occupying an Office | Doctor proposal; candidate norm | **COLLISION:** legacy v0.4 = provider + conversation identity |
| CHAT | Conversation/session environment in which executor works | Doctor proposal; candidate | not necessarily one transport handle |
| DYNASTY | Chronological chain of Office occupants linked by explicit succession events | Doctor registry; candidate | no identity continuity implied |
| TRIAD | Named, governed collaboration group of multiple role-holders | Author directive; candidate | membership may change, not always three |
| CURRENT_WORK_STATE | State of concrete project activity distinct from occupant's life/Office | Doctor/Chronicle; candidate | freeze vs blocked |
| ZOV | Boundary of professionally relevant visibility and context | ZOV working instruction §6; supported | content classes/access |
| ZOR | Boundary of responsibility and legitimate professional judgment/action | ZOV working instruction §6; supported | separate authority to execute |
| METSUKE | Actual current place/behaviour within ZOV/ZOR; drift monitoring | ZOV working instruction §6; supported | no automatic diagnosis |
| ROLE_CHARTER | Professional standing contract specifying allowed/forbidden acts | CHARTERS; supported candidate | document ownership |
| PROJECT_FRAME | Current project/environment in which Office works | CHARTERS; supported | time-scope |
| CURRENT_TASK | Currently specified substantive task | CHARTERS; supported | must not be inherited implicitly |
| WORK_PERMIT | Explicit, bounded authorization for concrete work; not created by capability or occupant activation | CHARTERS; Doctor; supported | authority/event shape |
| FINAL_AUTHORITY | Individual empowered to approve the highest-level decision: Author / A`TUIN | Doctor/Author; supported | no silent delegation |
| CAPABILITY | What agent/tool can do, irrespective of permission | Doctor/Claude; candidate | not authorization |
| AUTHORIZATION | Issuance of legitimate permission by authorized decision-maker | Doctor/Claude; candidate | distinct event |
| EXECUTION | Observed act/action or claimed run, distinct from evidence/approval | Doctor and code-spec usage; candidate | evidence grades |
| EVIDENCE | Observable records supporting a claim, with a stated grade | Doctor chronology; Claude; candidate | deterministic vs agent-attested |
| COMPLETED | Executor reports or evidence shows task operations finished | Doctor/Author; candidate | not ACCEPTED |
| ACCEPTED | Responsible reviewer/authority has accepted result, separate from execution | Doctor and engineering SPEC; candidate | not Work Permit |
| ACTIVE (OCCUPANT) | Office occupancy activated by Author | Doctor registry; supported | not work authorization |
| ACTIVE (TRIAD) | Authorized work in progress | Author proposal; working | distinct state dimension |
| WAIT | Available, no substantive current authorized operation | Dynasty practice; supported | not chat death |
| FROZEN | Deliberate suspension preserving all state and evidence | Author directive; working | reopening rule |
| BLOCKED | Cannot proceed until specified condition resolved | Working | differs from WAIT |
| CLOSED | Project/task formally concluded | Working | status ownership |
| PREDECESSOR | Earlier occupant in an Office dynasty | Doctor registry; supported | may still exist as Emeritus |
| SUCCESSOR | New occupant/formal candidate following predecessor in same Office | Doctor registry; supported | pre- vs post-activation |
| EMERITUS | Retired predecessor retained in advisory/provenance relation without active Office authority | Doctor chronology; supported | distinguish mentor |
| MENTOR | Advisory predecessor/specialist role, not hidden authority | Doctor registry; supported | must be explicitly bounded |
| CONSULTANT | Advisory contributor without inferred Office authority | Doctor/Author practice; working | explicit mandate |
| PROVENANCE_WITNESS | Former occupant/source can testify to historical facts, cannot issue current permit | Doctor registry; supported | scope of testimony |
| BIRTH | First activation of an Office occupant, or institutional birth phase as specified | Doctor registry; candidate | separate formation / activation |
| SUCCESSION | Formal professional function transfer to a new occupant | Doctor registry; supported | not personal-identity transfer |
| IMPRINTING | Staged acquisition of professional context/material in governed order | Doctor proposal; candidate | not activation/maturity |
| FOUNDATION | Selected foundational source corpus for professional understanding | Dynasty methodology; candidate | do not reconstruct absent sections |
| CONTRACT | Durable role/professional source governing Office boundaries | Dynasty methodology; candidate | hierarchy with charter |
| TESTAMENT | Predecessor's explicit handoff testimony, not authority in itself | Dynasty methodology; candidate | no hidden succession authority |
| HANDOFF | Time-bound project/work-state transfer with provenance | Dynasty methodology; candidate | stale tasks not automatically active |
| SUCCESSOR_GATE | Competence/authority boundary review before activation | Doctor registry; supported | acceptance is not activation |
| NEONATAL_CHECK | Doctor's formation/successor health verification | Doctor chronology; supported | independent of final authority |
| ACTIVATION | Explicit Author decision seating occupant in Office | Doctor registry; supported | not current Work Permit |
| SUDDEN_CHAT_LOSS | Unexpected loss of active conversation | Doctor registry; supported | loss of Office not implied |
| ABORTED_BEFORE_ACTIVATION | Candidate formation stopped without creating an active occupant | Doctor registry; supported | record retained |
| VALHALLA_CONTINUITY | Open category for predecessor continuity using external personal memory | Doctor registry; **UNRESOLVED** | do not treat as successor birth material |
| EVENT_LEDGER | Append-only institutional event record, primary source for administrative state | Claude conclusion; agreed design direction | authoritative schema pending |
| CLAIM / EVIDENCE / RECORD | Three independent stages: assertion, verification, persistent institutional registration | Claude conclusion; candidate | actor rights matrix |
| SECRETARY | Routing, conveying permitted material and returning response with evidence claims | Pivot/Claude; candidate | office vs function deferred |
| REPOSITORY_STEWARD | Audit and registration profession, not scientific or staffing authority | Author/Doctor/Claude; candidate | code handles deterministic writes |
| DISCLOSURE_CLASS | Allowed scope of recipient exposure for a message/attachment | Claude conclusion; candidate | enumerations pending |
| CORPORATE_CHANNEL | Message path with explicit coverage and retention guarantees | Claude conclusion; candidate | AUTHOR_RELAY and OUT_OF_BAND |
| HONC_TIMES | Newsletter view drawn from verified events, not a second authority for statuses | Author/Doctor/Claude; candidate | defer until ledger |

## Non-negotiable distinctions
- `OFFICE ≠ OCCUPANT ≠ CHAT ≠ CURRENT_WORK_STATE`.
- `CAPABILITY ≠ AUTHORIZATION`.
- `EXECUTION ≠ EVIDENCE ≠ ACCEPTANCE` and `COMPLETED ≠ ACCEPTED ≠ AUTHORIZED`.
- `ROLE BIRTH ≠ FOUNDATION ACQUISITION ≠ PROFESSIONAL MATURITY`.
- **ZOV is not ZOR**, and ZOR without a concrete Work Permit does not grant an open task.

## Immediate collision decisions pending
1. Legacy technical `OCCUPANT=(provider, conv_id)` vs institutional `OCCUPANT=executor occupying Office`. Proposed remedy: qualify legacy `LEGACY_CHAT_BINDING_IDENTITY` and preserve legacy file semantics/versions; do not silently rewrite older accepted contracts.
2. `BIRTH` as first activation (registry event) versus preceding formation process; proposed terms `FORMATION` and `ACTIVATION`, with `BIRTH` at the institutional milestone, subject to Doctor review.
3. `ACTIVE` may describe an occupant, triad, work permit or process, so **never use without a subject type**.
4. `SECRETARY` as profession versus communication protocol/transporter — keep distinction open pending operational pilot and Claude's review.
5. `EVIDENCE` grade schemes in Doctor clinical history (A/B/C/D) and technical transport (`DETERMINISTIC/AGENT_ATTESTED`) have **different domains**; do not merge labels.

**NEXT:** Doctor/ Keeper return source usage/alternatives + citations; Integrator issues v0.2 and circulates to Chief Prompter and Claude for collision review before Author acceptance.
