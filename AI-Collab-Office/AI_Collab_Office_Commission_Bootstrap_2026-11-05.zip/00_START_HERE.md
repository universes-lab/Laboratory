# AI-Collab Office — bootstrap package

**CREATED_AT:** 2026-11-05T18:26:17+01:00  
**FROM:** Chief Integrator / Methodologist  
**TO:** Author / A`TUIN; Doctor; Claude / AI-Collaboration Developer; Ontology Keeper  
**STATUS:** COMMISSION WORKING PACKAGE; NOT CANON; NOT AN ACTIVE CODE WORK PERMIT  
**FINAL AUTHORITY:** Author / A`TUIN

## Purpose
Launch the Author-directed restructuring of AI-Collab while retaining the original Laboratory as an archival/scientific source, building a **new private** corporate Office, preparing the Doctor-supervised maternity-ward transfer, and separately designing a **public** HONC theory website.

## Decisions already made by the Author
- Separate private corporate repository for Office (not a directory within public Laboratory).
- One corporate glossary: Doctor and Keeper gather source usage; Integrator authors the integrated document.
- Do not require new product-level ChatGPT Work proof as a prerequisite; keep the Secretary protocol's evidence, scope and prompt-injection defenses.
- Public theory portal belongs in universes-lab/HONC, NOT in private Office.
- Old BUILD 001: bring STEP 2 to clean externally confirmed checkpoint; STEP 3 HOLD; Samurai WAIT / WORK PERMIT NONE thereafter.
- Doctor, when the private Office exists, is responsible for reviewing and transferring verified maternity/dynastic source materials. Source history is preserved, not erased.

## Boundaries
- This package is a commission draft. It is NOT the birth pack of a successor, and does NOT transfer authority or old chat memory.
- Do not upload correspondence, personnel/diagnostic records, Work Permits or sensitive governance into the public Laboratory/HONC repositories.
- No private GitHub repo has yet been created using the available connector; the Author must create it through GitHub's UI or an authorized repo-administration tool, then explicitly permit Office bootstrap upload.
- The only already-created GitHub artifact of this task is a **public, planning-only** issue for the HONC site: https://github.com/universes-lab/HONC/issues/1.

## Contents
- `01_ARCHITECTURAL_PIVOT_V1_2.md`: revised commission architectural basis.
- `02_GLOSSARY_WORKING_DRAFT.md`: Integrator's initial definitions and collisions; awaiting Doctor and Keeper source reviews.
- `03_OFFICE_REPOSITORY_BOOTSTRAP.md`: layout, permissions, event/mail records and migration boundaries.
- `04_DOCTOR_MATERNITY_MIGRATION_TASK.md`: source-review and move/copy handoff for Doctor.
- `05_CLAUDE_ARCHITECTURE_TASK.md`: technical design commission brief for Claude.
- `06_HONC_PUBLIC_PORTAL_TASK.md`: public website/visualizations planning scope.

## Sequence
1. Author creates private `universes-lab/AI-Collab-Office` and verifies visibility PRIVATE.
2. Upload/bootstrap this package as **drafts** only; grant/verify access individually.
3. Doctor + Keeper produce provenance reviews; Integrator resolves glossary collisions, working with Prompter on role vocabulary.
4. Claude returns technical schema, rights/event matrix and migration plan; Doctor reviews medical/dynastic requirements.
5. Integrator issues next reviewed version for Author approval; lower-triad implementation remains on HOLD until explicitly authorized.
