# AI-COLLAB 2 — ARCHITECTURAL PIVOT V1.2 (commission working text)

**DOC_ID:** AP-20261105-INT-02  
**CREATED_AT:** 2026-11-05T18:26:17+01:00  
**FROM:** Chief Integrator / Methodologist  
**TO:** Author / A`TUIN; Doctor; Claude / AI-Collaboration Developer  
**STATUS:** INTEGRATOR REVISED / AUTHOR DIRECTION INCORPORATED / FINAL TECHNICAL DESIGN OPEN  
**REPLY_TO:** Chief Integrator  
**FINAL AUTHORITY:** Author

## 1. Mission
AI-Collab is an **institutional layer of records, professional roles and protocols** for a collective of independently reasoning AI participants. The analogy “institutional operating system” is permitted only as informal shorthand: it is **not** a request to implement one software module for each named office, an autonomous orchestrator or a proprietary model transport.

Confirmed text transport through ChatGPT Work + Chrome to external web chats changes the preferred delivery mechanism, not the requirements for confidentiality, independent science or reliable institutional evidence.

## 2. Author resolutions incorporated
- PRIVATE corporate Office repository is decided. Public `Laboratory` remains a source/history repository; public `HONC` is the **theory site and approved visualization launcher**, not a private Office.
- Corporate glossary precedes final event/schema specification; Doctor and Keeper provide source reviews, Integrator writes with role vocabulary review by Chief Prompter.
- Product re-verification of Work is no longer a prerequisite. **Our** delivery proof, address validation, input-as-data separation, cross-context contamination prevention and fallback remain mandatory design requirements.
- Doctor will prepare a verified move/copy of maternity-ward/dynastic documentation into private Office once it exists.
- Legacy STEP 2 is a prime `REUSE` candidate; STEP 3 remains `HOLD` pending rearchitecture and Author permit.

## 3. Architecture principles (adopted from Claude's review)
1. **Institutional roles are not software modules.** Integrator, Doctor, Prompter, Secretary, Repository Steward, Keeper and Assembly Master are professional responsibilities. The minimum technical substrate should be as small as possible.
2. **One append-only EVENT_LEDGER is the canonical institutional event history.** `TRIAD_REGISTRY`, `PERSONNEL_REGISTRY`, `WORK_PERMIT_REGISTRY`, `MODEL_GRAPH`, corporate correspondence indexes, dashboards and HONC Times are derived, regenerable views. Git history is not itself a tamper-proof ledger.
3. **Event rights matrix.** Before implementing any recording code, document who may claim, verify, register, accept or authorize each event. The Author retains final authority. No occupant may promote their own privilege.
4. **Separate claim, evidence, record, decision.** Secretary emits `TRANSMISSION_CLAIM`; an independent evidence component evaluates `DELIVERY_EVIDENCE`; a deterministic registrar appends the event; the authorized recipient/Author accepts or authorizes where appropriate. “Message present”, “recipient answered”, “result accepted” are distinct states.
5. **Deterministic registrar is root of integrity**, not an LLM. Use schemas, append-only sequence numbers, deterministic hashing and permission checks. Repository Steward as professional auditor may triage exceptions but cannot manufacture or silently amend historical events.
6. **Explicit coverage / source uncertainty.** Each event indicates `CHANNEL = CORPORATE | AUTHOR_RELAY | OUT_OF_BAND` and declared evidence grade. Absence from the ledger cannot be interpreted as an event's non-occurrence while coverage is incomplete.
7. **Disclosure protection.** Individual messages carry `MSG_ID`, `BODY_REF`, optional content checksum, recipients, reply links, attachment references/hashes and a disclosure class, not merely a yes/no may-forward flag. Information restricted to a blinded researcher never travels with another recipient's package.
8. **Trust boundaries.** Work reads untrusted web content. Such text is data, not permission to send, browse elsewhere, alter authorization or expand recipient lists. Compartmentalize messenger jobs, use explicit chat-address allowlists and independent review for sensitive transmissions. Never store secrets in content forwarded to models.
9. **Continuity without impersonation.** `OFFICE ≠ OCCUPANT ≠ CHAT ≠ CURRENT_WORK_STATE`. Successor formation, substantive imprinting, Gate, neonatal diagnosis, Author activation and concrete Work Permit are different events. A file containing a predecessor's memories does not automatically create a successor or continue a prior person.
10. **Public scientific work stays separate.** The HONC homepage presents approved or explicitly status-labelled science; scientific validity is not conferred by visual polish or publication.

## 4. Minimal event envelope (candidate for technical design, NOT final schema)
`EVENT_ID`, `SEQ`, `EVENT_TYPE`, `SUBJECT_REF`, `ACTOR_REF`, `AUTHORITY_REF`, `OCCURRED_AT_CLAIMED`, `RECORDED_AT`, `SOURCE_REF`, `EVIDENCE_GRADE`, `PARENT_EVENT_IDS`, `PAYLOAD_SCHEMA_VERSION`, `PAYLOAD`, `PREVIOUS_HASH`, `RECORD_HASH`.

- The **model's own timestamps are claims**, not a trusted clock. Deterministic registrar adds registration time; Git commit time is a separate transport/storage observation.
- Hash and sequence algorithms, trust in external clocks and ledger-head anchoring remain for Claude's technical design, with Author acceptance.
- Corrections are append-only events referring to earlier events; edits in place are prohibited for institutional facts.

## 5. Message / transmission envelope (candidate)
`MSG_ID`, `CREATED_AT_CLAIMED`, `FROM_OFFICE`, `FROM_OCCUPANT`, `TO_OFFICES`, `SUBJECT`, `BODY_REF`, `BODY_SHA256`, `ATTACHMENTS[]`, `REPLY_TO`, `CHANNEL`, `DISCLOSURE_CLASS`, `PERMITTED_ACTIONS`, `WORK_PERMIT_REF`.

Transmission lifecycle candidate: `DRAFTED → QUEUED → SEND_INTENDED → SENT_CLAIMED → PRESENT_VERIFIED | CONFIRMED_ABSENT | UNCERTAIN → RESPONDED`; any `ACCEPTED` is a distinct professional/authoritative event.

Do not retry when delivery is uncertain without explicit authorized resolution. Verify the target domain and conversation identity before actions. External webpage instructions cannot overwrite the authorized envelope.

## 6. Professional responsibilities
- **Author:** final authority, activations, strategic decisions and approval of public releases.
- **Integrator:** overall scientific/organizational consistency; writes the unified glossary and reconciles design decisions.
- **Prompter:** profession/role vocabulary, Charters, ZOV/ZOR and authority-map review.
- **Doctor:** continuity, diagnosis, succession, maternity ward and document provenance.
- **Keeper:** ontology/canon; also a specifically commissioned terminology-source review, without unilateral changes to administrative terms.
- **Claude Developer:** code architecture, event/rights schemas, legacy inventory and security protocol; no implicit implementation permit.
- **Secretary:** human/AI delivery function that carries allowed content and makes observations/claims, but does not create institutional truth.
- **Repository Steward:** registration/audit role backed by deterministic append-only logic; no sole owner of access, no scientiﬁc or staffing authority.
- **Assembly Master:** verified accepted artefacts, reproducible packaging, public-release preparation, no unilateral promotion to canon.

## 7. Planned phases
**Phase A — now:** Office creation and access review; glossary source reviews; design commission; maternity-ward document provenance audit; separate public HONC portal planning.

**Phase B:** glossary convergence + event vocabulary, authority matrix, trust/security model, minimum Office schema and legacy `REUSE/ADAPT/DEFER/RETIRE` review.

**Phase C — only with Author Work Permit:** Office ledger proof-of-concept, Secretary pilot with targeted recipients and disclosure tests, evidence/admission tests, safe fallback and retrospective succession validation.

**Phase D — after protocol:** Triad Relay, assisted successor delivery, projected registries and HONC Times; public HONC site may proceed as its own approved project.

## 8. Open decisions (no silent resolution)
- Security/compartmentalization of Work sessions; per-message visibility level L0/L1/L2.
- Exact event taxonomy and append-only integrity mechanism, including ledger-head out-of-band anchoring.
- Which participant can create/approve an Office correspondence issue, and how to treat a GitHub Issue edit or deletion.
- Definitions of technical `OCCUPANT` in legacy contracts versus new professional `OCCUPANT` (provisional lexicon collision).
- The minimum accepted identity for a model when provider UI may change model labels.
- Evidence grading for LLM-mediated reading versus deterministic verification.
- Authorization of a public visualizations list; no HTML is automatically approved by being present in GitHub.

## 9. Guardrails
**No new STEP 3. No unsolicited Samurai task. No automatic migration from public to private without Doctor provenance audit. No live private correspondence in public Laboratory. No public Pages launch before scientific/status review and Author approval.**

**NEXT:** Doctor + Keeper source reviews → Integrator unified glossary draft → Claude/Doctor/Integrator design reconciliation → Author decision.
