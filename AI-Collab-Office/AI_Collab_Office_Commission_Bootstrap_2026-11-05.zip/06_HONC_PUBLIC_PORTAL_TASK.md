# Public HONC theory homepage and visualization portal — planning brief

**CREATED_AT:** 2026-11-05T18:26:17+01:00  
**FROM:** Chief Integrator  
**TO:** Author; Claude Developer; Assembly Master (publication review)  
**STATUS:** PUBLIC PORTAL DESIGN / LAUNCH NOT AUTHORIZED

## Verified repository state, 2026-11-05
- `universes-lab/HONC`: PUBLIC, `homepage=null`, `has_pages=false`, default branch `main`.
- Repository root contains `Architecture_of_Typical_Universes/`, `Old_Canon/`, `safe_sync.bat`; no homepage launcher.
- Source text `Architecture_of_Typical_Universes/First_Principles_of_Temporal_Dynamics.md`.
- Interactive HTML candidates (not approval status):
  1. `Sources/Geometry_of_Latched_λ-Molecules.html` — Geometry of Latched λ-Molecules.
  2. `Sources/Qf_SuperZ.html` — Супер-Z Qf-нити.
  3. `Sources/Qf_Thread_Sketch_0.html` — Qf-нить с навесами.
  4. `Sources/Qf_Thread_Sketch_1.html` — Qf-нить с навесами.
- All four currently reference Three.js 0.132.2 via jsDelivr, and Google Fonts. Actual runtime/browser behavior has not been verified in this turn.

## Proposed site map
- Home — what HONC asserts, what is open, primary theory references and version/disclaimer.
- Theory — first principles, glossary, revisions and links to source repositories.
- Visualizations — status-labelled catalog with approved launch links, descriptions, physics assumptions, controls, source, last review.
- Research status — canonical definitions vs working geometry/experiments vs unresolved laws.
- About / attribution / collaboration contact — public information only, no internal Office/personnel documents.

## Candidate review inventory (no premature promotion)
| File | Existing form | Publication decision |
|---|---|---|
| Geometry_of_Latched_λ-Molecules.html | Interactive HTML, existing basis for geometric work | **REVIEW**: not yet certified for public launch |
| Qf_SuperZ.html | Interactive HTML | **REVIEW**: geometry/physics labels and dependency QA required |
| Qf_Thread_Sketch_0.html | Sketch 0 | **HOLD or historic/preview**, until Author confirms |
| Qf_Thread_Sketch_1.html | Sketch 1 | **HOLD or historic/preview**, until Author confirms |

## Implementation path to evaluate (not yet execute)
1. Decide public content ownership/approval (Author scientific + Assembly Master publication checks).
2. For every candidate: check local and GitHub Pages runtime, no intersecting forbidden rings, valid parameter controls, proper status/disclaimer, display at phone and desktop, external dependency strategy and source/version links.
3. Draft `index.html` and catalogue under `docs/` or a dedicated Pages branch; compare operational simplicity and risk of exposing unfinished HTML.
4. If approved, enable Pages, publish, verify actual live URLs and update repository metadata (homepage). Do not claim a live site until fetched and tested.
5. Keep private Office separate; only public accepted announcements/links may cross to this site.

## Relevant open scientific condition
Existing Qf interaction models under KT-1/KT-3 are still under investigation. A visualization's existence does not validate all movement laws or continuous collision-avoidance; every launcher must carry a scoped evidence status.

## GitHub trace
Planning issue created under Author's instruction: https://github.com/universes-lab/HONC/issues/1.

**STOP at plan/inventory. No Pages enablement or public release without subsequent approval.**
