# Private corporate Office — bootstrap specification

**CREATED_AT:** 2026-11-05T18:26:17+01:00  
**FROM:** Chief Integrator  
**TO:** Author; Doctor; Claude Developer  
**STATUS:** IMPLEMENTATION SCAFFOLD / REVIEW REQUIRED

**Approved repository type:** PRIVATE, separate from the PUBLIC repositories `universes-lab/Laboratory` and `universes-lab/HONC`.

**Proposed name:** `universes-lab/AI-Collab-Office`. Name is a recommendation; status PRIVATE is an Author decision. As of preparation, the connector could not locate this repository and has **no create_repository operation**. No private repository has been provisioned here.

## Initial tree (conceptual; empty directories are not Git objects)
```
README.md
OFFICE_INDEX.md
architecture/
  2026-11-05_ARCHITECTURAL_PIVOT_V1_2.md
  COMMISSION_DECISIONS.md
  LEGACY_REUSE_ADAPT_DEFER_RETIRE.md
lexicon/
  UNIFIED_AI_COLLAB_GLOSSARY_WORKING.md
  sources/DOCTOR_LEXICON_SOURCE_REVIEW.md
  sources/KEEPER_LEXICON_SOURCE_REVIEW.md
protocols/
  EVENT_LEDGER_SCHEMA.md
  EVENT_RIGHTS_MATRIX.md
  MESSAGE_ENVELOPE.md
  DELIVERY_EVIDENCE.md
  DISCLOSURE_RULES.md
  TRUST_BOUNDARIES.md
ledger/
  events/    # append-only, deterministic registrar only (not manually curated)
  anchors/   # signed or independently acknowledged head-hash references
projections/ # derived, regenerable, no manual source status
  TRIAD_REGISTRY.md
  PERSONNEL_REGISTRY.md
  WORK_PERMIT_REGISTRY.md
  MODEL_GRAPH.md
correspondence/
  index/     # linked by MSG_ID; primary bodies only if authorized
  threads/   # Issues or references; do not copy restricted bodies by default
maternity/
  README.md
  VERIFIED_MIGRATION_MANIFEST.md
  BIRTH_REGISTRY.md
  chronicles/
  protocols/
  dynasty/
    Doctor/
    Integrator/
    Prompter/
    HONC_PHYSICIST/
    Assembly_Master/
    others/
news/
  HONC_TIMES_INDEX.md
```

## Security model for creation
- Create PRIVATE, disable public Pages, check owner/account and visibility after creation.
- Before upload, review who has read/write/admin. Do not presume all models/chats possess separate GitHub identities; connector acts with connected account permissions, which must be logged.
- Do not publish human private data, raw secrets, auth tokens or need-to-know scientific packets in files/Issues visible beyond their intended audience.
- Separate correspondence **metadata** (index and event refs) from restricted **body** content. A private repo alone does not enforce compartmentalization if every participant can read every file.
- Require branch protection or review according to authorized account capabilities. Git commit author ≠ the conversational FROM field; retain declarative sender plus evidence.

## Proposed event record and provenance
An event is recorded by deterministic code after validation of claim, evidence and authority. Git can contain records, but a git history can be rewritten: an ordered hash chain and periodically exported ledger-head anchors are recommended as tamper evidence. The source of the timestamp must be recorded separately from an AI-authored claimed timestamp.

## Issues as correspondence
GitHub Issues are candidate **thread transport** for internal ChatGPT roles, not a guaranteed autonomous mail system. A participant has no automatic awareness of a new Issue; delivery and reading must be evidenced. Every message should carry `MSG_ID`, `CREATED_AT`, `FROM`, `TO`, `REPLY_TO`, `BODY_REF`, `DISCLOSURE_CLASS`, and explicit attachment controls. The registrar observes the Issue URL/creation event and does not infer receipt/understanding.

## Migration of existing Laboratory documentation
Copy verified, relevant source versions into private Office only after Doctor audit. Keep original public files as history; avoid automatic deletions/moves that destroy provenance. Store origin `repo/path/ref`, immutable commit SHA, original blob SHA, Doctor status, copy/checksum result and the current-vs-historical classification.

**STOP:** no uploads to public Laboratory for internal correspondence, no claims that the Office is created, no migration before Author/Doctor authorization and repository privacy check.
