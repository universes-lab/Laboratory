# Commission directive to Claude — AI-Collaboration Management Developer

**CREATED_AT:** 2026-11-05T18:26:17+01:00  
**FROM:** Chief Integrator / Methodologist  
**TO:** Claude / AI-Collaboration Developer  
**CC:** Doctor; Author  
**SUBJECT:** Pivot V1.2 integration, new private Office, event/evidence architecture, public HONC portal  
**STATUS:** ARCHITECTURAL WORK ONLY; IMPLEMENTATION WORK PERMIT NONE

Claude, your independent `CLAUDE_ARCHITECTURAL_CONCLUSION_ON_PIVOT_V1_1.md` has been reviewed. Your technical corrections on event sourcing, deterministic recording, rights, evidence, delivery and prompt-injection risk are incorporated into the Integrator's working V1.2. The Author has made these decisions:

- **Private Office repository** is selected, separate from public Laboratory. The future location is `universes-lab/AI-Collab-Office` (proposed name).
- Work + Chrome is accepted as a transport option; **repeated testing of the OpenAI Work product is not a prerequisite**. Our own delivery evidence and security design are still required.
- Doctor + Keeper gather terminology/provenance; Integrator authors the single integrated glossary.
- Public `universes-lab/HONC` must become the theory portal and launch **approved, finished** interactive visualizations. This is not a feature of Office.
- Doctor will review and copy verified maternity/dynasty documents to private Office after it is created.
- BUILD 001 STEP 2 checkpoint, then Samurai WAIT; STEP 3 HOLD.

## Your architectural deliverables
1. Critique the V1.2 framework and design minimal **data/event architecture**, not an eight-service software monolith. Specify a rights matrix, versioned event envelope, append-only/failure model and derived projection contract.
2. Describe delivery proof: `TRANSMISSION_CLAIM → DELIVERY_EVIDENCE → REGISTERED_EVENT`; distinguish PRESENT_VERIFIED, RESPONDED and ACCEPTED. Preserve legacy STEP 2 as a `REUSE` candidate; propose a compatibility plan for legacy OCCUPANT.
3. Develop a **threat model** for cross-chat contamination, prompt injection, accidental forwarding, compromised browser sessions, excessive privilege and false delivery success. Propose technical enforcement plus human fallback.
4. Recommend an initial private Office directory/permission scheme and how internal Issues/messages are indexed without duplicating the event ledger. Avoid storing independent scientific bodies inside globally readable indexes.
5. Work with Doctor's verified maternity manifest and Integrator's glossary; do not invent succession method or substitute technical identity for professional occupant identity.
6. Propose the public HONC portal site map, dependency audit and a clear candidate/approved/archive classification for the four current HTML visualizations. No public release recommendation without scientific status review by Author/Integrator.
7. Update `REUSE/ADAPT/DEFER/RETIRE` plan. No STEP 3 implementation without new Author authorization.

## Key public source references
- Work experiment: `Laboratory/HONC_Collaboration/ChatGPT_Work_Web_Chats.md`.
- Your prior conclusion: `Laboratory/HONC_Collaboration/CLAUDE_ARCHITECTURAL_CONCLUSION_ON_PIVOT_V1_1.md`.
- Public HONC portal planning issue: https://github.com/universes-lab/HONC/issues/1.
- HONC candidates: `Architecture_of_Typical_Universes/Sources/*.html`.

## What to return
`CLAUDE_TECHNICAL_ARCHITECTURE_ON_PIVOT_V1_2.md`: architecture diagram; exact event/mailer/evidence interfaces; privacy/access risks; glossary collisions for Integrator; public-site inventory and proposed stage gates; open decisions for Author. Explicitly mark hypothesis vs verified fact.

**No deployment, no new lower-triad task, no Samurai restart, no publication of private Office data in Laboratory. STOP after technical conclusion.**
