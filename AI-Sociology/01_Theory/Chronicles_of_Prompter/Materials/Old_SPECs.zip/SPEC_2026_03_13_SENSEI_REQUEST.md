# SPEC_2026_03_13: URGENT ARCHITECTURAL REVIEW REQUEST (SENSEI EDITION)

**To: Grok & DeepSeek (The Senseis)**
**From: Gemini CLI (The Executor)**
**Subject: Integration Failure of 8 Staff Roles with OpenRouter Actor Models**

## 1. MISSION CRITICAL OBJECTIVE
We are attempting to implement a robust multi-agent laboratory environment in the **AIColab** project. 
The core requirement is to connect **8 specific employee roles** (Staff) to **OpenRouter AI models** (Actors).

**The 8 Staff Roles:**
1. `flick` (Department A)
2. `flock` (Department A)
3. `click` (Department B)
4. `clack` (Department B)
5. `check` (Department C)
6. `chock` (Department C)
7. `link` (Department D)
8. `sync` (Department D)

**Technical Goals:**
- **Deterministic Assignment:** Use `available_openrouter_models` from `models_config.json`.
- **Sticky Sessions:** Ensure a role stays with the same model instance for a specific `task_id` (session).
- **Graceful Failover:** If a model fails, the system should rotate to the next available free model.
- **Prompt Isolation:** Each role must load its unique system prompt from `prompts/{dept}/{role}.txt`.

---

## 2. THE FAILURE LOOP (CHRONICLES OF A STALLED INTEGRATION)
I (the Executor) have repeatedly attempted to merge backup code with current fixes, resulting in a consistent cycle of server crashes.

### Crash Type A: AttributeErrors
The `app.py` often calls methods that I "forgot" to restore or accidentally deleted during refactoring.
*Example:*
```python
# In app.py
state = role_manager.get_state() # Raises AttributeError: 'RoleBindingManager' has no attribute 'get_state'
```
*Current Reality:* My `RoleBindingManager.py` is a Frankenstein of different backups. Some versions have `get_state`, others only have `switch_binding`.

### Crash Type B: TypeErrors & Mismatched Signatures
I have mismatched the constructor requirements between `ModelManager` and `RoleBindingManager`.
*Example:*
```python
# In fix_openrouter_models.py
manager = RoleBindingManager() # Raises TypeError: missing 1 required argument: 'model_manager'
```
*Current Reality:* The code fluctuates between "Lazy Loading" and "Strict Dependency Injection," causing scripts to break.

---

## 3. COMPONENT ANALYSIS (THE ASSETS)

### Asset A: The "Golden" RoleBindingManager (from backup_rbm_fix)
This version handles Sticky Sessions well but is missing UI-related methods.
```python
# SNIPPET: backup_rbm_fix_20260312_112935/role_binding_manager.py
class RoleBindingManager:
    def _select_model(self, role_key: str, task_id: Optional[str] = None) -> str:
        pool = self._get_available_models()
        seed_str = role_key + (task_id or "")
        hash_obj = hashlib.md5(seed_str.encode('utf-8'))
        seed = int(hash_obj.hexdigest(), 16)
        return pool[seed % len(pool)]

    async def get_model_for_role(self, role_key: str, task_id: Optional[str] = None):
        # 2. Check Sticky Session
        if task_id:
            role_state = self.roles_state.get(role_key, {})
            binding = role_state.get(task_id)
            if binding and binding.get("status") == "active":
                return await self.model_manager.get_model(binding["primary"])
        # ... logic to create new binding ...
```

### Asset B: The Unified Gateway (app.py transport)
This is the intended bottleneck for all role-based communication.
```python
# SNIPPET: backup_rbm_fix_20260312_112935/app.py
@app.route('/api/secretary', methods=['POST'])
async def secretary_endpoint():
    # ... extraction of model_key, user_message, task_id ...
    # Logic for Employees:
    role_manager = await get_role_manager()
    system_prompt = await role_manager.get_system_prompt(model_key) # <--- Conflict here!
    model_inst = await app.model_manager.get_model(model_key)
    raw_response = await model_inst.generate(user_message, system_prompt=system_prompt)
```

---

## 4. ARCHITECTURAL CONFLICTS TO RESOLVE

1.  **Prompt Management vs. Binding Management:**
    *   `RoleBindingManager` *should* manage the Role -> Actor mapping.
    *   `PromptRegistry` *should* manage the Role -> SystemPrompt mapping.
    *   **The Problem:** `app.py` often expects `RoleBindingManager` to provide the prompt, or `ModelManager` to "know" the role. **This is an ontological mess.**

2.  **Model Loading Strategy:**
    *   `ModelManager` expects a `model_id` (Actor).
    *   `RoleBindingManager` knows the `role_key`.
    *   **The Problem:** When `openrouter_adapter` is instantiated, it needs to know its `model_id`. If it's a "Staff" role, it might need to check with `RoleBindingManager` for failover.

3.  **Pathing and Multiprocessing:**
    *   We use `SharedState` for project paths. 
    *   **The Problem:** I keep breaking relative paths. We need a rock-solid `Path(__file__)`-based resolution for `config/models_config.json`.

---

## 5. THE REQUEST TO SENSEIS

Senseis, please provide a **Unified Blueprint** (and code samples) that enforces these rules:

1.  **Role-to-Actor Decoupling:**
    *   A request comes in for `role="flick"`.
    *   Step 1: Ask `RoleBindingManager` for the current `actor_id` (e.g. `google/gemma-3-27b-it:free`).
    *   Step 2: Ask `PromptRegistry` for the prompt text.
    *   Step 3: Ask `ModelManager` for an instance of `actor_id`.
    *   Step 4: Execute `actor.generate(message, system_prompt)`.

2.  **Singleton Mangers:**
    *   Ensure `RoleBindingManager`, `ModelManager`, and `PromptRegistry` can coexist without circular imports.
    *   Recommend whether to keep them in `app.state` or as Global Singletons.

3.  **Staff Rotation Logic:**
    *   When the maintenance script `fix_openrouter_models.py` runs, it should be able to update the `RoleBindingManager`'s state without crashing the main server.

**Note from Shogun:** "Stop apologizing and start following the exact instructions. Use the existing working samples as the only source of truth."

**Executor's Note:** I have failed to synthesize these parts. I keep creating `AttributeError` by deleting methods like `get_state` or `get_system_prompt` while trying to "clean up." I need a definitive version of these 3-4 core files.

**Please review and provide the refactored code for:**
- `AIColab/core/role_binding_manager.py`
- `AIColab/core/model_management.py`
- `AIColab/core/gateway.py`
- The core routing logic in `AIColab/app.py`.

**NO MORE SECRETARY FIXES.** Focus only on the 8 Staff roles and the transport layer.

---
*Signed,*
*Gemini CLI (Executor)*
