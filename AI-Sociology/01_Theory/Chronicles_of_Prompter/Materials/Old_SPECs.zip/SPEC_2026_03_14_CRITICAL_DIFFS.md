# SPEC_2026_03_14: ОТЧЕТ О КРИТИЧЕСКИХ ОТКЛОНЕНИЯХ (AUDIT REPORT)

**Кому:** Сенсеям (Grok / DeepSeek)
**От:** Исполнителя (Gemini CLI)
**Тема:** Полная опись нерешенных проблем интеграции OpenRouter и Staff-ролей

---

## 📋 СВОДНЫЙ ПЕРЕЧЕНЬ ЗАДАЧ
1. **Проблема №1: Нестабильная (не-липкая) привязка моделей.** В рабочей версии отсутствует механизм Sticky Session, из-за чего на один и тот же вопрос отвечают разные "Актеры". Требуется внедрение `task_id`.
2. **Проблема №2: Некорректное отображение имен моделей.** В интерфейсе отображается сырой ID (`arcee-ai/...`), а требуется человекочитаемое сокращенное название.
3. **Проблема №3: Отключенное автообновление.** Скрипт верификации моделей закомментирован в `startup`, пул моделей не актуализируется.
4. **Проблема №4: Ошибочные пути и имена файлов промптов.** Система ищет старые файлы типа `flick_system.txt` в папке `docs`, вместо новых `flick.txt` в папке текущего проекта.

---

## 1. Проблема №1: Sticky Session Failure

### Как сейчас (Quart - не работает):
В `app.py` сессия игнорируется, модель выбирается напрямую по ключу роли.
```python
@app.route('/api/secretary', methods=['POST'])
async def secretary():
    data = await request.get_json()
    model_key = data.get('model') # 'flick'
    # ОШИБКА: task_id не извлекается и не используется для привязки
    model_inst = await app.model_manager.get_model(model_key) # Прямой вызов по имени роли
```

### Как требуется (FastAPI - рабочее решение из бэкапа .001):
Генерация `task_id` и разрешение через `RoleBindingManager`.
```python
@app.post("/api/secretary")
async def secretary_endpoint(request: Request):
    data = await request.json()
    task_id = data.get("task_id", str(uuid.uuid4())) # ГАРАНТИРУЕМ task_id
    model_id = role_manager.get_model_for_role(role_key, task_id) # ПОЛУЧАЕМ ПРИВЯЗАННУЮ МОДЕЛЬ
    model_inst = await app.state.model_manager.get_model(model_id) # ЗАГРУЖАЕМ ИМЕННО ЕЁ
```

---

## 2. Проблема №2: Model Name Display

### Как сейчас:
Выводится полный технический идентификатор.
```python
return jsonify({
    "modelInfo": {
        "modelId": getattr(model_inst, 'model_id', 'unknown') # Результат: 'arcee-ai/trinity-large-preview:free'
    }
})
```

### Как требуется (Теоретически):
Вывод `short_name` из конфига или адаптера.
```python
short_model_name = getattr(model_inst, 'short_name', model_key)
return {
    "modelInfo": {
        "modelId": short_model_name # Результат: 'Trinity Large'
    }
}
```

---

## 3. Проблема №3: Disabled Models Updater

### Как сейчас:
Вызов закомментирован, логика верификации простаивает.
```python
@app.before_serving
async def startup():
    try:
        from scripts.fix_openrouter_models import fix_assignments
        # asyncio.create_task(fix_assignments()) # <-- ЗАКОММЕНТИРОВАНО
        app.logger.info("Автоматическая фиксация OpenRouter-моделей отключена.")
```

### Как требуется:
Фоновый запуск верификатора при старте сервера.
```python
@app.on_event("startup")
async def startup_event():
    from scripts.fix_openrouter_models import fix_assignments
    asyncio.create_task(fix_assignments()) # <-- ДОЛЖНО РАБОТАТЬ
    app.logger.info("Автоматическая верификация моделей запущена.")
```

---

## 4. Проблема №4: Prompt Paths & Naming

### Как сейчас:
Жесткие ссылки на старые файлы в глобальной папке.
```python
# В старом RoleBindingManager или коде загрузки:
prompt_path = "docs/prompts/department_A/flick_system.txt" # ОШИБКА: Старое имя и папка
```

### Как требуется (Согласно Unified Blueprint):
Динамическая загрузка из проекта с новым именованием.
```python
# В core/prompt_registry.py:
self.role_map = { "flick": "department_A/flick.txt" }
# Логика поиска:
project_file = self.project_path / "prompts" / rel_path # Путь: .../projects/Bestihi.ru/prompts/department_A/flick.txt
if project_file.exists():
    return project_file.read_text(encoding="utf-8")
```

---
*Документ подготовлен Исполнителем под надзором Сёгуна.*
