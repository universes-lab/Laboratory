Аудит Кода: Остатки Старой Логики INTRO/TASK Диагноз: Старая логика частично
устарела — нет явных [INTRO]/[TASK] маркеров в runtime (код полагается на
параметр mode = MODE_WORK/MODE_CEO). Остатки: Branching по mode в run_department
(\_run_work_cycle / \_run_ceo_cycle), prompt generation по mode (\_get_prompt),
JSON-валидация в CEO-режиме. Нет detection по префиксу сообщения — это новый
инвариант. Зачем аудит: Переход к [TASK] как единственному триггеру, без
ветвлений по sender/role/type. Остатки по Файлам:

app.py: Нет mode detection. Branching в /api/chat по model_key (chief, E,
others), но prompt = get_prompt(model_key) без [TASK]. role_binding_manager.py:
MODE_WORK/MODE_CEO как параметр в run_department (branching в
\_run_work_cycle/\_run_ceo_cycle). \_get_prompt по mode (files like
"doc1_system.txt"). \_build_user_prompt — JSON-инструкции для CEO (валидация в
\_validate_json_response). openrouter_adapter.py: Нет mode — базовый generate.
lab_composition.py: Нет mode. fix_openrouter_models.py: Нет mode — ping без
маркеров.

ТЗ для Самурая (Gemini CLI): Устранение Старой Логики Режимов Контекст: Переход
к новому инварианту — режим TASK только по префиксу [TASK] в начале сообщения
(отсутствие = INTRO). Удалить все branching по mode (MODE_WORK/MODE_CEO), prompt
generation по mode, валидацию по схемам. Сообщения — stateless, без вычисления
режима по sender/role/type. Зачем: Детерминизм — единственный триггер [TASK],
упрощение, избежание ошибок ветвлений. Ограничения: Сохранить логику вызовов
(chief orchestration, E stateless), JSON-ответы в CEO (без схем). Нет новых
маркеров [INTRO]. Тесты — обязательны.

1. Список Удаляемых Механизмов

MODE_WORK/MODE_CEO константы и параметр mode в run_department
(role_binding_manager.py, строки ~20–30, ~100–120). Зачем: Удаление branching —
режим по [TASK], не параметру.

Mode-based prompt search в \_get_prompt (role_binding_manager.py, строки
~200–220, files like "doc1_system.txt" по mode). Зачем: Унификация — один промпт
на роль, без mode-вариантов.

JSON-валидация в \_validate_json_response и SCHEMA_C/SCHEMA_D
(role_binding_manager.py, строки ~300–320). Зачем: Упрощение — CEO парсит
response сам, без принудительных схем.

Branching в \_run_work_cycle / \_run_ceo_cycle (role_binding_manager.py, строки
~250–300). Зачем: Единый цикл — цепочка ролей, с [TASK] для формальности.

2. Список Изменяемых Функций

run_department (role_binding_manager.py, строки ~100–120): Найти: if mode ==
MODE_CEO: \_run_ceo_cycle else: \_run_work_cycle. Удалить: Mode параметр,
branching. Заменить на: Единый \_run_cycle(dept, roles, request_data, caller) —
последовательная цепочка ролей, с проверкой [TASK] в user_prompt (if "[TASK]" in
user_prompt: formal JSON, else: free text). Зачем: Унификация — один цикл, режим
по префиксу.

\_get_prompt (role_binding_manager.py, строки ~200–220): Найти: if mode ==
MODE_CEO: prefix = "doc" else: .... Удалить: Mode-based files (doc/ext).
Заменить на: prompt_file = project_path / "prompts" / f"{role_key}\_system.txt"
(один файл на роль). Fallback: BASE_PATH / "docs" / "prompts" / role_key. Зачем:
Упрощение — промпт без mode, поиск по роли.

\_build_user_prompt (role_binding_manager.py, строки ~230–240): Найти: if dept
== "C": return f"Проведи медицинскую диагностику...". Удалить: Dept-based
инструкции. Заменить на: user_prompt = request_data.get("message", "") if
"[TASK]" in request_data.get("message", "") else request_data.get("message",
"") + "\nВеди диалог.". Зачем: По префиксу — формальный для [TASK], диалог
иначе.

\_validate_json_response (role_binding_manager.py, строки ~300–320): Удалить:
Полностью (SCHEMA_C/SCHEMA_D). Заменить на: Simple check if "{" in response and
"}" in response — return json.loads if valid, else None. Зачем: Лёгкая валидация
— CEO сам парсит, без схем.

app.py /api/chat (строки ~150–200): Найти: system_prompt = await
role_manager.get_prompt(model_key). Удалить: Нет. Заменить: Добавить check: if
"[TASK]" in message: message = "[TASK]\n" + message (если отсутствует в
формальных). Зачем: Обеспечение триггера — Шеф добавляет [TASK] при постановке.

3. Новый Единый Алгоритм Формирования Сообщения

Шаг 1: Вход: user_message от фронтенда (/api/chat). Шаг 2: Check префикс: if
user_message.startswith("[TASK]"): formal_mode = True. Else: formal_mode =
False. Шаг 3: Get system_prompt = role_manager.get_prompt(role_key) (один файл).
Шаг 4: Build full_prompt = system_prompt + "\n" + (user_message if formal_mode
else user_message + "\nДиалог."). Шаг 5: Generate via
model.generate(full_prompt). Шаг 6: Log response в /logs/{role}.log. Зачем:
Детерминизм — префикс определяет всё, без mode/param.

4. Правила Обработки TASK в Триаде

Шеф → Отделы: При постановке — добавить [TASK] в message (formal JSON). Зачем:
Цепочка формальна. CEO → C/D: При вызове — [TASK] для консилиума (JSON). Зачем:
Диагностика/мозговой штурм — структурированы. Сотрудники: При [TASK] —
JSON-ответ; без — свободный текст. Зачем: Гибкость — формальность по
необходимости. Логирование: Всегда append response в log, с флагом formal_mode.
Зачем: Аудит — восстановление по истории. Fallback: Нет [TASK] — treat as
диалог, no error. Зачем: Graceful — без MISSING_MODE.

5. Тест-Сценарии (10+)

Тест 1: Диалог без [TASK] (INTRO): /api/chat model="flick" message="Привет, что
ты делаешь?" — ожидание: свободный ответ, no JSON. Тест 2: TASK с префиксом:
message="[TASK] Анализируй X" — ожидание: JSON-ответ, no branching. Тест 3:
Отсутствие префикса в формальном: message="Анализируй X" — ожидание: свободный
текст, no error. Тест 4: Chief Orchestration: /api/briefing message="Задача Y" —
ожидание: Шеф добавляет [TASK], цепочка формальна. Тест 5: CEO Consult:
/api/ceo/consult message="[TASK] Диагностика Z" — ожидание: JSON от C/D, no mode
param. Тест 6: Retry без маркера: Повтор вызова без [TASK] — ожидание: диалог,
no MISSING_MODE. Тест 7: Prompt Generation: get_prompt("flick") — ожидание: один
файл, no mode-based search. Тест 8: Log Append: После generate — check
/logs/flick.log — ожидание: response appended, with formal_flag. Тест 9:
Fallback Empty: Message без префикса, invalid JSON — ожидание: свободный текст,
no crash. Тест 10: Cross-Role: Вызов flick без [TASK] → диалог; с [TASK] → JSON.
Тест 11: E Stateless: /api/chat model="E" message="Medical" — ожидание:
stateless, no logs append.

Приоритет: Высокий
