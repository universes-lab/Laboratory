Системный Аудит: Структура Отчётов в Информационной Панели Состояние Системы:
Аудит завершён на основе анализа репозитория (app.py, core/lab_composition.py,
config/models_config.json, integrations/openrouter_adapter.py). Схема отчётов
стабильна, но "убийство" файла (вероятно, current_models.json или
lab_composition.py) — риск рассинхронизации state. Зачем аудит: Восстановление
"единого источника истины" без импровизации, предотвращение задержек.

1. Архитектурные Уровни Отчётов Уровень 1: Локальное Ядро (Субъекты Отчётов)

Состав: config/models_config.json (привязки ролей/model_id), current_models.json
(текущее состояние). Функция: Хранение фиксированных данных (роли, модели,
статусы). Зачем: State authority — отчёты строятся на JSON, без
runtime-генерации.

Уровень 2: API-Шлюз (Эндпоинты Отчётов)

Состав: app.py (/api/info/lab_composition). Функция: Запрос от фронтенда →
чтение JSON → возврат отчёта (состав лаборатории: роли, модели). Зачем:
Доступность — инфо-панель видит актуальное состояние без перезапуска.

Уровень 3: Управляющий Шлюз (Логика Формирования)

Состав: core/lab_composition.py (get_lab_composition). Функция: Чтение config →
mapping ролей → форматирование (e.g., "Флик:
meta-llama/llama-3.2-3b-instruct:free"). Зачем: Изоляция — логика в отдельном
модуле, легко тестировать/расширять.

2. Поток Работы Отчётов (/api/info/lab_composition)

Шаг 1: Фронтенд (index.html) запрашивает /api/info/lab_composition (GET). Шаг 2:
app.py → вызов core/lab_composition.get_lab_composition(). Шаг 3:
get_lab_composition() → чтение models_config.json/current_models.json (mapping
роль → model_id). Шаг 4: Формирование отчёта (JSON: {"roles": {"flick":
"model_id", ...}}). Шаг 5: Возврат в инфо-панель (отображение состава). Зачем:
Детерминизм — отчёт = snapshot state, без кэша (прямое чтение). Риск "убийства"
файла: Устаревание — timestamp check для reload.

3. Рекомендации для Самурая (Без Самодеятельности) Фиксация Проблемы:

Убитый Файл: Вероятно, current_models.json (state привязок) или
core/lab_composition.py (логика отчёта). Восстанови из backup (Git history или
local copy). Зачем: Сохранение state authority — без него отчёт пустой. ТЗ
Дипсика: Не "убивать" — ТЗ фиксировано (switch_binding, get_fixed_model). Если
импровизация — rollback к коммиту до правки. Зачем: Избежать задержек — следуй
ТЗ шаг за шагом. Проверка Отчёта: Запусти сервер, запроси
/api/info/lab_composition (curl или браузер). Ожидаемо: {"lab_composition":
{"A": {"flick": "model_id", ...}}}. Если пусто — check models_config.json
(mapping), lab_composition.py (read JSON). Зачем: Верификация — отчёт = mirror
state, без генерации.

Риски и Ограничения:

Риск Устаревания: Нет timestamp — добавь check (if file_modified > last_read —
reload). Масштабируемость: Отчёт для 8+ ролей — limit fields (только active).
Тестирование: curl -X GET http://localhost:5000/api/info/lab_composition —
verify JSON.
