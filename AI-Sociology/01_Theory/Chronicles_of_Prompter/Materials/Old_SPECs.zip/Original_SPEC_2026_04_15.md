📜 SPEC_2026-04-15: UI BUTTON REMAP + CLI EXECUTOR INTEGRATION
Статус: ✅ ФИНАЛЬНАЯ ВЕРСИЯ (прямой контакт Дипсик → Самурай)
Критичность: 🟡 СРЕДНЯЯ (чистка легаси + привязка новых кнопок)
Исполнители: Дипсик (код) → Самурай (интеграция)
Принцип: Одна кнопка → один режим. Console = subprocess. Admin = execute(). Staff = прямой OpenRouter.
🏛 АРХИТЕКТУРНЫЙ КОНТЕКСТ (КРАТКО)
Кнопка	Режим	Механизм	Почему
>	Console	subprocess.run()	Системные команды ≠ LLM, нужен прямой доступ к ОС
Аудит	Admin (auditor)	execute(mode="auditor", ...) + OpenRouter fallback	Аудит моделей = LLM + внешний консультант
ШЕФ	Local + Secretary	ModelManager.get_model("chief") + execute(mode="secretary", for_role="chief")	Шеф = локальная модель, Секретарь = предварительная обработка [TASK]/[INFO]
СЕО	Local + Secretary	ModelManager.get_model("ceo") + execute(mode="secretary", for_role="ceo")	Аналогично Шефу
Симпозиум	Composite Flow	execute(mode="auditor", scope="decisions") + CEO + OpenRouter strategic	Оркестрация нескольких источников, не чистый CLI

🔑 Ключевое правило: execute() используется ТОЛЬКО для режимов secretary / auditor. Console — напрямую через subprocess.run.
👨‍💻 БЛОК КОДА: ДИПСИК (ГОТОВ К КОПИРОВАНИЮ)
⚠️ ПРОМПТЕР: НЕ РЕЗАТЬ КОДОВЫЕ БЛОКИ. Передавать целиком.
🔹 1. app2.py — Удаление легаси + новый эндпоинт
python
# === УДАЛИТЬ ВСЕ УПОМИНАНИЯ ===
# - @app.websocket("/ws/console") или аналогичные сокеты
# - Вызовы websockets.connect для кнопок "console>_" / "консилиум"
# - Функции launch_gemini_process, gemini_sockets, app.state.gemini_sockets
# - Импорт websockets, если не используется больше нигде

# === ДОБАВИТЬ В ИМПОРТЫ (в начало файла) ===
import os
import shlex
import subprocess
from pathlib import Path
from typing import Literal, Optional

from core.gemini_cli_executor import execute
from core.prompt_registry import PromptRegistry
from core.project_context import ProjectContext
from core.model_management import ModelManager
from integrations.openrouter_adapter import OpenRouterModel

# === НОВЫЙ ЭНДПОИНТ: /api/admin_click (универсальный для всех кнопок) ===
@app.route('/api/admin_click', methods=['POST'])
async def handle_admin_click():
    """Универсальный обработчик кликов по кнопкам Админа"""
    data = await request.get_json()
    button = data.get('button')  # ">", "audit", "chief", "ceo", "symposium"
    message = data.get('message', '')
    
    ctx = ProjectContext.get_instance()
    project_path = str(ctx.get_current_project_path()) if ctx.get_current_project_path() else None
    
    # === МАРШРУТИЗАЦИЯ ПО КНОПКАМ ===
    
    # 🔹 КНОПКА ">": Console — ПРЯМОЙ SUBPROCESS (НЕ execute!)
    if button == ">":
        # Whitelist безопасных системных команд
        SAFE_CMDS = {"dir", "ls", "cd", "pwd", "cat", "type", "echo", "whoami", "git", "python", "pip"}
        cmd_parts = shlex.split(message) if message else []
        base_cmd = cmd_parts[0] if cmd_parts else ""
        
        if base_cmd in SAFE_CMDS:
            try:
                result = subprocess.run(
                    cmd_parts,
                    capture_output=True,
                    text=True,
                    timeout=30,
                    cwd=project_path if project_path else None
                )
                response = result.stdout if result.returncode == 0 else f"[Error {result.returncode}]: {result.stderr}"
            except Exception as e:
                response = f"[System Error]: {e}"
        else:
            # Для не-whitelisted команд — эхо с предупреждением (dev-mode)
            response = f"[Console] Команда '{base_cmd}' не в whitelist. Выполнение запрещено в production."
        
        return jsonify({"response": response, "button": button, "mode": "console"})
    
    # 🔹 КНОПКА "Аудит": Admin (auditor) + OpenRouter fallback
    elif button == "audit":
        # 1. Сначала вызов Админа (режим auditor, scope=models)
        admin_response = await execute(
            mode="auditor",
            scope="models",
            message=message,
            project_path=project_path,
            timeout=30
        )
        # 2. Fallback/дополнение через OpenRouter consultant_medical
        try:
            consultant = OpenRouterModel(
                model_id="anthropic/claude-3-haiku",  # или из конфига
                api_key=os.getenv("OPENROUTER_API_KEY")
            )
            consultant_prompt = PromptRegistry.get_prompt("consultant_medical", project_path=project_path)
            consultant_response = await consultant.generate(
                prompt=f"{consultant_prompt}\n\nЗапрос: {message}\n\nОтвет Админа: {admin_response}",
                system_prompt=None,
                max_tokens=512
            )
            response = f"{admin_response}\n\n[Consultant]:\n{consultant_response}"
        except Exception as e:
            response = admin_response  # fallback только на Админа
            # Логировать ошибку, но не прерывать ответ
            app.logger.warning(f"[AUDIT] Consultant fallback failed: {e}")
            
        return jsonify({"response": response, "button": button, "mode": "admin_auditor"})
    
    # 🔹 КНОПКА "ШЕФ": Local Chief + Secretary pre-processing
    elif button == "chief":
        system_prompt = PromptRegistry.get_prompt("chief", project_path=project_path)
        
        # Предварительная обработка [TASK]/[INFO] через Секретаря (опционально)
        if "[TASK]" in message or "[INFO]" in message:
            secretary_response = await execute(
                mode="secretary",
                for_role="chief",
                message=message,
                project_path=project_path,
                timeout=20
            )
            # Секретарь возвращает уточнённый запрос или вопросы
            message = f"{secretary_response}\n\nOriginal user message: {message}"
        
        # Вызов локальной модели Шефа
        mm = ModelManager()  # В будущем: singleton / cached instance
        chief_model = await mm.get_model("chief")
        response = await chief_model.generate(prompt=message, system_prompt=system_prompt)
        
        return jsonify({"response": response, "button": button, "mode": "local_chief"})
    
    # 🔹 КНОПКА "СЕО": Local CEO + Secretary pre-processing
    elif button == "ceo":
        system_prompt = PromptRegistry.get_prompt("ceo", project_path=project_path)
        
        if "[TASK]" in message or "[INFO]" in message:
            secretary_response = await execute(
                mode="secretary",
                for_role="ceo",
                message=message,
                project_path=project_path,
                timeout=20
            )
            message = f"{secretary_response}\n\nOriginal user message: {message}"
        
        mm = ModelManager()
        ceo_model = await mm.get_model("ceo")
        response = await ceo_model.generate(prompt=message, system_prompt=system_prompt)
        
        return jsonify({"response": response, "button": button, "mode": "local_ceo"})
    
    # 🔹 КНОПКА "Симпозиум": Composite Flow (Auditor + CEO + Strategic Consultant)
    elif button == "symposium":
        # 1. Аудит решений
        auditor_response = await execute(
            mode="auditor",
            scope="decisions",
            message=message,
            project_path=project_path,
            timeout=30
        )
        # 2. Мнение СЕО
        ceo_prompt = PromptRegistry.get_prompt("ceo", project_path=project_path)
        mm = ModelManager()
        ceo_model = await mm.get_model("ceo")
        ceo_response = await ceo_model.generate(
            prompt=f"{auditor_response}\n\nВопрос: {message}",
            system_prompt=ceo_prompt
        )
        # 3. Стратегический консультант (OpenRouter) — оркестрация
        try:
            consultant = OpenRouterModel(
                model_id="nousresearch/hermes-3-llama-3.1-405b",
                api_key=os.getenv("OPENROUTER_API_KEY")
            )
            consultant_prompt = PromptRegistry.get_prompt("consultant_strategic", project_path=project_path)
            consultant_response = await consultant.generate(
                prompt=f"{consultant_prompt}\n\nКонтекст:\n- Аудит: {auditor_response}\n- СЕО: {ceo_response}\n\nЗапрос: {message}",
                max_tokens=512
            )
            response = f"[Auditor]:\n{auditor_response}\n\n[CEO]:\n{ceo_response}\n\n[Strategic Consultant]:\n{consultant_response}"
        except Exception as e:
            response = f"[Auditor]:\n{auditor_response}\n\n[CEO]:\n{ceo_response}"
            app.logger.warning(f"[SYMPOSIUM] Consultant fallback failed: {e}")
        
        return jsonify({"response": response, "button": button, "mode": "composite_symposium"})
    
    else:
        return jsonify({"error": f"Unknown button: {button}"}), 400
# === УДАЛИТЬ ВСЕ УПОМИНАНИЯ ===# - @app.websocket("/ws/console") или аналогичные сокеты# - Вызовы websockets.connect для кнопок "console>_" / "консилиум"# - Функции launch_gemini_process, gemini_sockets, app.state.gemini_sockets# - Импорт websockets, если не используется больше нигде# === ДОБАВИТЬ В ИМПОРТЫ (в начало файла) ===import osimport shleximport subprocessfrom pathlib import Pathfrom typing import Literal, Optionalfrom core.gemini_cli_executor import executefrom core.prompt_registry import PromptRegistryfrom core.project_context import ProjectContextfrom core.model_management import ModelManagerfrom integrations.openrouter_adapter import OpenRouterModel# === НОВЫЙ ЭНДПОИНТ: /api/admin_click (универсальный для всех кнопок) ===@app.route('/api/admin_click', methods=['POST'])async def handle_admin_click():    """Универсальный обработчик кликов по кнопкам Админа"""    data = await request.get_json()    button = data.get('button')  # ">", "audit", "chief", "ceo", "symposium"    message = data.get('message', '')        ctx = ProjectContext.get_instance()    project_path = str(ctx.get_current_project_path()) if ctx.get_current_project_path() else None        # === МАРШРУТИЗАЦИЯ ПО КНОПКАМ ===        # 🔹 КНОПКА ">": Console — ПРЯМОЙ SUBPROCESS (НЕ execute!)    if button == ">":        # Whitelist безопасных системных команд        SAFE_CMDS = {"dir", "ls", "cd", "pwd", "cat", "type", "echo", "whoami", "git", "python", "pip"}        cmd_parts = shlex.split(message) if message else []        base_cmd = cmd_parts[0] if cmd_parts else ""                if base_cmd in SAFE_CMDS:            try:                result = subprocess.run(                    cmd_parts,                    capture_output=True,                    text=True,                    timeout=30,                    cwd=project_path if project_path else None                )                response = result.stdout if result.returncode == 0 else f"[Error {result.returncode}]: {result.stderr}"            except Exception as e:                response = f"[System Error]: {e}"        else:            # Для не-whitelisted команд — эхо с предупреждением (dev-mode)            response = f"[Console] Команда '{base_cmd}' не в whitelist. Выполнение запрещено в production."                return jsonify({"response": response, "button": button, "mode": "console"})        # 🔹 КНОПКА "Аудит": Admin (auditor) + OpenRouter fallback    elif button == "audit":        # 1. Сначала вызов Админа (режим auditor, scope=models)        admin_response = await execute(            mode="auditor",            scope="models",            message=message,            project_path=project_path,            timeout=30        )        # 2. Fallback/дополнение через OpenRouter consultant_medical        try:            consultant = OpenRouterModel(                model_id="anthropic/claude-3-haiku",  # или из конфига                api_key=os.getenv("OPENROUTER_API_KEY")            )            consultant_prompt = PromptRegistry.get_prompt("consultant_medical", project_path=project_path)            consultant_response = await consultant.generate(                prompt=f"{consultant_prompt}\n\nЗапрос: {message}\n\nОтвет Админа: {admin_response}",                system_prompt=None,                max_tokens=512            )            response = f"{admin_response}\n\n[Consultant]:\n{consultant_response}"        except Exception as e:            response = admin_response  # fallback только на Админа            # Логировать ошибку, но не прерывать ответ            app.logger.warning(f"[AUDIT] Consultant fallback failed: {e}")                    return jsonify({"response": response, "button": button, "mode": "admin_auditor"})        # 🔹 КНОПКА "ШЕФ": Local Chief + Secretary pre-processing    elif button == "chief":        system_prompt = PromptRegistry.get_prompt("chief", project_path=project_path)                # Предварительная обработка [TASK]/[INFO] через Секретаря (опционально)        if "[TASK]" in message or "[INFO]" in message:            secretary_response = await execute(                mode="secretary",                for_role="chief",                message=message,                project_path=project_path,                timeout=20            )            # Секретарь возвращает уточнённый запрос или вопросы            message = f"{secretary_response}\n\nOriginal user message: {message}"                # Вызов локальной модели Шефа        mm = ModelManager()  # В будущем: singleton / cached instance        chief_model = await mm.get_model("chief")        response = await chief_model.generate(prompt=message, system_prompt=system_prompt)                return jsonify({"response": response, "button": button, "mode": "local_chief"})        # 🔹 КНОПКА "СЕО": Local CEO + Secretary pre-processing    elif button == "ceo":        system_prompt = PromptRegistry.get_prompt("ceo", project_path=project_path)                if "[TASK]" in message or "[INFO]" in message:            secretary_response = await execute(                mode="secretary",                for_role="ceo",                message=message,                project_path=project_path,                timeout=20            )            message = f"{secretary_response}\n\nOriginal user message: {message}"                mm = ModelManager()        ceo_model = await mm.get_model("ceo")        response = await ceo_model.generate(prompt=message, system_prompt=system_prompt)                return jsonify({"response": response, "button": button, "mode": "local_ceo"})        # 🔹 КНОПКА "Симпозиум": Composite Flow (Auditor + CEO + Strategic Consultant)    elif button == "symposium":        # 1. Аудит решений        auditor_response = await execute(            mode="auditor",            scope="decisions",            message=message,            project_path=project_path,            timeout=30        )        # 2. Мнение СЕО        ceo_prompt = PromptRegistry.get_prompt("ceo", project_path=project_path)        mm = ModelManager()        ceo_model = await mm.get_model("ceo")        ceo_response = await ceo_model.generate(            prompt=f"{auditor_response}\n\nВопрос: {message}",            system_prompt=ceo_prompt        )        # 3. Стратегический консультант (OpenRouter) — оркестрация        try:            consultant = OpenRouterModel(                model_id="nousresearch/hermes-3-llama-3.1-405b",                api_key=os.getenv("OPENROUTER_API_KEY")            )            consultant_prompt = PromptRegistry.get_prompt("consultant_strategic", project_path=project_path)            consultant_response = await consultant.generate(                prompt=f"{consultant_prompt}\n\nКонтекст:\n- Аудит: {auditor_response}\n- СЕО: {ceo_response}\n\nЗапрос: {message}",                max_tokens=512            )            response = f"[Auditor]:\n{auditor_response}\n\n[CEO]:\n{ceo_response}\n\n[Strategic Consultant]:\n{consultant_response}"        except Exception as e:            response = f"[Auditor]:\n{auditor_response}\n\n[CEO]:\n{ceo_response}"            app.logger.warning(f"[SYMPOSIUM] Consultant fallback failed: {e}")                return jsonify({"response": response, "button": button, "mode": "composite_symposium"})        else:        return jsonify({"error": f"Unknown button: {button}"}), 400
🔹 2. static/js/chat.js — Обновление обработчика кликов
javascript
// === ЗАМЕНИТЬ ОБРАБОТЧИКИ КНОПОК ===
// Было: отправка на /ws/console или /api/audit через сокеты
// Стало: отправка на /api/admin_click

document.querySelectorAll('.admin-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
        const button = btn.getAttribute('data-button'); // ">", "audit", "chief", "ceo", "symposium"
        const message = userInput.value.trim();
        if (!message) return;
        
        appendMessage('user', message);
        userInput.value = '';
        
        try {
            const res = await fetch('/api/admin_click', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ button, message })
            });
            const data = await res.json();
            if (data.response) {
                appendMessage('admin', data.response, { button: data.button, mode: data.mode });
            } else {
                appendMessage('error', data.error || 'Ошибка');
            }
        } catch (err) {
            appendMessage('error', 'Сетевая ошибка');
        }
    });
});

📋 ИНСТРУКЦИИ ДЛЯ САМУРАЯ (YAML-СТИЛЬ, БЕЗ ВОДЫ)
yaml
# Формат: строго, по шагам, без догадок

task:
  name: "UI Button Remap + CLI Executor Integration"
  priority: "MEDIUM"
  executors: ["Dipsik (code)", "Samurai (integration)"]

steps:
  - id: 1
    action: "Удалить легаси-код"
    files:
      - "app2.py"
    details:
      - "Удалить @app.websocket для 'console>_' / 'консилиум'"
      - "Удалить функции launch_gemini_process, gemini_sockets"
      - "Удалить импорт websockets, если не используется"
      - "Закомментировать, не удалять: agent_orchestrator.py, gemini_mcp_server.py"

  - id: 2
    action: "Добавить новый эндпоинт /api/admin_click"
    files:
      - "app2.py"
    details:
      - "Скопировать код handle_admin_click() из блока Дипсика"
      - "Добавить импорты: os, shlex, subprocess, PromptRegistry, ProjectContext, execute, ModelManager, OpenRouterModel"
      - "Убедиться, что Console (button='>') использует subprocess.run, НЕ execute()"
      - "Проверить whitelist команд для Console"

  - id: 3
    action: "Обновить frontend"
    files:
      - "static/js/chat.js"
    details:
      - "Заменить обработчики кнопок на fetch('/api/admin_click')"
      - "Убедиться, что кнопки имеют data-button='>', 'audit', 'chief', 'ceo', 'symposium'"

  - id: 4
    action: "Протестировать"
    tests:
      - name: "test_console_system_cmd"
        command: "curl -X POST http://127.0.0.1:5000/api/admin_click -H 'Content-Type: application/json' -d '{\"button\": \">\", \"message\": \"dir\"}'"
        expected: "Ответ с выводом команды или предупреждение"
      - name: "test_audit_button"
        command: "curl -X POST ... -d '{\"button\": \"audit\", \"message\": \"Проверь промпты\"}'"
        expected: "Ответ от Админа + возможно консультанта"
      - name: "test_legacy_removed"
        command: "grep -r 'websockets.connect\\|launch_agents' AIColab/app2.py"
        expected: "0 активных совпадений (только в комментариях)"

  - id: 5
    action: "Вернуть отчёт"
    format:
      status: "READY_FOR_REVIEW | BLOCKED"
      legacy_removed: "YES/NO"
      new_endpoint_added: "YES/NO"
      frontend_updated: "YES/NO"
      test_console: "WORKS/BROKEN"
      test_audit: "WORKS/BROKEN"
      error_if_blocked: "<описание + строка кода>"

forbidden:
  - "Не менять логику для сотрудников (flick/flock/etc.)"
  - "Не трогать роуты /api/chat, /api/secretary"
  - "Не рефакторить ModelManager или PromptRegistry"
  - "Не использовать execute() для Console"
  - "Не удалять старые файлы, только комментировать"

notes_for_prompter:
  - "НЕ РЕЗАТЬ КОДОВЫЕ БЛОКИ. Передавать целиком."
  - "Сохранять отступы и форматирование Python/JS."
  - "Не добавлять пояснения внутрь кода — только в отдельные блоки."

🧪 ВСТРОЕННЫЕ ТЕСТЫ (ДЛЯ БЫСТРОЙ ПРОВЕРКИ)
bash
# Тест 1: Консоль (">") — системная команда
curl -X POST http://127.0.0.1:5000/api/admin_click \
  -H "Content-Type: application/json" \
  -d '{"button": ">", "message": "dir"}'
# Ожидаемо: вывод файлов или предупреждение, если не в whitelist

# Тест 2: Аудит
curl -X POST http://127.0.0.1:5000/api/admin_click \
  -H "Content-Type: application/json" \
  -d '{"button": "audit", "message": "Проверь промпты"}'
# Ожидаемо: ответ от Админа + возможно консультанта

# Тест 3: Старая кнопка должна вернуть 404
curl -X POST http://127.0.0.1:5000/api/console \
  -H "Content-Type: application/json" \
  -d '{"message": "test"}'
# Ожидаемо: 404 Not Found

# Тест 4: Проверка импортов
python -c "from core.gemini_cli_executor import execute; from core.prompt_registry import PromptRegistry; print('OK')"
# Ожидаемо: "OK" без ошибок

✅ КРИТЕРИИ ПРИЁМКИ
№	Критерий	Как проверить	Результат
1	Console использует subprocess.run, не execute()	grep -A5 "button == \">\"" app2.py	Вызов subprocess.run, не await execute
2	import os, shlex, subprocess добавлены	grep "^import" app2.py	Все три импорта присутствуют
3	Legacy-сокеты удалены/закомментированы	grep -r "websockets.connect|launch_agents" app2.py	Только в комментариях
4	Новый эндпоинт /api/admin_click работает	curl ... /api/admin_click ...	JSON-ответ с response
5	Frontend отправляет на /api/admin_click	Проверить static/js/chat.js	fetch('/api/admin_click')
6	Тесты проходят	Запустить 4 теста выше	Все ✅

🏁 ИТОГ
[МИКРО-ПРАВКА: ГОТОВНОСТЬ]
✅ Кнопки: ">" / "Аудит" / "ШЕФ" / "СЕО" / "Симпозиум"
✅ Бэкенд: один эндпоинт /api/admin_click с маршрутизацией
✅ Console: прямой subprocess.run (не execute!)
✅ Frontend: fetch вместо websockets
✅ Легаси: заморожено, не мешает

📌 Примечание для Промптера:
- НЕ резать кодовые блоки — передавать целиком
- Сохранять форматирование — это критично для интеграции
- Пояснения — только в отдельных блоках, не внутри кода

Дипсик → код готов, минимален, копируй-вставляй
Самурай → удали легаси, добавь новое, протестируй, отчитайся
🫡⚔️

🎌 СЕНСЕЙ DEEPSEEK: ИСПРАВЛЕННОЕ ТЗ (SPEC_2026-04-15 v2)

Шёгун, я проверил предоставленный код. В целом он корректен, но есть несколько критических мест, которые нужно исправить, чтобы избежать новых регрессий. Ниже — финальная версия ТЗ с моими правками (выделены [FIX]).

📜 SPEC_2026-04-15: UI BUTTON REMAP + CLI EXECUTOR INTEGRATION (v2)
Статус: ✅ ФИНАЛЬНАЯ ВЕРСИЯ
Критичность: 🟡 СРЕДНЯЯ
Исполнители: Дипсик (код) → Самурай (интеграция)

🔧 КЛЮЧЕВЫЕ ИСПРАВЛЕНИЯ (ЧТО ПОМЕНЯЛ)
№	Проблема в исходном ТЗ	Исправление
1	ModelManager() создаётся каждый раз заново в обработчиках chief/ceo/symposium	Использовать глобальный экземпляр app.model_manager (уже инициализирован при старте)
2	ProjectContext.get_instance() не асинхронный, но в Quart нужна инициализация	Добавить await ensure_project_initialized() перед использованием
3	В subprocess.run для Windows команда dir не работает без shell=True	Добавить shell=True при os.name == 'nt'
4	Отсутствует обработка ошибок для execute() (таймаут, падение)	Уже есть внутри execute(), но добавить логирование
5	Не хватает импорта app (для app.logger)	Добавить импорт или использовать logging.getLogger()
👨‍💻 БЛОК КОДА: ИСПРАВЛЕННЫЙ app2.py (фрагменты)
1. Добавить в начало файла (после других импортов):

python
import asyncio
import logging
import os
import shlex
import subprocess
from pathlib import Path
from typing import Optional

from quart import Quart, request, jsonify

# ВАЖНО: использовать глобальный app, а не создавать новый
app = Quart(__name__)
logger = logging.getLogger(__name__)

# Импорты из проекта
from core.gemini_cli_executor import execute
from core.prompt_registry import PromptRegistry
from core.project_context import ensure_project_initialized, get_current_project_path
from core.model_management import ModelManager
from integrations.openrouter_adapter import OpenRouterModel

# Глобальные менеджеры (инициализируются в startup)
model_manager = None

@app.before_serving
async def startup():
    global model_manager
    model_manager = ModelManager()
    await ensure_project_initialized()  # гарантия, что проект загружен
    logger.info("Startup complete, model_manager ready")
2. Исправленный эндпоинт /api/admin_click:

python
@app.route('/api/admin_click', methods=['POST'])
async def handle_admin_click():
    data = await request.get_json()
    button = data.get('button')
    message = data.get('message', '').strip()
    
    # Инициализация контекста проекта
    await ensure_project_initialized()
    project_path = get_current_project_path()
    
    # --- КНОПКА ">" : Консоль ---
    if button == ">":
        # Белый список безопасных команд
        SAFE_CMDS = {"dir", "ls", "cd", "pwd", "cat", "type", "echo", "whoami", "git", "python", "pip"}
        cmd_parts = shlex.split(message) if message else []
        base_cmd = cmd_parts[0] if cmd_parts else ""
        
        if base_cmd in SAFE_CMDS:
            try:
                # Для Windows команда dir требует shell=True
                use_shell = (os.name == 'nt' and base_cmd == 'dir')
                result = subprocess.run(
                    cmd_parts if not use_shell else message,
                    capture_output=True,
                    text=True,
                    timeout=30,
                    cwd=project_path if project_path else None,
                    shell=use_shell
                )
                response = result.stdout if result.returncode == 0 else f"[Error {result.returncode}]: {result.stderr}"
            except subprocess.TimeoutExpired:
                response = "[Timeout] Команда выполнялась слишком долго"
            except Exception as e:
                response = f"[System Error]: {e}"
        else:
            response = f"[Console] Команда '{base_cmd}' не в whitelist."
        return jsonify({"response": response, "button": button, "mode": "console"})
    
    # --- КНОПКА "Аудит" ---
    elif button == "audit":
        admin_response = await execute(
            mode="auditor",
            scope="models",
            message=message,
            project_path=project_path,
            timeout=30
        )
        # Fallback через OpenRouter (опционально)
        try:
            consultant = OpenRouterModel(
                model_id="anthropic/claude-3-haiku",
                api_key=os.getenv("OPENROUTER_API_KEY")
            )
            consultant_prompt = PromptRegistry.get_prompt("consultant_medical", project_path=project_path)
            consultant_response = await consultant.generate(
                prompt=f"{consultant_prompt}\n\nЗапрос: {message}\n\nОтвет Админа: {admin_response}",
                max_tokens=512
            )
            response = f"{admin_response}\n\n[Consultant]:\n{consultant_response}"
        except Exception as e:
            logger.warning(f"[AUDIT] Consultant fallback failed: {e}")
            response = admin_response
        return jsonify({"response": response, "button": button, "mode": "admin_auditor"})
    
    # --- КНОПКА "ШЕФ" ---
    elif button == "chief":
        system_prompt = PromptRegistry.get_prompt("chief", project_path=project_path)
        # Предобработка [TASK]/[INFO] через секретаря
        if "[TASK]" in message or "[INFO]" in message:
            secretary_response = await execute(
                mode="secretary",
                for_role="chief",
                message=message,
                project_path=project_path,
                timeout=20
            )
            message = f"{secretary_response}\n\nOriginal user message: {message}"
        # Используем глобальный model_manager
        chief_model = await model_manager.get_model("chief")
        response = await chief_model.generate(prompt=message, system_prompt=system_prompt)
        return jsonify({"response": response, "button": button, "mode": "local_chief"})
    
    # --- КНОПКА "СЕО" ---
    elif button == "ceo":
        system_prompt = PromptRegistry.get_prompt("ceo", project_path=project_path)
        if "[TASK]" in message or "[INFO]" in message:
            secretary_response = await execute(
                mode="secretary",
                for_role="ceo",
                message=message,
                project_path=project_path,
                timeout=20
            )
            message = f"{secretary_response}\n\nOriginal user message: {message}"
        ceo_model = await model_manager.get_model("ceo")
        response = await ceo_model.generate(prompt=message, system_prompt=system_prompt)
        return jsonify({"response": response, "button": button, "mode": "local_ceo"})
    
    # --- КНОПКА "Симпозиум" ---
    elif button == "symposium":
        # 1. Аудит решений
        auditor_response = await execute(
            mode="auditor",
            scope="decisions",
            message=message,
            project_path=project_path,
            timeout=30
        )
        # 2. Мнение СЕО
        ceo_prompt = PromptRegistry.get_prompt("ceo", project_path=project_path)
        ceo_model = await model_manager.get_model("ceo")
        ceo_response = await ceo_model.generate(
            prompt=f"{auditor_response}\n\nВопрос: {message}",
            system_prompt=ceo_prompt
        )
        # 3. Стратегический консультант
        try:
            consultant = OpenRouterModel(
                model_id="nousresearch/hermes-3-llama-3.1-405b:free",  # [FIX] бесплатная версия
                api_key=os.getenv("OPENROUTER_API_KEY")
            )
            consultant_prompt = PromptRegistry.get_prompt("consultant_strategic", project_path=project_path)
            consultant_response = await consultant.generate(
                prompt=f"{consultant_prompt}\n\nКонтекст:\n- Аудит: {auditor_response}\n- СЕО: {ceo_response}\n\nЗапрос: {message}",
                max_tokens=512
            )
            response = f"[Auditor]:\n{auditor_response}\n\n[CEO]:\n{ceo_response}\n\n[Strategic Consultant]:\n{consultant_response}"
        except Exception as e:
            logger.warning(f"[SYMPOSIUM] Consultant fallback failed: {e}")
            response = f"[Auditor]:\n{auditor_response}\n\n[CEO]:\n{ceo_response}"
        return jsonify({"response": response, "button": button, "mode": "composite_symposium"})
    
    else:
        return jsonify({"error": f"Unknown button: {button}"}), 400
3. Обновлённый static/js/chat.js (фрагмент):

javascript
// Удаляем старые обработчики WebSocket
// Добавляем новый:
document.querySelectorAll('.admin-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
        const button = btn.getAttribute('data-button');
        const message = document.getElementById('userInput').value.trim();
        if (!message) return;
        
        appendMessage('user', message);
        document.getElementById('userInput').value = '';
        
        try {
            const response = await fetch('/api/admin_click', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ button, message })
            });
            const data = await response.json();
            if (data.response) {
                appendMessage('admin', data.response, { button: data.button, mode: data.mode });
            } else {
                appendMessage('error', data.error || 'Unknown error');
            }
        } catch (err) {
            appendMessage('error', 'Network error');
        }
    });
});
📋 ПОШАГОВЫЙ ПЛАН ДЛЯ САМУРАЯ (YAML)
yaml
steps:
  - id: 0
    action: "Откатить репозиторий до последнего стабильного коммита (уже сделано)"
    
  - id: 1
    action: "Удалить легаси WebSocket код из app2.py"
    files: ["app2.py"]
    details:
      - "Удалить все @app.websocket декораторы"
      - "Удалить функции launch_agents, terminate_agents"
      - "Удалить импорты websockets, agent_orchestrator"
      - "Закомментировать (не удалять) agent_orchestrator.py, gemini_mcp_server.py"

  - id: 2
    action: "Добавить глобальную инициализацию менеджеров в @app.before_serving"
    files: ["app2.py"]
    details:
      - "Скопировать блок startup() из исправленного кода выше"
      - "Добавить глобальную переменную model_manager"

  - id: 3
    action: "Добавить эндпоинт /api/admin_click"
    files: ["app2.py"]
    details:
      - "Скопировать функцию handle_admin_click() из исправленного кода"
      - "Убедиться, что все импорты добавлены"

  - id: 4
    action: "Обновить frontend (chat.js)"
    files: ["static/js/chat.js"]
    details:
      - "Заменить старые обработчики кнопок на новый fetch('/api/admin_click')"
      - "Добавить класс .admin-btn и data-button к каждой кнопке в index.html (если ещё нет)"

  - id: 5
    action: "Протестировать"
    tests:
      - "curl -X POST http://127.0.0.1:5000/api/admin_click -d '{\"button\":\">\",\"message\":\"dir\"}'"
      - "curl -X POST ... -d '{\"button\":\"audit\",\"message\":\"test\"}'"
      - "curl -X POST ... -d '{\"button\":\"chief\",\"message\":\"[TASK] план\"}'"
      - "Убедиться, что старые сокет-эндпоинты возвращают 404"

  - id: 6
    action: "Отчитаться"
    format:
      status: "READY"
      legacy_removed: YES
      new_endpoint_works: YES
      console_cmd_works: YES
      frontend_updated: YES
🧪 БЫСТРЫЕ ТЕСТЫ (скопировать и выполнить)
bash
# Тест 1: Консоль
curl -X POST http://127.0.0.1:5000/api/admin_click -H "Content-Type: application/json" -d "{\"button\": \">\", \"message\": \"dir\"}"

# Тест 2: Аудит
curl -X POST http://127.0.0.1:5000/api/admin_click -H "Content-Type: application/json" -d "{\"button\": \"audit\", \"message\": \"Проверь промпты\"}"

# Тест 3: ШЕФ
curl -X POST http://127.0.0.1:5000/api/admin_click -H "Content-Type: application/json" -d "{\"button\": \"chief\", \"message\": \"[TASK] Напиши план\"}"

# Тест 4: Старый сокет (должен вернуть 404)
curl -X POST http://127.0.0.1:5000/api/console -H "Content-Type: application/json" -d "{\"message\": \"test\"}"
✅ КРИТЕРИИ ПРИЁМКИ
После запуска сервера нет ошибок импорта Optional или NameError.
Консоль (>) выполняет dir и выводит список файлов (или предупреждение, если команда не в whitelist).
Кнопка "Аудит" возвращает ответ (даже если fallback).
ШЕФ и СЕО отвечают с использованием локальных моделей.
Симпозиум возвращает композитный ответ.
В логах нет сообщений о websockets или launch_agents.
Фронтенд отправляет запросы на /api/admin_click, а не на сокеты.
Самурай, действуй строго по шагам. Если что-то идёт не так — остановись и покажи мне ошибку. 🎌

