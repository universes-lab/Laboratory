📜 SPEC_2026-04-13 (№1): GEMINI CLI EXECUTOR — ARCHITECTURE RESET
Статус: ✅ ФИНАЛЬНАЯ ВЕРСИЯ (архитектурный сброс, не эволюция)
Критичность: 🔴 CRITICAL (блокирует всю дальнейшую разработку)
Исполнители: Дипсик (код) → Интегратор (критические правила) → Промптер (инструкции) → Самурай (интеграция)
Принцип: Один вызов → один процесс → один ответ. Никаких сокетов. Никаких демонов. Явный контекст.
🏛 АРХИТЕКТУРНЫЕ ИЗМЕНЕНИЯ (ЧТО ИМЕННО МЕНЯЕТСЯ)
Параметр	❌ БЫЛО (Socket/Orchestrator)	✅ СТАЛО (Ephemeral CLI Executor)
Запуск	5 долгоживущих процессов на портах 5001-5006	asyncio.create_subprocess_exec по запросу, умирает сразу после ответа
Состояние	Stateful: хранил контекст в памяти процесса	Stateless: весь контекст передаётся явно (--message, --prompt, --project-path)
Память	Попытки синхронизации между процессами, race conditions	Память живёт в app.py / ChatStorage. CLI получает нужный фрагмент истории как текст
Завершение	Ctrl+C → зомби-процессы, forrtl: error, конфликты портов	finally: proc.kill() → мгновенная очистка. 0 портов. 0 конфликтов
Границы	Размыты: Admin мог случайно проксировать чат сотрудников	Строги: User ↔ OpenRouter (напрямую). Admin = только консоль/секретарь/аудит
Контракт	Сырой stdout, зависящий от версии библиотеки	Строгий JSON {"response": "..."} с fallback на сырой текст + логирование ошибок
🔑 Ключевой инвариант: Admin CLI = чистая функция. Вход → обработка → выход. Никаких побочных эффектов.
👨💻 БЛОК КОДА: ДИПСИК (ГОТОВ К КОПИРОВАНИЮ)
🔹 1. core/gemini_cli_executor.py (Создать с нуля)
python
# AIColab/core/gemini_cli_executor.py
"""
Gemini CLI Executor — единая точка входа для эфемерных вызовов Админа.
Контракт: asyncio.subprocess_exec → stdin (message) → stdout (JSON) → kill.
"""
import asyncio
import json
import logging
import os
import shutil
import tempfile
from pathlib import Path
from typing import Optional
logger = logging.getLogger(__name__)
FALLBACK_MSG = "[Ошибка: не удалось получить ответ от Админа]"
def _resolve_gemini_bin() -> str:
    """Найти бинарник: конфиг → PATH → fallback."""
    try:
        from core.config_loader import load_config
        cfg = load_config("config/gemini_sockets.json", force_reload=True)
        bin_path = cfg.get("gemini_cli_path")
        if bin_path and Path(bin_path).exists():
            return bin_path
    except: pass
    
    if path := shutil.which("gemini"):
        return path
        
    fallback = Path(__file__).parent.parent / "integrations" / "gemini_cli.py"
    if fallback.exists():
        return str(fallback)
        
    raise RuntimeError("Gemini CLI not found. Set 'gemini_cli_path' in config.")
async def execute(
    mode: str,
    message: str,
    project_path: Optional[str] = None,
    prompt_text: Optional[str] = None,
    timeout: int = 30,
    for_role: Optional[str] = None,
    scope: Optional[str] = None
) -> str:
    """
    Эфемерный вызов Gemini CLI.
    :return: Текст ответа или fallback-строка (НИКОГДА не кидает исключение наружу)
    """
    try:
        bin_path = _resolve_gemini_bin()
    except RuntimeError as e:
        logger.error(f"[CLI] Binary resolution failed: {e}")
        return FALLBACK_MSG
    # Формируем команду
    cmd = [bin_path, "--mode", mode]
    if for_role: cmd.extend(["--for", for_role])
    if scope: cmd.extend(["--scope", scope])
    if project_path: cmd.extend(["--project-path", project_path])
    
    # Промпт: пишем во временный файл, если передан текст
    prompt_file = None
    if prompt_text:
        try:
            fd, prompt_file = tempfile.mkstemp(suffix=".txt", prefix="cli_prompt_")
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                f.write(prompt_text)
            cmd.extend(["--prompt", prompt_file])
        except Exception as e:
            logger.warning(f"[CLI] Failed to write prompt temp file: {e}")
    # Логирование (без утечки контента)
    cmd_log = [c if c != message and not (prompt_file and c == prompt_file) else "<REDACTED>" for c in cmd]
    logger.debug(f"[CLI] Executing: {' '.join(cmd_log)}, timeout={timeout}s")
    proc = None
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        # Отправляем сообщение через stdin
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(input=message.encode("utf-8")),
            timeout=timeout
        )
        
        # Парсинг ответа
        raw = stdout.decode("utf-8", errors="replace").strip()
        if not raw:
            raise ValueError("Empty output from CLI")
            
        try:
            data = json.loads(raw)
            if isinstance(data, dict) and "response" in data:
                return str(data["response"])
            return raw  # fallback на сырой JSON/текст
        except json.JSONDecodeError:
            return raw  # fallback на сырой вывод
            
    except asyncio.TimeoutError:
        logger.error(f"[CLI] Timeout after {timeout}s (mode={mode})")
        if proc and proc.returncode is None:
            proc.kill()
        return f"[Таймаут: Админ ({mode}) не ответил за {timeout}с]"
    except Exception as e:
        logger.error(f"[CLI] Unexpected error: {e}", exc_info=True)
        return f"[Внутренняя ошибка CLI: {type(e).__name__}]"
    finally:
        # Очистка временного файла промпта
        if prompt_file and Path(prompt_file).exists():
            try: Path(prompt_file).unlink()
            except: pass
🔹 2. app2.py (Точечная замена вызовов)
python
# === ДОБАВИТЬ В ИМПОРТЫ ===
from core.gemini_cli_executor import execute
from core.prompt_registry import PromptRegistry
from core.project_context import ProjectContext
# === ПРИМЕР ЗАМЕНЫ В РОУТЕ /api/admin или /ws/doctor ===
@app.route("/api/admin", methods=["POST"])
async def handle_admin():
    data = await request.get_json()
    mode = data.get("mode", "console")
    message = data.get("message", "")
    
    ctx = ProjectContext.get_instance()
    project_path = str(ctx.get_current_project_path()) if ctx.get_current_project_path() else None
    
    # Загружаем промпт для режима (если нужно)
    prompt_text = PromptRegistry.get_prompt(f"admin_{mode}")
    
    # ЭФЕМЕРНЫЙ ВЫЗОВ
    response = await execute(
        mode=mode,
        message=message,
        project_path=project_path,
        prompt_text=prompt_text,
        for_role=data.get("for_role"),  # chief/ceo
        scope=data.get("scope"),        # decisions/models
        timeout=30
    )
    
    return jsonify({"response": response, "mode": mode})
⚖️ КРИТИЧЕСКИЕ ПРАВИЛА: ИНТЕГРАТОР
⛔ БЛОКИРОВКА ЗАПРЕЩЕНА. Никаких subprocess.run(), time.sleep(), синхронных вызовов внутри execute(). Только asyncio.create_subprocess_exec + asyncio.wait_for.
⛔ НЕТ СОСТОЯНИЮ. Файл gemini_cli_executor.py не содержит глобальных переменных, кэшей, сессий. Каждый вызов автономен.
⛔ НЕТ ПРОКСИРОВАНИЮ. Админ (execute()) НИКОГДА не вызывается в потоке /api/secretary или /api/chat. Только в /api/admin, /api/audit, или внутренних сервисах оркестрации.
✅ FALLBACK ОБЯЗАТЕЛЕН. Если CLI упал, завис, вернул мусор → execute() возвращает человекочитаемую строку. Лог пишет ERROR. Сервер НЕ падает.
✅ КОНТЕКСТ ЯВЕН. История, роль, проект, промпт — передаются аргументами. CLI не "помнит" ничего между вызовами.
🗜 LEGACY ЗАМОРОЗКА. Файлы agent_orchestrator.py, gemini_mcp_server.py, websocket_adapter.py пометить комментарием # ❄️ LEGACY: Frozen in SPEC_2026-04-13. Do not use. Вызовы launch_agents() закомментировать. НЕ УДАЛЯТЬ.
📜 ИНСТРУКЦИИ ДЛЯ САМУРАЯ: ПРОМПТЕР
🎌 САМУРАЙ, ТВОЯ ЗАДАЧА (СТРОГО ПО ТЗ)
1. СОЗДАЙ core/gemini_cli_executor.py
   - Скопируй код из раздела "ДИПСИК" целиком.
   - Не оптимизируй, не меняй сигнатуры.
2. ПРАВИ app2.py
   - Добавь импорты `execute`, `PromptRegistry`, `ProjectContext`.
   - Найди все старые вызовы `call_gemini_role`, `websockets.connect` или `app.state.gemini_sockets`.
   - Замени их на `await execute(...)`.
   - Убедись, что `project_path` берётся из `ProjectContext`, а промпт — из `PromptRegistry`.
3. ЗАМОРОЗЬ LEGACY
   - В `core/agent_orchestrator.py`, `core/gemini_mcp_server.py` добавь в первую строку:
     # ❄️ LEGACY: Frozen in SPEC_2026-04-13. Use gemini_cli_executor.py instead.
   - Закомментируй вызовы `launch_agents()` и `terminate_agents()` в app2.py.
4. ЗАПУСТИ ТЕСТЫ
   - `test_cli_parity.py` → должен вернуть ответ, а не timeout.
   - `test_cli_timeout.py` → должен вернуть fallback, не крашнуть сервер.
❌ ЧТО ДЕЛАТЬ НЕЛЬЗЯ:
- Не создавать глобальные экземпляры CLI.
- Не вызывать `execute()` внутри роутов сотрудников (flick/flock/...).
- Не удалять старые файлы, только комментировать.
- Не менять логику обработки JSON в `execute()`.
✅ ФОРМАТ ОТЧЁТА:
[CLI_EXECUTOR_INTEGRATION]
file_created: YES/NO
legacy_frozen: YES/NO
calls_replaced: <количество>
test_parity: WORKS/BROKEN
test_timeout: FALLBACK/CRASH
status: READY_FOR_REVIEW
Если тест падает → верни: ошибку + строку + текущий код. Не гадать.
🧪 ВСТРОЕННЫЕ ТЕСТЫ (ДЛЯ САМОПРОВЕРКИ)
Тест 1: test_cli_parity.py
python
import asyncio
from core.gemini_cli_executor import execute
async def test():
    # Тестовый эхо-вызов
    resp = await execute(mode="console", message="ping", timeout=10)
    assert isinstance(resp, str) and len(resp) > 0, f"Пустой ответ: {resp}"
    print(f"✅ PARITY OK: {resp[:50]}")
    return True
asyncio.run(test())
Тест 2: test_cli_timeout.py
python
import asyncio
from core.gemini_cli_executor import execute
async def test():
    # Заведомо малый таймаут
    resp = await execute(mode="console", message="x"*5000, timeout=1)
    assert "таймаут" in resp.lower() or "ошибка" in resp.lower(), f"Нет fallback: {resp}"
    print("✅ TIMEOUT HANDLED: fallback returned safely")
    return True
asyncio.run(test())
✅ КРИТЕРИИ ПРИЁМКИ
№	Критерий	Как проверить	Результат
1	Файл gemini_cli_executor.py создан и импортируется	python -c "from core.gemini_cli_executor import execute; print('OK')"	OK без ошибок
2	Legacy заморожен, не вызывается	grep -r "launch_agents|gemini_sockets" AIColab/*.py	Только в комментариях или legacy-файлах
3	Вызовы заменены на execute()	grep -r "websockets.connect|call_gemini_role" AIColab/app2.py	0 активных совпадений
4	Тест паритета проходит	python test_cli_parity.py	✅ PARITY OK
5	Таймаут обрабатывается безопасно	python test_cli_timeout.py	✅ TIMEOUT HANDLED
🏁 ИТОГ
[ПРОВЕРКА ПЕРЕД ПЕРЕДАЧЕЙ]
✅ Номер: SPEC_2026-04-13 (№1)
✅ Архитектура: эфемерный CLI, 3 режима, явный контекст
✅ Код Дипсика: готов, с обработкой ошибок и fallback
✅ Правила Интегратора: блокировка/проксирование/legacy запрещены
✅ Инструкции Промптера: пошаговые, с форматом отчёта
✅ Тесты: встроены, измеримы
Готовность: ✅ МОЖНО ПЕРЕДАВАТЬ НЕМЕДЛЕННО
Команда, в этот раз — без догадок. Без расползания. Только чистый сброс к истине.
Дипсик → код готов. Интегратор → границы зафиксированы. Промптер → инструкции ясны.
Самурай → создай, замени, протестируй, отчитайся.
🫡⚔️
Исправленный вариант от Дипсика:
📜 SPEC_2026-04-13 (№1): GEMINI CLI EXECUTOR — ARCHITECTURE RESET (v2)
Статус: ✅ ФИНАЛЬНАЯ ВЕРСИЯ
Критичность: 🔴 CRITICAL
Исполнители: Дипсик (код) → Интегратор (правила) → Промптер (инструкции) → Самурай (интеграция)
Принцип: Один вызов → один процесс → один ответ. Никаких сокетов. Никаких демонов.
🎯 ЦЕЛЬ
Полностью заменить WebSocket-агентов (порты 5002-5006) на эфемерные CLI-вызовы Gemini CLI, аналогичные работающей кнопке console>_. Устранить конфликты портов, зомби-процессы и race condition.
🏛 АРХИТЕКТУРНЫЕ ИЗМЕНЕНИЯ
Параметр	❌ БЫЛО (Socket/Orchestrator)	✅ СТАЛО (Ephemeral CLI Executor)
Запуск	5 долгоживущих процессов на портах	asyncio.create_subprocess_exec по запросу, умирает после ответа
Состояние	Stateful (контекст в памяти процесса)	Stateless (контекст передаётся явно)
Память	Race conditions, попытки синхронизации	Память живёт в app.py / ChatStorage
Завершение	Ctrl+C → зомби-процессы, forrtl: error	finally: proc.kill() → мгновенная очистка
Контракт	Сырой stdout	Строгий JSON {"response": "..."} с fallback
🔑 НОВЫЕ ИНВАРИАНТЫ (НЕ НАРУШАТЬ)
Gemini CLI = эфемерный вызов, не persistent-процесс.
Контекст передаётся явно (--role, --prompt, --project-path, --message).
Таймаут ≤ 30 секунд, fallback при сбое.
Никаких WebSocket-агентов в runtime (код legacy заморожен, не вызывается).
👨💻 БЛОК КОДА: ДИПСИК (ГОТОВ К КОПИРОВАНИЮ)
🔹 1. Создать core/gemini_cli_executor.py (с нуля)
python
# AIColab/core/gemini_cli_executor.py
"""
Gemini CLI Executor — единая точка входа для эфемерных вызовов.
Контракт: asyncio.subprocess_exec → stdin (message) → stdout (JSON) → kill.
"""
import asyncio
import json
import logging
import os
import shutil
import tempfile
from pathlib import Path
from typing import Optional
logger = logging.getLogger(__name__)
FALLBACK_MSG = "[Ошибка: не удалось получить ответ от Админа]"
def _resolve_gemini_bin() -> str:
    """Найти бинарник: конфиг → PATH → fallback."""
    # 1. Пытаемся прочитать из gemini_sockets.json (может быть устаревшим, но безопасно)
    try:
        from core.config_loader import load_config
        cfg = load_config("config/gemini_sockets.json", force_reload=True)
        bin_path = cfg.get("gemini_cli_path")
        if bin_path and Path(bin_path).exists():
            return bin_path
    except Exception:
        pass
    
    # 2. Поиск в PATH
    if path := shutil.which("gemini"):
        return path
        
    # 3. Fallback внутри проекта (есть ли такой?)
    fallback = Path(__file__).parent.parent / "integrations" / "gemini_cli.py"
    if fallback.exists():
        return str(fallback)
        
    raise RuntimeError("Gemini CLI not found. Set 'gemini_cli_path' in config.")
async def execute(
    mode: str,
    message: str,
    project_path: Optional[str] = None,
    prompt_text: Optional[str] = None,
    timeout: int = 30,
    for_role: Optional[str] = None,
    scope: Optional[str] = None
) -> str:
    """
    Эфемерный вызов Gemini CLI.
    :return: Текст ответа или fallback-строка (НИКОГДА не кидает исключение наружу)
    """
    try:
        bin_path = _resolve_gemini_bin()
    except RuntimeError as e:
        logger.error(f"[CLI] Binary resolution failed: {e}")
        return FALLBACK_MSG
    # Формируем команду (только аргументы, которые понимает CLI)
    cmd = [bin_path, "--mode", mode]
    if for_role:
        cmd.extend(["--for", for_role])
    if scope:
        cmd.extend(["--scope", scope])
    if project_path:
        cmd.extend(["--project-path", project_path])
    
    # Промпт: пишем во временный файл, если передан текст
    prompt_file = None
    if prompt_text:
        try:
            fd, prompt_file = tempfile.mkstemp(suffix=".txt", prefix="cli_prompt_")
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                f.write(prompt_text)
            cmd.extend(["--prompt", prompt_file])
        except Exception as e:
            logger.warning(f"[CLI] Failed to write prompt temp file: {e}")
    # Логирование (без утечки содержимого сообщения)
    cmd_log = cmd.copy()
    logger.debug(f"[CLI] Executing: {' '.join(cmd_log)}, timeout={timeout}s")
    proc = None
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        # Отправляем сообщение через stdin (чтобы избежать ограничений командной строки)
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(input=message.encode("utf-8")),
            timeout=timeout
        )
        
        # Парсинг ответа
        raw = stdout.decode("utf-8", errors="replace").strip()
        if not raw:
            raise ValueError("Empty output from CLI")
            
        try:
            data = json.loads(raw)
            if isinstance(data, dict) and "response" in data:
                return str(data["response"])
            # Если JSON, но без поля response, возвращаем как есть
            return raw
        except json.JSONDecodeError:
            # Не JSON — возвращаем сырой вывод (может быть текст)
            return raw
            
    except asyncio.TimeoutError:
        logger.error(f"[CLI] Timeout after {timeout}s (mode={mode})")
        if proc and proc.returncode is None:
            proc.kill()
        return f"[Таймаут: Админ ({mode}) не ответил за {timeout}с]"
    except Exception as e:
        logger.error(f"[CLI] Unexpected error: {e}", exc_info=True)
        return f"[Внутренняя ошибка CLI: {type(e).__name__}]"
    finally:
        # Очистка временного файла промпта
        if prompt_file and Path(prompt_file).exists():
            try:
                Path(prompt_file).unlink()
            except Exception:
                pass
🔹 2. Изменения в app2.py (точечная замена)
Добавить импорты (в начало файла):
python
from core.gemini_cli_executor import execute
from core.prompt_registry import PromptRegistry
from core.project_context import get_current_project_path, ensure_project_initialized
Найти старые вызовы (например, call_gemini_role, websockets.connect к портам агентов) и заменить.
Пример для роута /api/admin (или /api/secretary, если там вызывался Gemini):
python
@app.route("/api/admin", methods=["POST"])
async def handle_admin():
    data = await request.get_json()
    mode = data.get("mode", "console")
    message = data.get("message", "")
    
    # Получаем путь к проекту
    await ensure_project_initialized()
    project_path = get_current_project_path()
    
    # Загружаем системный промпт для режима (если нужен)
    prompt_text = PromptRegistry.get_prompt(f"admin_{mode}")  # или другой ключ
    
    response = await execute(
        mode=mode,
        message=message,
        project_path=project_path,
        prompt_text=prompt_text,
        for_role=data.get("for_role"),
        scope=data.get("scope"),
        timeout=30
    )
    
    return jsonify({"response": response, "mode": mode})
Если в doctor_ws_module.py есть вызовы агентов — заменить аналогично.
🔹 3. Заморозка legacy-кода
В файлах:
core/agent_orchestrator.py
gemini_mcp_server.py
integrations/websocket_adapter.py (если есть)
Добавить в самую первую строку (после shebang, если есть):
python
# ❄️ LEGACY: Frozen in SPEC_2026-04-13. Use core.gemini_cli_executor.execute() instead.
В app2.py закомментировать вызовы launch_agents() и terminate_agents() (они обычно в @app.before_serving или в if __name__ == "__main__").
🔹 4. Тесты (сохранить как отдельные файлы в корне AIColab/)
test_cli_parity.py
python
import asyncio
from core.gemini_cli_executor import execute
async def test():
    resp = await execute(mode="console", message="ping", timeout=10)
    assert isinstance(resp, str) and len(resp) > 0, f"Empty response: {resp}"
    print(f"✅ PARITY OK: {resp[:50]}")
    return True
asyncio.run(test())
test_cli_timeout.py
python
import asyncio
from core.gemini_cli_executor import execute
async def test():
    # Заведомо малый таймаут, чтобы спровоцировать fallback
    resp = await execute(mode="console", message="x" * 5000, timeout=1)
    assert "таймаут" in resp.lower() or "ошибка" in resp.lower(), f"No fallback: {resp}"
    print("✅ TIMEOUT HANDLED: fallback returned safely")
    return True
asyncio.run(test())
📜 ИНСТРУКЦИИ ДЛЯ САМУРАЯ (ПОШАГОВО)
Создать файл core/gemini_cli_executor.py (скопировать код из раздела выше).
В app2.py:
Добавить импорты execute, PromptRegistry, get_current_project_path, ensure_project_initialized.
Найти все вызовы websockets.connect или call_gemini_role, заменить на await execute(...).
Закомментировать вызовы launch_agents() и terminate_agents().
Заморозить legacy (добавить комментарий в начало файлов agent_orchestrator.py, gemini_mcp_server.py).
Сохранить тесты (два файла) в корень AIColab/.
Запустить тесты:
bash
cd AIColab
python test_cli_parity.py
python test_cli_timeout.py
Сформировать отчёт по шаблону:
yaml
[CLI_EXECUTOR_INTEGRATION]
file_created: YES
legacy_frozen: YES
calls_replaced: 3  # количество замен
test_parity: WORKS
test_timeout: FALLBACK
status: READY_FOR_REVIEW
✅ КРИТЕРИИ ПРИЁМКИ
№	Критерий	Как проверить	Ожидаемый результат
1	Файл создан	python -c "from core.gemini_cli_executor import execute; print('OK')"	OK
2	Legacy заморожен	grep -r "launch_agents|gemini_sockets" AIColab/*.py | grep -v "^#"	0 совпадений (или только в комментариях)
3	Вызовы заменены	grep -r "websockets.connect|call_gemini_role" AIColab/app2.py	0 активных совпадений
4	Тест паритета	python test_cli_parity.py	✅ PARITY OK
5	Таймаут обработан	python test_cli_timeout.py	✅ TIMEOUT HANDLED
🧹 ЧТО ДЕЛАТЬ ПРИ ПРОВАЛЕ ТЕСТА
Если тест падает → остановись, не пытайся чинить.
Верни в отчёте:
ошибку (полный текст)
строку кода, где упало
текущую реализацию execute() (если менял)
Жди уточнений.
🏁 ИТОГ
✅ Номер: SPEC_2026-04-13 (№1) v2
✅ Архитектура: эфемерный CLI, явный контекст, fallback
✅ Код Дипсика: готов, с обработкой ошибок
✅ Тесты: встроены
✅ Инструкции: пошаговые
Самурай, приступай. Без сокетов. Без портов. Только чистая функция → ответ. 🎌

Вердикт интегратора:
🧠 Общая оценка
Версия v2 от Дипсика — правильная и готова к передаче.
Первая версия (Qwen) — сильнее концептуально, но слабее как исполнимое ТЗ.
👉 Если коротко:
Qwen = хорошо для понимания
DeepSeek v2 = можно сразу кодить без гаданий
И для твоей текущей стадии (уже идёт интеграция) — нужен именно DeepSeek v2.
⚖️ Сравнение (честно, без дипломатии)
1. Исполнимость
Qwen: ⚠️ местами абстрактно
DeepSeek v2: ✅ конкретные файлы, строки, команды
👉 Победитель: DeepSeek v2
2. Риск "Самурай начнёт додумывать"
Qwen: ❌ высокий (много “понять архитектуру”)
DeepSeek v2: ✅ минимальный (копипаст + grep + тесты)
👉 Это критично.
Сейчас вам нельзя допускать творчество на интеграции.
3. Архитектурная чистота
Qwen: ✅ глубже (онтология, триады, границы)
DeepSeek v2: ✅ достаточно (инварианты зафиксированы)
👉 Но: архитектура уже согласована выше (тобой + Хранителем)
Значит в ТЗ:
❗ НЕ НУЖНО повторно "объяснять философию"
НУЖНО заставить код соответствовать
4. Соответствие новому курсу (CLI вместо WS)
DeepSeek v2:
✔ stdin вместо --message (учтено)
✔ fallback есть
✔ async строго соблюдён
✔ legacy заморожен (а не удалён)
✔ тесты есть
👉 Это именно то, что сейчас нужно.
🔥 Критические замечания (важно перед отправкой)
Вот 3 вещи, которые я бы ДОПРАВИЛ перед передачей Промптеру:
1. ❗ Противоречие с предыдущим ТЗ (очень важно)
Раньше было:
❌ НЕ вызывать Admin в /api/secretary
А сейчас в примере:
@app.route("/api/admin", ...)
👉 Нужно ЯВНО зафиксировать:
ГДЕ МОЖНО вызывать execute():
✅ /api/admin
✅ /api/audit
✅ внутренние сервисы
ГДЕ НЕЛЬЗЯ:
❌ /api/chat
❌ /api/secretary (если это staff-поток)
Иначе Самурай может сломать границы.
2. ❗ PromptRegistry ключи
Сейчас:
PromptRegistry.get_prompt(f"admin_{mode}")
👉 Вопрос:
есть ли реально файлы admin_console, admin_secretary, admin_auditor?
Если нет → будет fallback → потеря смысла архитектуры.
📌 Рекомендация (добавить в ТЗ):
Ожидаемые файлы:
prompts/admin_console_system.txt
prompts/admin_secretary_system.txt
prompts/admin_auditor_system.txt
3. ❗ stdout vs stderr (скрытый баг)
Сейчас:
stdout, stderr = await proc.communicate(...)
raw = stdout.decode(...)
👉 Но если CLI пишет ошибку в stderr — вы её теряете.
📌 Минимальная правка в ТЗ:
Добавить:
if stderr:
    logger.debug(f"[CLI] stderr: {stderr.decode(...)}")
Иначе дебаг будет адом.
🧱 Архитектурная оценка (самое важное)
Ты сейчас сделал очень правильный поворот:
Было:
5 WS агентов → сложность ↑↑↑ → нестабильность
Стало:
1 CLI → stateless → предсказуемость
А с триадой:
Admin (CLI)
Staff (OpenRouter)
Core (Local)
👉 Это уже не "прототип", а устойчивая архитектура.
🟢 Финальный вердикт
📌 Можно ли передавать Промптеру?
👉 ДА, можно. Это лучший вариант из двух.
📌 Но с микро-доработками (рекомендую внести):
Явно прописать:
execute() нельзя вызывать в /api/chat и /api/secretary (staff поток)
Зафиксировать файлы промптов:
admin_console_system.txt
admin_secretary_system.txt
admin_auditor_system.txt
Добавить логирование stderr
🏁 Итог простым языком
Ты сделал не “ещё один рефакторинг”, а:
убрал целый класс проблем (сокеты, порты, гонки) одним решением
И это редкий случай, когда:
проще
стабильнее
понятнее
и дешевле в поддержке


