'use strict';
const { I } = require('./lib/ia');
const { V } = require('./lib/vec');
const { distPointToMidCircle } = require('./lib/geom');
const { hangDirection, rodrigues } = require('./lib/frame');

const A_T2 = V.of([0, 0, 4]);
const Y_HAT = V.of([0, 1, 0]);
const EX = V.of([1, 0, 0]), EY = Y_HAT, EZ = V.of([0, 0, 1]);
const SIDE = 1;

// Same as buildH1 in check1_root.js — full §2 link rule with u = e.
function buildH1(rho_I, d_I, psi, delta) {
  const e = hangDirection(rho_I, psi, EX, EY, EZ, SIDE);
  const u_dot_T = e.dot(Y_HAT);
  const T_prime = Y_HAT.sub(e.scale(u_dot_T.mul(I.of(2))));
  const n_raw = e.cross(Y_HAT);
  let n;
  try {
    n = n_raw.unit();
  } catch (err) {
    throw new Error('n degenerate at ρ=' + (rho_I.mid() * 180 / Math.PI));
  }
  const T_H1 = rodrigues(T_prime, n, delta);
  const A_H1 = A_T2.add(e.scale(d_I));
  return { A_H1, T_H1 };
}

function checkTheta(theta, W_deg, N_rho, dMid, dPad, psi, delta) {
  const P = V.of([0, Math.sin(theta), 3 - Math.cos(theta)]);
  let distMax = -Infinity;
  let distMin = Infinity;
  let hitCount = 0;
  for (let j = 0; j <= N_rho; j++) {
    const rhoDeg = W_deg[0] + j * (W_deg[1] - W_deg[0]) / N_rho;
    const rho = I.of(rhoDeg * Math.PI / 180);
    const d_I = new I(dMid - dPad, dMid + dPad);
    let H;
    try { H = buildH1(rho, d_I, psi, delta); } catch (e) { continue; }
    hitCount++;
    const dist = distPointToMidCircle(P, H.A_H1, H.T_H1);
    if (dist.hi > distMax) distMax = dist.hi;
    if (dist.lo < distMin) distMin = dist.lo;
  }
  if (hitCount === 0) return null;
  return { distMax, distMin, body_bound: 0.5 };
}

function check2_penetration(W_deg, d_lo, d_hi, psi_deg, delta_deg) {
  if (!W_deg) {
    return {
      check: 'check2_penetration',
      found: false,
      error: 'no_W_from_check1',
      coverage: 'NONE — no single-interval W from check1.',
      notes: 'Cannot run: check1 returned no single-interval W.'
    };
  }
  const psi = psi_deg * Math.PI / 180;
  const delta = delta_deg * Math.PI / 180;
  const N_theta = 720;
  const N_rho = 50;
  const dMid = (d_lo + d_hi) / 2;
  const dPad = (d_hi - d_lo) / 2 + 0.01;
  let best = null;
  for (let j = 0; j < N_theta; j++) {
    const thetaDeg = j * 360 / N_theta;
    const theta = thetaDeg * Math.PI / 180;
    const r = checkTheta(theta, W_deg, N_rho, dMid, dPad, psi, delta);
    if (r && r.distMax < 0.5) {
      if (!best || r.distMax < best.distMax) {
        best = { theta_deg: thetaDeg, distMax: r.distMax, distMin: r.distMin };
      }
    }
  }
  const found = !!best;
  return {
    check: 'check2_penetration',
    config: { psi_deg, delta_deg, side: 1 },
    W_deg,
    theta_grid_points: N_theta,
    rho_grid_points: N_rho + 1,
    found,
    theta_deg: found ? best.theta_deg : null,
    dist_H1_body_hi: found ? best.distMax : null,
    body_bound: 0.5,
    coverage: found
      ? 'PARTIAL — W is a union of undetermined boxes; uniqueness of the root is not proven. Penetration shown for sampled ρ ∈ W and all θ in a 720-point grid.'
      : 'NOT_FOUND — no θ in the grid gave strict penetration for all sampled ρ ∈ W.',
    notes: 'If found=true: point on R1 is strictly inside H1 body. Per Integrator 03.11: PARTIAL coverage — uniqueness of the root not proven. buildH1 applies full §2 link rule (mirror axis then rotate).'
  };
}

module.exports = { check2_penetration };
