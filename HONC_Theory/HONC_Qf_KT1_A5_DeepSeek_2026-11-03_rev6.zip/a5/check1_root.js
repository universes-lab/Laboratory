'use strict';
const { I } = require('./lib/ia');
const { V } = require('./lib/vec');
const { gapTorusTorus } = require('./lib/geom');
const { hangDirection, rodrigues } = require('./lib/frame');

const A_T1 = V.of([0, 0, 2]);
const A_T2 = V.of([0, 0, 4]);
const Y_HAT = V.of([0, 1, 0]);
const X_HAT = V.of([1, 0, 0]);
const Z_HAT = V.of([0, 0, 1]);

const EX = X_HAT, EY = Y_HAT, EZ = Z_HAT;
const SIDE = 1;

// Build H1 torus on host T2 per §2 interface v6, link rule with u = e:
//   mirror axis T' = T_h − 2(T_h·u)·u
//   n = norm(u × T_h)
//   T_{k+1} = rodrigues(T', n, δ)
// where T_h = Y_HAT (host axis of T2)
function buildH1(rho_I, d_I, psi, delta) {
  const e = hangDirection(rho_I, psi, EX, EY, EZ, SIDE);
  const u_dot_T = e.dot(Y_HAT);
  const T_prime = Y_HAT.sub(e.scale(u_dot_T.mul(I.of(2))));
  const n_raw = e.cross(Y_HAT);
  let n;
  try {
    n = n_raw.unit();
  } catch (err) {
    throw new Error('n degenerate at ρ=' + (rho_I.mid() * 180 / Math.PI));
  }
  const T_H1 = rodrigues(T_prime, n, delta);
  const A_H1 = A_T2.add(e.scale(d_I));
  return { A_H1, T_H1 };
}

function evaluateGapH1T2(rho_I, d_mid, psi, delta) {
  const { A_H1, T_H1 } = buildH1(rho_I, I.of(d_mid), psi, delta);
  return gapTorusTorus(A_H1, T_H1, A_T2, Y_HAT, 180, 1.0);
}

function solveD(rho_I, psi, delta) {
  const dLo = 0.5, dHi = 3.0;
  const N_scan = 40;
  const scanH = (dHi - dLo) / N_scan;
  const straddles = [];
  let prevSign = null;
  let prev_d = dLo;
  for (let j = 0; j <= N_scan; j++) {
    const d = dLo + j * scanH;
    const g = evaluateGapH1T2(rho_I, d, psi, delta);
    const sign = g.isPos() ? '+' : (g.isNeg() ? '-' : '0');
    if (prevSign !== null && prevSign !== '0' && sign !== '0' && prevSign !== sign) {
      straddles.push([prev_d, d]);
    }
    if (sign !== '0') prevSign = sign;
    prev_d = d;
  }
  if (straddles.length === 0) {
    return { lo: dLo, hi: dHi, uncertain: true, multiplicity: 0 };
  }
  if (straddles.length > 1) {
    let lo = Infinity, hi = -Infinity;
    for (const [a, b] of straddles) { if (a < lo) lo = a; if (b > hi) hi = b; }
    return { lo, hi, uncertain: true, multiplicity: straddles.length };
  }
  let a = straddles[0][0], b = straddles[0][1];
  const ga = evaluateGapH1T2(rho_I, a, psi, delta);
  let sign_a = ga.isPos() ? '+' : '-';
  for (let iter = 0; iter < 40 && (b - a) > 1e-6; iter++) {
    const m = (a + b) / 2;
    const g = evaluateGapH1T2(rho_I, m, psi, delta);
    const s = g.isPos() ? '+' : (g.isNeg() ? '-' : '0');
    if (s === sign_a) a = m;
    else b = m;
  }
  return { lo: a, hi: b, uncertain: false, multiplicity: 1 };
}

function gapH1T1(rho_I, psi, delta) {
  const d = solveD(rho_I, psi, delta);
  if (d.uncertain) return { gap: new I(-1, 1), d, uncertain: true };
  const { A_H1, T_H1 } = buildH1(rho_I, new I(d.lo, d.hi), psi, delta);
  const gap = gapTorusTorus(A_H1, T_H1, A_T1, Y_HAT, 360, 1.0);
  return { gap, d, uncertain: false };
}

function check1_root(psi_deg, delta_deg, rho_lo_deg, rho_hi_deg) {
  const psi = psi_deg * Math.PI / 180;
  const delta = delta_deg * Math.PI / 180;
  const N = 80;
  const step = (rho_hi_deg - rho_lo_deg) / N;
  const grid = [];
  for (let j = 0; j <= N; j++) {
    const rhoDeg = rho_lo_deg + j * step;
    const rho = I.of(rhoDeg * Math.PI / 180);
    const { gap, d, uncertain } = gapH1T1(rho, psi, delta);
    const sign = uncertain ? '?' : (gap.isPos() ? '+' : (gap.isNeg() ? '-' : '?'));
    grid.push({
      rho_deg: rhoDeg, gap_lo: gap.lo, gap_hi: gap.hi,
      d_lo: d.lo, d_hi: d.hi,
      d_multiplicity: d.multiplicity,
      d_widened: d.uncertain,
      sign, uncertain
    });
  }
  const changes = [];
  for (let j = 0; j < N; j++) {
    const a = grid[j], b = grid[j + 1];
    if (a.sign === '+' && b.sign === '-') changes.push({ rho_a_deg: a.rho_deg, rho_b_deg: b.rho_deg, dir: '+-' });
    else if (a.sign === '-' && b.sign === '+') changes.push({ rho_a_deg: a.rho_deg, rho_b_deg: b.rho_deg, dir: '-+' });
  }
  const hasUncertain = grid.some(g => g.uncertain || g.sign === '?');
  const hasWidened = grid.some(g => g.d_widened);
  let W = null, existence, uniqueness;
  if (changes.length === 1) {
    W = [changes[0].rho_a_deg, changes[0].rho_b_deg];
    existence = 'yes';
    uniqueness = (hasUncertain || hasWidened)
      ? 'practical_one_change_with_uncertainty'
      : 'practical_one_change';
  } else if (changes.length === 0 && !hasUncertain && !hasWidened) {
    existence = 'no';
    uniqueness = 'no_change';
  } else if (changes.length === 0 && (hasUncertain || hasWidened)) {
    existence = 'undetermined';
    uniqueness = 'undetermined_grid';
  } else {
    existence = 'undetermined';
    uniqueness = 'multiple_sign_changes';
  }
  let minGapLo = Infinity, minGapLoRho = null;
  let maxGapHi = -Infinity, maxGapHiRho = null;
  let countUncertain = 0, countWidened = 0, maxMultiplicity = 0;
  for (const g of grid) {
    if (g.gap_lo < minGapLo) { minGapLo = g.gap_lo; minGapLoRho = g.rho_deg; }
    if (g.gap_hi > maxGapHi) { maxGapHi = g.gap_hi; maxGapHiRho = g.rho_deg; }
    if (g.uncertain) countUncertain++;
    if (g.d_widened) countWidened++;
    if (g.d_multiplicity > maxMultiplicity) maxMultiplicity = g.d_multiplicity;
  }
  return {
    check: 'check1_root',
    config: { psi_deg, delta_deg, rho_bracket_deg: [rho_lo_deg, rho_hi_deg], with: 'T1', side: 1 },
    grid_points: N + 1,
    grid_step_deg: step,
    grid: grid,
    grid_summary: {
      min_gap_lo: minGapLo, min_gap_lo_rho_deg: minGapLoRho,
      max_gap_hi: maxGapHi, max_gap_hi_rho_deg: maxGapHiRho,
      count_uncertain: countUncertain,
      count_widened: countWidened,
      max_d_multiplicity: maxMultiplicity
    },
    sign_changes: changes,
    W_deg: W,
    existence,
    uniqueness,
    notes: 'Existence via IVT on gap_H1_T1(ρ) = 0. Uniqueness practical, not formal Lipschitz on ρ. solveD scans d ∈ [0.5, 3.0] for all sign-change straddles of gap(H1,T2) at each ρ; if multiple, bracket is union of all and d_widened=true. sin/cos via Math.* with field 1e-12 — practical envelope. Undetermined grid evidence reported as "undetermined", never as "no". buildH1 applies full §2 link rule (mirror axis then rotate).'
  };
}

module.exports = { check1_root };
