"""Этап А, режим «замыкание», трёхмерная модель с разрешённой областью — вместо грубого критерия «ушёл вбок»
(closure_profile.py: «ρ > 0,29 при β < 35° — ушёл»). [мост при О-к+ на время замыкания]

Что меняется против closure_profile.py:
- поле — полное (Био — Савар на сетке free3d_grid.npz, шаг 0,1), а не разложение у оси до ρ²;
- стенки — настоящие: центр шара радиуса 1 допустим при d ≥ 1 (d — расстояние до ближайшего тора или кольца);
  при d < 1 шар выталкивается по ∇d до d = 1, нормальная составляющая скорости внутрь гасится (упор неупругий);
  торы движутся с β и сами толкают шар;
- «ушёл» — только если центр вышел за сферу |x| = 3,2 (за пределы сборки); куда — по направлению:
  «по оси», если |y| > 0,8|x|, иначе «наклонно/вбок».
Остальное как в closure_profile.py: сфера — точный диполь (сила ∇(s·B)), прецессия P = 100, |s| = 1,
β: 5° → 35° за T1, 35° → 65° за T2, затем выдержка 10 при 65°, «вместе»; 300 квантронов у центра, случайные s.
Запуск: python3 free3d_closure.py   (нужен free3d_grid.npz от free3d_grid.py)"""
import numpy as np, os
here = os.path.dirname(os.path.abspath(__file__))
Z = np.load(os.path.join(here, 'free3d_grid.npz'))
betas = Z['betas']; ax = Z['ax']; H = ax[1] - ax[0]; n = len(ax)
d = Z['d']; gd = np.stack([np.stack(np.gradient(d[k], H, H, H), -1) for k in range(len(betas))])
F = np.concatenate([d[..., None], gd, Z['B'], Z['G'].reshape(*Z['G'].shape[:4], 9)], -1).astype(np.float32)  # 16 компонент
del Z, gd
def interp(P, bt):
    i = int(np.clip(np.searchsorted(betas, bt) - 1, 0, len(betas) - 2)); w = (bt - betas[i]) / (betas[i + 1] - betas[i])
    u = np.clip((P - ax[0]) / H, 0, n - 1.000001); i0 = np.floor(u).astype(int); f = u - i0
    out = 0.0
    for dx in (0, 1):
        for dy in (0, 1):
            for dz in (0, 1):
                wt = (f[:, 0] if dx else 1 - f[:, 0]) * (f[:, 1] if dy else 1 - f[:, 1]) * (f[:, 2] if dz else 1 - f[:, 2])
                ix, iy, iz = i0[:, 0] + dx, i0[:, 1] + dy, i0[:, 2] + dz
                out = out + wt[:, None] * ((1 - w) * F[i, ix, iy, iz] + w * F[i + 1, ix, iy, iz])
    return out
def rotate(s, B, ang):
    nB = np.linalg.norm(B, axis=1); k = B / np.maximum(nB, 1e-12)[:, None]; a = (ang * nB)[:, None]
    return s * np.cos(a) + np.cross(k, s) * np.sin(a) + k * (k * s).sum(1)[:, None] * (1 - np.cos(a))
rng = np.random.default_rng(11); N = 300
s0 = rng.normal(size=(N, 3)); s0 /= np.linalg.norm(s0, axis=1)[:, None]
P0 = np.stack([rng.normal(0, 0.005, N), rng.normal(0, 0.02, N), rng.normal(0, 0.005, N)], 1)
Pp = 100.0; RESC = 3.2
HOLD = 10.0   # после 65° — выдержка: дать долететь тем, кто ещё в пути
def run(T1, T2, b_end=65.0, hold=HOLD):
    T2e = T2 * (b_end - 35) / 30
    dt = min(0.002, (T1 + T2e) / 4000); nst = int((T1 + T2e + hold) / dt)
    s = s0.copy(); P = P0.copy(); V = np.zeros((N, 3)); alive = np.ones(N, bool); how = np.zeros(N, int)  # 1 ось, 2 наклонно
    when = np.full(N, np.nan); maxpen = 0.0
    for k in range(nst):
        t = k * dt; bt = 5 + 30 * t / T1 if t < T1 else min(35 + 30 * (t - T1) / T2, b_end)
        A = np.where(alive)[0]
        if len(A) == 0: break
        Q = interp(P[A], bt); B = Q[:, 4:7]; G = Q[:, 7:16].reshape(-1, 3, 3)
        s[A] = rotate(s[A], B, Pp * dt)
        V[A] += np.einsum('nj,nji->ni', s[A], G) * dt; P[A] += V[A] * dt
        for _ in range(2):   # стенки
            Q = interp(P[A], bt); dd = Q[:, 0]; hit = dd < 1.0
            if not hit.any(): break
            maxpen = max(maxpen, float((1 - dd[hit]).max()))
            g = Q[hit, 1:4]; nh = g / np.maximum(np.linalg.norm(g, axis=1), 1e-12)[:, None]
            j = A[hit]; P[j] += (1.0 - dd[hit])[:, None] * nh
            vn = (V[j] * nh).sum(1); V[j] -= np.minimum(vn, 0)[:, None] * nh
        r = np.linalg.norm(P[A], axis=1); out = r > RESC
        if out.any():
            j = A[out]; alive[j] = False; when[j] = bt
            how[j] = np.where(np.abs(P[j, 1]) > 0.8 * r[out], 1, 2)
    r = np.linalg.norm(P, axis=1); cen = alive & (r < 0.4); thr = alive & ~cen & (np.abs(P[:, 1]) > 0.6) & (np.abs(P[:, 1]) < 1.0) & (np.hypot(P[:, 0], P[:, 2]) < 0.3)
    oth = alive & ~cen & ~thr
    sy = s[cen, 1].mean() if cen.any() else float('nan')
    sy_ax = s[how == 1, 1].mean() if (how == 1).any() else float('nan')
    sy_ob = s[how == 2, 1].mean() if (how == 2).any() else float('nan')
    return dict(thr=thr.mean(), thr_sy=(s[thr, 1].mean() if thr.any() else float('nan')), thr_y=(np.median(np.abs(P[thr, 1])) if thr.any() else float('nan')), ax=(how == 1).mean(), ob=(how == 2).mean(), cen=cen.mean(), oth=oth.mean(), sy=sy, sy_ax=sy_ax, sy_ob=sy_ob,
                b_ob=np.nanmax(np.where(how == 2, when, np.nan)) if (how == 2).any() else float('nan'),
                b_ax=np.nanmax(np.where(how == 1, when, np.nan)) if (how == 1).any() else float('nan'),
                pen=maxpen, oth_r=(np.median(r[oth]) if oth.any() else float('nan')),
                oth_y=(np.median(np.abs(P[oth, 1])) if oth.any() else float('nan')), oth_rho=(np.median(np.hypot(P[oth, 0], P[oth, 2])) if oth.any() else float('nan')),
                oth_sy=(s[oth, 1].mean() if oth.any() else float('nan')))
if __name__ == '__main__':
    print("Карта отбора в 3D с разрешённой областью (P = 100, «вместе», β 5° → 35° → 65°)")
    for T1 in (0.43, 2.0, 5.0, 15.0):
        for T2 in (0.69, 3.0, 10.0, 30.0):
            R = run(T1, T2)
            print(f"   T1={T1:5.2f}, T2={T2:5.2f}: по оси {R['ax']:.2f} (s_y {R['sy_ax']:+.2f}, последний при β={R['b_ax']:.1f}), "
                  f"наклонно {R['ob']:.2f} (s_y {R['sy_ob']:+.2f}, последний при β={R['b_ob']:.1f}); у центра {R['cen']:.2f}, "
                  f"s_y {R['sy']:+.2f}; у горловин {R['thr']:.2f} (|y| {R['thr_y']:.2f}, s_y {R['thr_sy']:+.2f}); в прочих местах {R['oth']:.2f} (медианы |y| {R['oth_y']:.2f}, ρ {R['oth_rho']:.2f}; s_y {R['oth_sy']:+.2f}); проникновение ≤ {R['pen']:.3f}", flush=True)
