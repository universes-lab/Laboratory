"""Куда уходят «по полю» в ранней фазе при медленном замыкании (T1 = 15, T2 = 10) в модели free3d_closure.py:
наибольшее удаление от оси, высота |y| в этот момент, положение при β = 35° и в конце. Запуск: python3 free3d_trace.py"""
import numpy as np
import free3d_closure as C
T1, T2, hold = 15.0, 10.0, 10.0
N = C.N; dt = 0.002; nst = int((T1 + T2 + hold) / dt)
s = C.s0.copy(); P = C.P0.copy(); V = np.zeros((N, 3)); alive = np.ones(N, bool)
rmax = np.zeros(N); ymax_at = np.zeros(N); b_at = np.zeros(N); dmin = np.full(N, 9.0); P35 = None
for k in range(nst):
    t = k * dt; bt = 5 + 30 * t / T1 if t < T1 else min(35 + 30 * (t - T1) / T2, 65.0)
    A = np.where(alive)[0]
    Q = C.interp(P[A], bt); B = Q[:, 4:7]; G = Q[:, 7:16].reshape(-1, 3, 3)
    s[A] = C.rotate(s[A], B, C.Pp * dt); V[A] += np.einsum('nj,nji->ni', s[A], G) * dt; P[A] += V[A] * dt
    for _ in range(2):
        Q = C.interp(P[A], bt); dd = Q[:, 0]; hit = dd < 1.0
        if not hit.any(): break
        g = Q[hit, 1:4]; nh = g / np.maximum(np.linalg.norm(g, axis=1), 1e-12)[:, None]; j = A[hit]
        P[j] += (1.0 - dd[hit])[:, None] * nh; vn = (V[j] * nh).sum(1); V[j] -= np.minimum(vn, 0)[:, None] * nh
    rho = np.hypot(P[:, 0], P[:, 2]); upd = alive & (rho > rmax)
    rmax[upd] = rho[upd]; ymax_at[upd] = np.abs(P[upd, 1]); b_at[upd] = bt
    dmin[A] = np.minimum(dmin[A], C.interp(P[A], bt)[:, 0])
    alive &= np.linalg.norm(P, axis=1) <= C.RESC
    if P35 is None and bt >= 35: P35 = P.copy()
al = (C.s0[:, 1] > 0)
end_c = alive & (np.linalg.norm(P, axis=1) < 0.4)
def q(x): return f"медиана {np.median(x):.2f}, 90% {np.quantile(x, 0.9):.2f}, макс {x.max():.2f}"
print(f"«по полю» (s_y > 0 в начале): {al.sum()}; из них в конце у центра {(al & end_c).sum()}")
print(f"  наибольшее удаление от оси ρ_max: {q(rmax[al])}")
print(f"  |y| в момент ρ_max: {q(ymax_at[al])}; β в этот момент: {q(b_at[al])}")
r35 = np.hypot(P35[:, 0], P35[:, 2])
print(f"  при β = 35°: ρ {q(r35[al])}, |y| {q(np.abs(P35[al, 1]))}")
print(f"  касались стенки (d ≤ 1,001): {(dmin[al] <= 1.001).mean():.2f}")
