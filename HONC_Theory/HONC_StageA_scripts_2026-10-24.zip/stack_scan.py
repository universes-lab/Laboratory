"""Энергия пустой пары «голова к хвосту» U_cc(D) = −M12 (фиксированные токи, [мост]) на 1,85 ≤ D ≤ 3,5:
есть ли равновесное расстояние (минимум U) до касания. Поворот B вокруг оси 0° и 22,5°. Запуск: python3 stack_scan.py"""
import numpy as np, sys, os, io, contextlib
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
with contextlib.redirect_stdout(io.StringIO()):
    import stack_two as S
y = np.array([0, 1.0, 0])
for name, M in (("0°", np.eye(3)), ("22,5°", S.Rot(y, np.pi / 8))):
    Ds = np.round(np.arange(1.85, 3.51, 0.05), 3); U = []
    for Dd in Ds:
        _, rB, _ = S.transform(M, Dd * y); U.append(-S.M12(rB))
    U = np.array(U); k = np.argmin(U)
    c = np.polyfit(Ds[max(k - 2, 0):k + 3], U[max(k - 2, 0):k + 3], 2); Dst = -c[1] / (2 * c[0])
    print(f"поворот {name}: " + "; ".join(f"{d:.2f}:{u:+.2f}" for d, u in zip(Ds, U)))
    print(f"   минимум U = {np.polyval(c, Dst):+.3f} при D* = {Dst:.3f}; жёсткость U'' = {2 * c[0]:.2f}; U(1,85) − U(D*) = {U[0] - np.polyval(c, Dst):+.3f}", flush=True)
