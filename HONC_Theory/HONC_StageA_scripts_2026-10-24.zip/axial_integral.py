"""Проверка: интеграл B_y по всей оси цикла равен нулю, потому что ни одно кольцо не охватывает ось
(закон Ампера по контуру «ось + бесконечность»; кольца — эллипсы у пар соседних торов). Отсюда центральная доля
поля обязана компенсироваться долями обратного знака за осевыми нулями [мост, аналитически].
Числа: сетка по y неравномерная (sinh), хвосты |y| > L — дипольные, 2m/L². β = 65°, «вместе». Запуск: python3 axial_integral.py"""
import importlib.util, numpy as np, os, sys
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
spec = importlib.util.spec_from_file_location('h', os.path.join(here, 'honc_ring_field.py'))
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
for beta in (63.49, 65.0, 66.54):
    seg = h.segments(h.build(8, beta), 600); m = h.moment(seg)[1]
    L = 80.0; u = np.linspace(0, np.arcsinh(L / 0.05), 6001); y = 0.05 * np.sinh(u); y = np.concatenate([-y[::-1], y[1:]])
    B = h.field(seg, np.stack([0 * y, y, 0 * y], 1))[:, 1]
    I = np.trapezoid(B, y) + 2 * m / L ** 2
    pos = np.trapezoid(np.clip(B, 0, None), y); neg = np.trapezoid(np.clip(B, None, 0), y)
    yp = y[y > 0]; Bp = B[y > 0]; zc = yp[1:][np.sign(Bp[1:]) != np.sign(Bp[:-1])]
    print(f"beta={beta}: ∫B_y dy = {I:+.4f} (положительные доли {pos:+.3f}, отрицательные {neg:+.3f}); смены знака при y>0: "
          + ", ".join(f"{z:.3f}" for z in zc) + f"; min B_y = {Bp.min():+.3f} при y = {yp[np.argmin(Bp)]:.2f}")
