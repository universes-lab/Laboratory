"""Пара «голова к хвосту» на касании колец (D_c из stack_contact.py): сколько точек касания, какие кольца,
угол между касательными и направление обхода в точке (сонаправленно / встречно) — для чтения касания как
возможного события защёлки между инструментами (П-X, К-1; A-15 — не больше двух колец в точке). Запуск: python3 stack_touch.py"""
import numpy as np, sys, os, io, contextlib
from scipy.spatial import cKDTree
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
with contextlib.redirect_stdout(io.StringIO()):
    import stack_two as S
a = 0.015; y = np.array([0, 1.0, 0]); n = len(S.rings[0])
def tang(R):
    t = np.roll(R, -1, 0) - np.roll(R, 1, 0); return t / np.linalg.norm(t, axis=1)[:, None]
for ph in (0.0, 22.5, 45.0):
    M = S.Rot(y, np.radians(ph)); lo, hi = 1.85, 3.2
    def mind(Dd):
        _, rB, _ = S.transform(M, Dd * y)
        return min(np.linalg.norm(Ra[:, None] - Rb[None], axis=2).min() for Ra in S.rings for Rb in rB)
    for _ in range(30):
        mid = (lo + hi) / 2; lo, hi = (lo, mid) if mind(mid) >= 2 * a else (mid, hi)
    Dc = hi; _, rB, _ = S.transform(M, Dc * y)
    rows = []
    for i, Ra in enumerate(S.rings):
        ta = tang(Ra)
        for j, Rb in enumerate(rB):
            d = np.linalg.norm(Ra[:, None] - Rb[None], axis=2); k = np.unravel_index(np.argmin(d), d.shape)
            if d[k] < 2 * a + 0.01:
                tb = tang(Rb)[k[1]]; c = float(ta[k[0]] @ tb)
                rows.append((i, j, d[k], np.degrees(np.arccos(abs(c))), 'сонаправленно' if c > 0 else 'встречно', Ra[k[0]]))
    print(f"φ = {ph}°: D_c = {Dc:.4f}; точек касания {len(rows)}")
    for i, j, dd, ang, sgn, X in rows:
        print(f"   кольцо A{i} — кольцо B{j}: зазор {dd:.4f}, угол касательных {ang:5.1f}°, обход {sgn}, точка (ρ = {np.hypot(X[0], X[2]):.3f}, y = {X[1]:+.3f})")
