"""Этап Б, вход: (1) проверка M12 — к пределу точечных диполей на больших расстояниях;
(2) гружёные связки «голова к хвосту»: квантрон-шар радиуса 1 в центре каждой сборки (N = 8, β = 65°, «вместе»).
Свободный радиус на оси одной сборки при |y| до 3 — где может стоять шар соседа; D_min гружёных.
(3) Слагаемые энергии гружёной пары при фиксированных токах [мост]:
U = U_cc(D) − 2 m_q·b_y(D) − 2 m_q²/D³, где b_y(D) — поле одной сборки на оси на расстоянии D,
m_q — момент квантрона по полю (О-и); шары — точные диполи, слагаемое шар—шар точное.
Запуск: python3 stack_loaded.py"""
import importlib.util, numpy as np, os, sys
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
spec = importlib.util.spec_from_file_location('h', os.path.join(here, 'honc_ring_field.py'))
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
import docking as D
import stack_two as S   # повторно считает свою часть; функции M12, transform
g = S.g
obst = np.vstack([D.ring_points(r['C'], r['u'], r['W'], r['p'], r['q'], 4000) for r in g['rings']] +
                 [D.torus_surface(np.array(A), np.array(T) / np.linalg.norm(T), 200) for A, T in zip(g['A'], g['T'])])
print("\nСвободный радиус на оси одной сборки:")
ys = np.round(np.arange(0.0, 3.01, 0.1), 2)
fr = {y: np.linalg.norm(obst - np.array([0, y, 0.0]), axis=1).min() for y in ys}
fr_m = {y: np.linalg.norm(obst - np.array([0, -y, 0.0]), axis=1).min() for y in ys}
print("  " + "; ".join(f"y={y:.1f}: {fr[y]:.3f}/{fr_m[y]:.3f}" for y in ys))
Dl = None
for Dd in np.arange(1.85, 4.001, 0.01):
    a = np.linalg.norm(obst - np.array([0, Dd, 0.0]), axis=1).min(); b = np.linalg.norm(obst - np.array([0, -Dd, 0.0]), axis=1).min()
    if Dd >= 2.0 and a >= 1.0 and b >= 1.0: Dl = Dd; break
print(f"D_min гружёных «голова к хвосту» = {Dl:.2f} (пустые — 1,85; шар—шар требует ≥ 2)")
seg = h.segments(g, 3000)
y = np.array([0, 1.0, 0])
print("\nПроверка M12 против диполей на больших расстояниях (голова к хвосту, поворот 0°):")
for Dd in (8.0, 15.0, 30.0):
    _, rB, _ = S.transform(np.eye(3), Dd * y)
    U = -S.M12(rB); Ud = -2 * S.mA[1] ** 2 / Dd ** 3
    print(f"  D={Dd:5.1f}: U={U:+.5f}, диполи {Ud:+.5f}, отношение {U / Ud:.3f}")
print("\nГружёная пара: слагаемые U = U_cc − 2 m_q b_y(D) − 2 m_q²/D³")
for Dd in (Dl, Dl + 0.5, Dl + 1.0, Dl + 3.0):
    _, rB, _ = S.transform(np.eye(3), Dd * y)
    Ucc = -S.M12(rB)
    by = h.field(seg, np.array([[0, Dd, 0.0]]))[0, 1]
    bdip = 2 * S.mA[1] / Dd ** 3
    print(f"  D={Dd:.2f}: U_cc={Ucc:+.3f}; b_y(D)={by:+.4f} (диполь {bdip:+.4f}); 2/D³={2 / Dd ** 3:.4f}")
