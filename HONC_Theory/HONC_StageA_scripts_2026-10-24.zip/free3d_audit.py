"""Контроль Интегратора к п. 15 (модель free3d_closure.py).
(1) Таблица переходов по каждому квантрону: исходный знак s_y → конечное место → конечный знак s_y;
    сравнение с простым селектором «s_y > 0», который никакой динамики не выполняет.
(2) Зависимость от начальной выборки: seed 11/12/13 (PCG64), другой генератор (MT19937), детерминированная
    сфера Фибоначчи (без случайности).
(3) Аудит стенок: неупругий упор (как в п. 15) против упругого отражения; потеря кинетической энергии на стенках
    против масштаба энергии момента в поле |s|·|B(0)| ≈ 1,81.
Запуск: python3 free3d_audit.py"""
import numpy as np, sys
import free3d_closure as C
def sample(kind, seed, N=300):
    if kind == 'pcg': r = np.random.default_rng(seed); s = r.normal(size=(N, 3)); P = np.stack([r.normal(0, .005, N), r.normal(0, .02, N), r.normal(0, .005, N)], 1)
    elif kind == 'mt': r = np.random.RandomState(seed); s = r.normal(size=(N, 3)); P = np.stack([r.normal(0, .005, N), r.normal(0, .02, N), r.normal(0, .005, N)], 1)
    else:   # сфера Фибоначчи: почти равномерные направления без случайности; смещения — детерминированные
        i = np.arange(N) + 0.5; y = 1 - 2 * i / N; ph = np.pi * (1 + 5 ** 0.5) * i; rr = np.sqrt(1 - y * y)
        s = np.stack([rr * np.cos(ph), y, rr * np.sin(ph)], 1); u = (i * 0.7548776662) % 1; v = (i * 0.5698402910) % 1
        P = np.stack([0.005 * np.cos(2 * np.pi * u), 0.02 * (2 * v - 1), 0.005 * np.sin(2 * np.pi * u)], 1)
    return s / np.linalg.norm(s, axis=1)[:, None], P
def run(T1, T2, s0, P0, hold=10.0, elastic=False, b_end=65.0):
    N = len(s0); T2e = T2 * (b_end - 35) / 30
    dt = min(0.002, (T1 + T2e) / 4000); nst = int((T1 + T2e + hold) / dt)
    s = s0.copy(); P = P0.copy(); V = np.zeros((N, 3)); alive = np.ones(N, bool); how = np.zeros(N, int); lost = np.zeros(N)
    for k in range(nst):
        t = k * dt; bt = 5 + 30 * t / T1 if t < T1 else min(35 + 30 * (t - T1) / T2, b_end)
        A = np.where(alive)[0]
        if len(A) == 0: break
        Q = C.interp(P[A], bt); B = Q[:, 4:7]; G = Q[:, 7:16].reshape(-1, 3, 3)
        s[A] = C.rotate(s[A], B, C.Pp * dt)
        V[A] += np.einsum('nj,nji->ni', s[A], G) * dt; P[A] += V[A] * dt
        for _ in range(2):
            Q = C.interp(P[A], bt); dd = Q[:, 0]; hit = dd < 1.0
            if not hit.any(): break
            g = Q[hit, 1:4]; nh = g / np.maximum(np.linalg.norm(g, axis=1), 1e-12)[:, None]; j = A[hit]
            P[j] += (1.0 - dd[hit])[:, None] * nh
            vn = np.minimum((V[j] * nh).sum(1), 0)
            if elastic: V[j] -= 2 * vn[:, None] * nh
            else: V[j] -= vn[:, None] * nh; lost[j] += 0.5 * vn ** 2
        r = np.linalg.norm(P[A], axis=1); out = r > C.RESC
        if out.any():
            j = A[out]; alive[j] = False; how[j] = np.where(np.abs(P[j, 1]) > 0.8 * r[out], 1, 2)
    r = np.linalg.norm(P, axis=1); rho = np.hypot(P[:, 0], P[:, 2])
    cen = alive & (r < 0.4); thr = alive & ~cen & (np.abs(P[:, 1]) > 0.6) & (np.abs(P[:, 1]) < 1.0) & (rho < 0.3)
    place = np.full(N, 'прочие', dtype=object); place[cen] = 'центр'; place[thr] = 'горловина'; place[how == 1] = 'ось'; place[how == 2] = 'наклонно'
    Bf = C.interp(P, b_end)[:, 4:7]; sB = (s * Bf).sum(1) / np.maximum(np.linalg.norm(Bf, axis=1), 1e-12)
    return place, s, sB, lost, P
def report(tag, s0, res):
    place, s, sB, lost, P = res; up = s0[:, 1] > 0; cen = place == 'центр'
    agree = (cen == up).mean(); same = (cen & up).sum(); jac = same / max((cen | up).sum(), 1)
    print(f"{tag}: исходно s_y>0 — {up.sum()} (средний s_y {s0[up, 1].mean():+.4f}); у центра в конце — {cen.sum()} "
          f"(средний конечный s_y {s[cen, 1].mean():+.4f}); совпадение с селектором «s_y>0» {agree:.3f}, Жаккар {jac:.3f}", flush=True)
    for sg, m in (('+', up), ('−', ~up)):
        cnt = {p: int((place[m] == p).sum()) for p in ('центр', 'горловина', 'ось', 'наклонно', 'прочие')}
        fsg = (np.sign(s[m, 1]) == (1 if sg == '+' else -1)).mean()
        print(f"     исходный знак {sg}: " + ", ".join(f"{p} {c}" for p, c in cnt.items()) + f"; конечный знак s_y тот же у {fsg:.3f}")
    bad = cen != up
    if bad.any(): print(f"     несовпадения: {bad.sum()}, их |s_y| исходно: " + ", ".join(f"{x:.3f}" for x in np.sort(np.abs(s0[bad, 1]))[:12]) +
                        f"; места: " + ", ".join(sorted(set(place[bad]))))
    print(f"     потеря кинетической энергии на стенках: медиана {np.median(lost):.3g}, 90% {np.quantile(lost, .9):.3g}, макс {lost.max():.3g}")
if __name__ == '__main__':
    profiles = [(0.43, 0.69), (2.0, 10.0), (15.0, 30.0)]
    print("(1)–(2) Таблица переходов и выборки; стенки неупругие, выдержка 10")
    for kind, seed in (('pcg', 11), ('pcg', 12), ('pcg', 13), ('mt', 11), ('fib', 0)):
        s0, P0 = sample(kind, seed)
        for T1, T2 in (profiles if (kind, seed) == ('pcg', 11) else profiles[:2]):
            report(f"[{kind} {seed}] T1={T1}, T2={T2}", s0, run(T1, T2, s0, P0))
    print("\n(3) Упругие стенки (выборка pcg 11)")
    s0, P0 = sample('pcg', 11)
    for T1, T2 in profiles:
        report(f"[упруго] T1={T1}, T2={T2}", s0, run(T1, T2, s0, P0, elastic=True))
