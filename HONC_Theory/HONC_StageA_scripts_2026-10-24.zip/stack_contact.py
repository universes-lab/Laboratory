"""Пара «голова к хвосту»: где касаются кольца двух сборок (кольца — провода толщины a = 0,015, касание при
расстоянии осей проводов 2a). Поворот B вокруг общей оси φ = 0…45° (период цикла N = 8 — 45°).
Подход издалека: первое касание D_c(φ). Энергия при касании — M12 со сглаживанием √(r² + a²) [мост].
Запуск: python3 stack_contact.py"""
import numpy as np, sys, os, io, contextlib
from scipy.spatial import cKDTree
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
with contextlib.redirect_stdout(io.StringIO()):
    import stack_two as S
a = 0.015; y = np.array([0, 1.0, 0])
RA = np.vstack(S.rings); tA = cKDTree(RA)
def rr_min(M, Dd):
    _, rB, _ = S.transform(M, Dd * y); return tA.query(np.vstack(rB))[0].min()
def M12a(rB):
    s = 0.0
    for P in S.rings:
        dP = np.roll(P, -1, 0) - P; mP = P + dP / 2
        for Q in rB:
            dQ = np.roll(Q, -1, 0) - Q; mQ = Q + dQ / 2
            r2 = ((mP[:, None] - mQ[None]) ** 2).sum(2)
            s += ((dP @ dQ.T) / np.sqrt(r2 + a * a)).sum()
    return s
res = []
for ph in np.arange(0, 45.01, 2.5):
    M = S.Rot(y, np.radians(ph)); Dc = None
    for Dd in np.arange(3.2, 1.849, -0.005):
        if rr_min(M, Dd) < 2 * a: Dc = Dd + 0.005; break
    if Dc is None: Dc = 1.85
    lo, hi = Dc - 0.005, Dc
    for _ in range(25):
        mid = (lo + hi) / 2
        lo, hi = (lo, mid) if rr_min(M, mid) >= 2 * a else (mid, hi)
    Dc = hi; _, rB, _ = S.transform(M, Dc * y)
    U = -M12a(rB); res.append((ph, Dc, U))
    print(f"φ={ph:4.1f}°: D_c = {Dc:.3f}; U(D_c) = {U:+.2f}; диполи {-2 * S.mA[1] ** 2 / Dc ** 3:+.2f}", flush=True)
res = np.array(res); k = np.argmin(res[:, 1]); j = np.argmin(res[:, 2])
print(f"наименьшее D_c = {res[k, 1]:.3f} при φ = {res[k, 0]:.1f}°; наименьшая U = {res[j, 2]:+.2f} при φ = {res[j, 0]:.1f}° (D_c = {res[j, 1]:.3f})")
