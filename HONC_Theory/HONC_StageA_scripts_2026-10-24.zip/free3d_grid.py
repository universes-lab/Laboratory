"""Трёхмерная разрешённая область для шара радиуса 1 и полное поле колец (без разложения у оси).
Для каждого β: d(x) — расстояние от центра шара до ближайшего тора или кольца (шар допустим при d ≥ 1),
B(x) по Био — Савару (обход «вместе», нормировка как в honc_ring_field.py) и ∂B_j/∂x_i — только там, где d ≥ 0,6
(в запретной области поле не нужно; запас — чтобы трилинейная интерполяция у стенки не брала мусор).
Сетка шаг 0,1, куб |x|, |y|, |z| ≤ 3,5. Результат: free3d_grid.npz. Запуск: python3 free3d_grid.py"""
import importlib.util, numpy as np, os, sys
from multiprocessing import Pool
from scipy.spatial import cKDTree
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
spec = importlib.util.spec_from_file_location('h', os.path.join(here, 'honc_ring_field.py'))
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
import docking as D
BETAS = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 61.56, 62.5, 63.49, 64.25, 65.0]
H = 0.1; ax = np.round(np.arange(-3.5, 3.5 + 1e-9, H), 6); n = len(ax)
X, Y, Z = np.meshgrid(ax, ax, ax, indexing='ij'); PTS = np.stack([X.ravel(), Y.ravel(), Z.ravel()], 1)
def one(beta):
    g = h.build(8, beta)
    obst = np.vstack([D.ring_points(r['C'], r['u'], r['W'], r['p'], r['q'], 3000) for r in g['rings']] +
                     [D.torus_surface(np.array(A), np.array(T) / np.linalg.norm(T), 160) for A, T in zip(g['A'], g['T'])])
    d = cKDTree(obst).query(PTS, workers=1)[0]
    # внутри тела тора расстояние до поверхности мало, но точка запретна: пометим отрицательным
    for A, T in zip(g['A'], g['T']):
        A = np.array(A); T = np.array(T) / np.linalg.norm(T)
        inside = D.memb(PTS, A, T) < 1
        d[inside] = -d[inside]
    m = d >= 0.6
    B = np.zeros((len(PTS), 3)); B[m] = h.field(h.segments(g, 150), PTS[m], chunk=400)
    B = B.reshape(n, n, n, 3)
    G = np.stack([np.stack(np.gradient(B[..., j], H, H, H), -1) for j in range(3)], -2)   # G[..., j, i] = ∂B_j/∂x_i
    print(f"beta={beta}: точек с полем {m.sum()}, допустимых (d ≥ 1) {(d >= 1).sum()}", flush=True)
    return d.reshape(n, n, n).astype(np.float32), B.astype(np.float32), G.astype(np.float32)
if __name__ == '__main__':
    with Pool(2) as p: res = p.map(one, BETAS)
    np.savez_compressed(os.path.join(here, 'free3d_grid.npz'), betas=np.array(BETAS), ax=ax,
                        d=np.stack([r[0] for r in res]), B=np.stack([r[1] for r in res]), G=np.stack([r[2] for r in res]))
    print("сохранено free3d_grid.npz")
