"""Вход этапа Б: две глюонные сборки (N = 8, β = 65°, «вместе») — геометрия соседства и взаимодействие колец [мост].
1. «Голова к хвосту»: B = A, сдвинутая на D вдоль оси (моменты параллельны), поворот вокруг оси 0° или 22,5°.
   «Бок о бок»: сдвиг на D поперёк оси (моменты параллельны) и с переворотом B (антипараллельны).
   D_min — наименьший сдвиг без взаимного проникновения торов и колец (функция принадлежности, как в docking.py).
2. Взаимодействие при фиксированных токах: U = −M12 (μ0 I²/4π = 1), M12 — взаимная индуктивность всех колец A и B (Нейман);
   против точечных диполей U_dip = (m1·m2 − 3(m1·r̂)(m2·r̂))/D³.
Запуск: python3 stack_two.py"""
import importlib.util, numpy as np, os, sys
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
spec = importlib.util.spec_from_file_location('h', os.path.join(here, 'honc_ring_field.py'))
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
import docking as D
TOL = 2e-3
g = h.build(8, 65.0)
tori = [(np.array(A), np.array(T) / np.linalg.norm(T)) for A, T in zip(g['A'], g['T'])]
def ring_oriented(r, n=500):
    t = np.linspace(0, 2 * np.pi, n, endpoint=False)
    P = r['C'] + np.outer(r['p'] * np.cos(t), r['u']) + np.outer(r['q'] * np.sin(t), r['W'])
    return P if r['Om'] > 0 else P[::-1]
rings = [ring_oriented(r) for r in g['rings']]
surf = [D.torus_surface(A, T, 40) for A, T in tori]
mA = h.moment(h.segments(g, 3000))
def Rot(axis, ang):
    axis = axis / np.linalg.norm(axis); K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
    return np.eye(3) + np.sin(ang) * K + (1 - np.cos(ang)) * K @ K
def transform(M, shift):
    return [(M @ A + shift, M @ T) for A, T in tori], [R @ M.T + shift for R in rings], [S @ M.T + shift for S in surf]
def overlap(tB, rB, sB):
    for (A, T), S in zip(tori, surf):
        for (A2, T2), S2 in zip(tB, sB):
            if np.linalg.norm(A - A2) < 3.0 and (D.memb(S2, A, T).min() < 1 - TOL or D.memb(S, A2, T2).min() < 1 - TOL):
                return True
    for R in rB:
        for A, T in tori:
            if D.memb(R, A, T).min() < 1 - TOL: return True
    for R in rings:
        for A2, T2 in tB:
            if D.memb(R, A2, T2).min() < 1 - TOL: return True
    return False
def M12(rB):
    s = 0.0
    for P in rings:
        dP = np.roll(P, -1, 0) - P; mP = P + dP / 2
        for Q in rB:
            dQ = np.roll(Q, -1, 0) - Q; mQ = Q + dQ / 2
            s += ((dP @ dQ.T) / np.linalg.norm(mP[:, None] - mQ[None], axis=2)).sum()
    return s
y = np.array([0, 1.0, 0]); x = np.array([1.0, 0, 0])
cases = [("голова к хвосту, поворот 0°", np.eye(3), y), ("голова к хвосту, поворот 22,5°", Rot(y, np.pi / 8), y),
         ("бок о бок, параллельно", np.eye(3), x), ("бок о бок, антипараллельно (B перевёрнута)", Rot(np.array([0, 0, 1.0]), np.pi), x)]
print(f"момент одной сборки m = {mA[1]:+.3f} (вдоль оси)")
for name, M, e in cases:
    Dmin = None
    for Dd in np.arange(0.2, 9.01, 0.05):
        tB, rB, sB = transform(M, Dd * e)
        if not overlap(tB, rB, sB):
            Dmin = Dd; break
    tB, rB, sB = transform(M, Dmin * e)
    mB = M @ mA
    out = []
    for Dd in (Dmin, Dmin + 1.0, Dmin + 3.0):
        _, rB2, _ = transform(M, Dd * e)
        U = -M12(rB2); r = e
        Ud = (mA @ mB - 3 * (mA @ r) * (mB @ r)) / Dd ** 3
        out.append(f"D={Dd:.2f}: U={U:+.2f}, диполи {Ud:+.2f}")
    print(f"{name}: D_min = {Dmin:.2f}; " + "; ".join(out), flush=True)
