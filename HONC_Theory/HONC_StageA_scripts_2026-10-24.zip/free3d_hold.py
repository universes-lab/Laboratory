"""Сколько должна простоять закрытая камера (выдержка при 65°), чтобы разделение по s_y завершилось,
и зависит ли итог от частоты прецессии P. Модель free3d_closure.py. Запуск: python3 free3d_hold.py"""
import numpy as np, io, contextlib
import free3d_closure as C
def show(tag, R):
    print(f"{tag}: у центра {R['cen']:.2f} (s_y {R['sy']:+.2f}); у горловин {R['thr']:.2f} (s_y {R['thr_sy']:+.2f}); по оси {R['ax']:.2f}; "
          f"наклонно {R['ob']:.2f}; прочие {R['oth']:.2f}", flush=True)
for hold in (0.0, 0.5, 1.0, 2.0, 5.0):
    show(f"T1=0,43, T2=0,69, выдержка {hold:4.1f}", C.run(0.43, 0.69, hold=hold))
for Pp in (10.0, 1000.0):
    C.Pp = Pp
    show(f"P={Pp:6.0f}, T1=0,43, T2=0,69, выдержка 10", C.run(0.43, 0.69))
    show(f"P={Pp:6.0f}, T1=15, T2=30, выдержка 10", C.run(15.0, 30.0))
