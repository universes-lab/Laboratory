'use strict';
const { I } = require('./lib/ia');
const { V } = require('./lib/vec');
const { gapTorusTorus } = require('./lib/geom');
const { hangDirection, rodrigues } = require('./lib/frame');

const A_T1 = V.of([0, 0, 2]);
const A_T2 = V.of([0, 0, 4]);
const Y_HAT = V.of([0, 1, 0]);
const X_HAT = V.of([1, 0, 0]);
const Z_HAT = V.of([0, 0, 1]);

const EX = X_HAT, EY = Y_HAT, EZ = Z_HAT;
const SIDE = 1;

// Build H1 torus per §2 interface v6, link rule with u = e:
//   mirror T' = T_h − 2(T_h·u)·u; n = norm(u × T_h); T_{k+1} = rodrigues(T', n, δ)
function buildH1(rho_I, d_I, psi, delta) {
  const e = hangDirection(rho_I, psi, EX, EY, EZ, SIDE);
  const u_dot_T = e.dot(Y_HAT);
  const T_prime = Y_HAT.sub(e.scale(u_dot_T.mul(I.of(2))));
  const n_raw = e.cross(Y_HAT);
  let n;
  try {
    n = n_raw.unit();
  } catch (err) {
    throw new Error('n degenerate at ρ=' + (rho_I.mid() * 180 / Math.PI));
  }
  const T_H1 = rodrigues(T_prime, n, delta);
  const A_H1 = A_T2.add(e.scale(d_I));
  return { A_H1, T_H1 };
}

function evaluateGapH1T2(rho_I, d_mid, psi, delta) {
  const { A_H1, T_H1 } = buildH1(rho_I, I.of(d_mid), psi, delta);
  return gapTorusTorus(A_H1, T_H1, A_T2, Y_HAT, 180, 1.0);
}

// Solve d_H1(ρ): root of gap(H1, T2) = 0 in d ∈ [dLo, dHi].
// Expanded range [0.3, 3.5] vs rev6 [0.5, 3.0].
// Returns { lo, hi, uncertain, multiplicity }.
//   multiplicity = number of sign-change sub-intervals found.
//   If multiple, take the smallest (first from dLo) — first contact H1 with T2.
//   If none, uncertain = true, bracket = [dLo, dHi] (whole range).
function solveD(rho_I, psi, delta) {
  const dLo = 0.3, dHi = 3.5;
  const N_scan = 40;
  const scanH = (dHi - dLo) / N_scan;
  const straddles = [];
  let prevSign = null;
  let prev_d = dLo;
  for (let j = 0; j <= N_scan; j++) {
    const d = dLo + j * scanH;
    const g = evaluateGapH1T2(rho_I, d, psi, delta);
    const sign = g.isPos() ? '+' : (g.isNeg() ? '-' : '0');
    if (prevSign !== null && prevSign !== '0' && sign !== '0' && prevSign !== sign) {
      straddles.push([prev_d, d]);
    }
    if (sign !== '0') prevSign = sign;
    prev_d = d;
  }
  if (straddles.length === 0) {
    return { lo: dLo, hi: dHi, uncertain: true, multiplicity: 0 };
  }
  // use first (smallest d) straddle — H1 first encounters T2
  const [a0, b0] = straddles[0];
  let a = a0, b = b0;
  const ga = evaluateGapH1T2(rho_I, a, psi, delta);
  let sign_a = ga.isPos() ? '+' : '-';
  for (let iter = 0; iter < 40 && (b - a) > 1e-6; iter++) {
    const m = (a + b) / 2;
    const g = evaluateGapH1T2(rho_I, m, psi, delta);
    const s = g.isPos() ? '+' : (g.isNeg() ? '-' : '0');
    if (s === sign_a) a = m;
    else b = m;
  }
  return { lo: a, hi: b, uncertain: false, multiplicity: straddles.length };
}

// gap(H1, T1) at given ρ.
// Does NOT fall back to [-1, 1] on d.uncertain — instead computes gap on the
// full d-bracket [d.lo, d.hi]. The result is '?' (hasZero) only if the gap
// interval straddles zero, not because d is uncertain.
function gapH1T1(rho_I, psi, delta) {
  const d = solveD(rho_I, psi, delta);
  const d_I = new I(d.lo, d.hi);
  const { A_H1, T_H1 } = buildH1(rho_I, d_I, psi, delta);
  const gap = gapTorusTorus(A_H1, T_H1, A_T1, Y_HAT, 360, 1.0);
  return { gap, d, uncertain: gap.hasZero() };
}

// Sign classification per node:
//   '+' — gap_lo > 0 (definitely positive)
//   '-' — gap_hi < 0 (definitely negative)
//   '?' — gap interval contains 0 (could be root at this node, or uncertain d)
function classify(gap) {
  if (gap.isPos()) return '+';
  if (gap.isNeg()) return '-';
  return '?';
}

function check1_root(psi_deg, delta_deg, rho_lo_deg, rho_hi_deg) {
  const psi = psi_deg * Math.PI / 180;
  const delta = delta_deg * Math.PI / 180;
  const N = 80;
  const step = (rho_hi_deg - rho_lo_deg) / N;
  const grid = [];
  for (let j = 0; j <= N; j++) {
    const rhoDeg = rho_lo_deg + j * step;
    const rho = I.of(rhoDeg * Math.PI / 180);
    const { gap, d, uncertain } = gapH1T1(rho, psi, delta);
    const sign = uncertain ? '?' : classify(gap);
    grid.push({
      rho_deg: rhoDeg, gap_lo: gap.lo, gap_hi: gap.hi,
      d_lo: d.lo, d_hi: d.hi,
      d_multiplicity: d.multiplicity,
      d_widened: d.uncertain,
      sign, uncertain
    });
  }
  // Collect sign changes, allowing '?' as separator between '+' and '-'.
  // A "W candidate" spans from the last definite '+' to the first definite '-'
  // (or reverse), even if intermediate nodes are '?'.
  const changes = [];
  let i = 0;
  while (i < N) {
    const a = grid[i];
    if (a.sign !== '+' && a.sign !== '-') { i++; continue; }
    // look ahead for next definite-sign node of opposite sign
    let j = i + 1;
    let sawUncertain = false;
    while (j <= N && grid[j].sign === '?') { sawUncertain = true; j++; }
    if (j <= N && grid[j].sign !== a.sign) {
      changes.push({
        rho_a_deg: a.rho_deg,
        rho_b_deg: grid[j].rho_deg,
        sign_a: a.sign,
        sign_b: grid[j].sign,
        through_uncertain: sawUncertain,
        uncertain_count: j - i - 1
      });
      i = j;
    } else {
      i++;
    }
  }
  const hasUncertain = grid.some(g => g.uncertain || g.sign === '?');
  const hasWidened = grid.some(g => g.d_widened);
  let W = null, existence, uniqueness;
  if (changes.length === 1) {
    W = [changes[0].rho_a_deg, changes[0].rho_b_deg];
    if (changes[0].through_uncertain || hasWidened) {
      existence = 'undetermined_with_W';
      uniqueness = 'practical_with_uncertain_nodes';
    } else {
      existence = 'yes';
      uniqueness = 'practical_one_change';
    }
  } else if (changes.length === 0 && !hasUncertain && !hasWidened) {
    existence = 'no';
    uniqueness = 'no_change';
  } else if (changes.length === 0) {
    existence = 'undetermined';
    uniqueness = 'undetermined_grid';
  } else {
    existence = 'undetermined';
    uniqueness = 'multiple_sign_changes';
  }
  let minGapLo = Infinity, minGapLoRho = null;
  let maxGapHi = -Infinity, maxGapHiRho = null;
  let countUncertain = 0, countWidened = 0, maxMultiplicity = 0;
  for (const g of grid) {
    if (g.gap_lo < minGapLo) { minGapLo = g.gap_lo; minGapLoRho = g.rho_deg; }
    if (g.gap_hi > maxGapHi) { maxGapHi = g.gap_hi; maxGapHiRho = g.rho_deg; }
    if (g.uncertain) countUncertain++;
    if (g.d_widened) countWidened++;
    if (g.d_multiplicity > maxMultiplicity) maxMultiplicity = g.d_multiplicity;
  }
  return {
    check: 'check1_root',
    config: { psi_deg, delta_deg, rho_bracket_deg: [rho_lo_deg, rho_hi_deg], with: 'T1', side: 1 },
    grid_points: N + 1,
    grid_step_deg: step,
    grid: grid,
    grid_summary: {
      min_gap_lo: minGapLo, min_gap_lo_rho_deg: minGapLoRho,
      max_gap_hi: maxGapHi, max_gap_hi_rho_deg: maxGapHiRho,
      count_uncertain: countUncertain,
      count_widened: countWidened,
      max_d_multiplicity: maxMultiplicity
    },
    sign_changes: changes,
    W_deg: W,
    existence,
    uniqueness,
    notes: 'Existence via IVT on gap_H1_T1(ρ) = 0; sign-changes may pass through "?" nodes. gapH1T1 computes gap on full [d.lo, d.hi] bracket — does not fall back to [-1,1] on d uncertainty. solveD scans d ∈ [0.3, 3.5]; if multiple straddles, uses the smallest (first contact with T2) and sets multiplicity > 1 (open question for review). sin/cos via Math.* with field 1e-12 — practical envelope. buildH1 applies full §2 link rule (mirror axis then rotate).'
  };
}

module.exports = { check1_root };
