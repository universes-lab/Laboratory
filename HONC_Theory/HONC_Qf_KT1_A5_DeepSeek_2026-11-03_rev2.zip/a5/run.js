'use strict';
const fs = require('fs');
const path = require('path');
const { check1_root } = require('./check1_root');
const { check2_penetration } = require('./check2_penetration');

function main() {
  const outDir = process.env.KT1_OUT;
  if (!outDir) {
    console.error('KT1_OUT not set');
    process.exit(2);
  }
  console.log('a5/run.js: starting check1_root...');
  const c1 = check1_root();
  console.log(`  existence=${c1.existence} uniqueness=${c1.uniqueness} W_deg=${JSON.stringify(c1.W_deg)}`);
  fs.writeFileSync(path.join(outDir, 'a5.check1.root.json'), JSON.stringify(c1, null, 2));

  let c2;
  if (c1.W_deg) {
    const W = c1.W_deg;
    let d_lo = Infinity, d_hi = -Infinity;
    for (const g of c1.grid) {
      if (g.rho_deg >= W[0] && g.rho_deg <= W[1]) {
        if (g.d_lo < d_lo) d_lo = g.d_lo;
        if (g.d_hi > d_hi) d_hi = g.d_hi;
      }
    }
    if (d_lo === Infinity) { d_lo = 1.5; d_hi = 2.0; }
    console.log(`a5/run.js: starting check2_penetration W_deg=${JSON.stringify(W)} d∈[${d_lo.toFixed(4)}, ${d_hi.toFixed(4)}]...`);
    c2 = check2_penetration(W, d_lo, d_hi);
    console.log(`  found=${c2.found} theta_deg=${c2.theta_deg} dist_hi=${c2.dist_H1_body_hi}`);
  } else {
    c2 = {
      check: 'check2_penetration',
      found: false,
      error: 'no_W_from_check1',
      coverage: 'NONE',
      notes: 'check1 returned no single-interval W; check2 cannot run.'
    };
    console.log('a5/run.js: no W from check1, check2 skipped.');
  }
  fs.writeFileSync(path.join(outDir, 'a5.check2.result.json'), JSON.stringify(c2, null, 2));
  console.log('a5/run.js: done. Wrote a5.check1.root.json, a5.check2.result.json to KT1_OUT.');
}

main();
