#!/bin/bash
W=/tmp/claude-0/-home-claude/6935880b-5ec3-55fe-acf8-346b2d2a291f/scratchpad/runs6; H=/tmp/claude-0/-home-claude/6935880b-5ec3-55fe-acf8-346b2d2a291f/scratchpad/runs5/harness; MK=/tmp/claude-0/-home-claude/6935880b-5ec3-55fe-acf8-346b2d2a291f/scratchpad/runs5/mk
A=$W/HONC_Qf_KT1_D3_DeepSeek_2026-11-10_rev5_1.zip; SH=5e9282cbb7c227e4e2ed52323d04e51d3eab514287172ce25344a108b6072b19
python3 -I $H/kt1_sandbox_run.py --mode d3-run --label d3rev51-ACCEPTANCE --archive $A --sha $SH --entry d3/run.js --kernel /tmp/claude-0/-home-claude/6935880b-5ec3-55fe-acf8-346b2d2a291f/scratchpad/runs5/kernel/HONC_Qf_KT1_Kernel_2026-11-02.zip > $W/run_kernel.json 2> $W/run_kernel.err
echo "kernel exit $? $(date -u +%H:%M:%S)"
cp "$(python3 -I -c "import json;print(json.load(open('$W/run_kernel.json'))['out_zip'])")" $W/out/
for m in m1 m2a m2b m3v2 m4 m5 m8 m8b m12 m13 m14; do
  python3 -I $H/kt1_mutant_run.py --mutant-registry /tmp/claude-0/-home-claude/6935880b-5ec3-55fe-acf8-346b2d2a291f/scratchpad/runs5/m8b/registry.json --mutant-id $m \
    --mode d3-run --label MUTANT-r51-$m --archive $A --sha $SH --entry d3/run.js --kernel $MK/HONC_Qf_KT1_Mutant_$m.zip > $W/run_$m.json 2> $W/run_$m.err
  rc=$?
  cp "$(python3 -I -c "import json;print(json.load(open('$W/run_$m.json'))['out_zip'])" 2>/dev/null)" $W/out/ 2>/dev/null
  echo "$m exit $rc $(date -u +%H:%M:%S)"
done
echo ALL_DONE
