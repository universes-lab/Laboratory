# Исполнитель КТ-1: сводка прогонов rev5 на мутантах. «Поймали» — испытание PASS на ядре и не PASS на мутанте.
# Два столбца: итог зафиксированного набора и переоценка 11 ключей contacts[0].* (reeval.py) — диагностика, не итог набора.
import json, sys, glob, os, zipfile
sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
from reeval import reeval
expected = json.load(open(sys.argv[1])); outdir = sys.argv[2]; kzip = sys.argv[3]; PFX = sys.argv[4] if len(sys.argv) > 4 else 'MUTANT-r5-'
MAP = {'m1':'m1','m2a':'m2','m2b':'m2','m3v2':'m3','m4':'m4','m5':'m5','m8':'m8','m8b':'m8','m12':'m12','m13':'m13','m14':'m14'}
_, kout = reeval(kzip, expected)
k_off = {t: v[0] for t, v in kout.items()}; k_re = {t: v[1] for t, v in kout.items()}
rows = []
for m in MAP:
    zs = sorted(glob.glob(f'{outdir}/{PFX}{m}-*-out.zip'))
    if not zs: rows.append({'mutant': m, 'missing': True}); continue
    zp = zs[-1]; res, out = reeval(zp, expected)
    summ = json.loads(zipfile.ZipFile(zp).read('log/summary.json'))
    off = {t: v[0] for t, v in out.items()}; re_ = {t: v[1] for t, v in out.items()}
    cnt = lambda d: tuple(sum(1 for s in d.values() if s == x) for x in ('PASS', 'FAIL', 'ERROR'))
    decl = expected['mutants'][MAP[m]]['caught_by']
    c_off = [t for t in off if k_off.get(t) == 'PASS' and off[t] != 'PASS']
    c_re = [t for t in re_ if k_re.get(t) == 'PASS' and re_[t] != 'PASS']
    rows.append({'mutant': m, 'zip': os.path.basename(zp), 'runner': summ.get('runner_status'), 'test': summ.get('test_status'),
                 'src_unchanged': summ.get('src_unchanged'), 'kernel_unchanged': summ.get('kernel_unchanged'),
                 'official': cnt(off), 'reeval': cnt(re_), 'declared': decl,
                 'caught_official_declared': [t for t in c_off if t in decl], 'caught_official_other': [t for t in c_off if t not in decl],
                 'caught_reeval_declared': [t for t in c_re if t in decl], 'caught_reeval_other': [t for t in c_re if t not in decl],
                 'problems': {t: [p for p in r.get('problems', [])][:4] for t, r in ((r['id'], r) for r in res['results']) if t in c_re or t in c_off}})
print(json.dumps(rows, ensure_ascii=False, indent=1))
