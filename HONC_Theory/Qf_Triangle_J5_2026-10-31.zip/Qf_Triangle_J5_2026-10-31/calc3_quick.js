// Переносится ли узел из полосы ∏=+1 на 5+3: гребёнка и чередование, навесы все вверх или через один.
const QN=require('./core.js'), C=require('./calc1.js');const {sub,len}=QN;
function rho1(psi,d){let lo=0,hi=89,prev=null;for(let r=0;r<=89;r+=1){const g=QN.build(C.cfgOf(r,psi,d));const v=C.gap(g.tori[1],g.tori[C.hangOf(g)]);if(prev!==null&&prev>0&&v<=0){lo=r-1;hi=r;break;}prev=v;}for(let k=0;k<40;k++){const m=(lo+hi)/2,g=QN.build(C.cfgOf(m,psi,d));(C.gap(g.tori[1],g.tori[C.hangOf(g)])>0?lo=m:hi=m);}return lo-1e-7;}
function graphJ5(g){ // все касания и согласуемость знаков (раскраска с чётностью ребра)
  const n=g.tori.length, E=[];
  for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){if(len(sub(g.tori[i].A,g.tori[j].A))>2.05)continue;const c=C.contact(g.tori[i],g.tori[j]);if(c.gap<1e-5)E.push([i,j,c.g,c.cs]);}
  const s=new Array(n).fill(0);let ok=true;
  for(let st=0;st<n;st++){if(s[st])continue;s[st]=1;const q=[st];while(q.length){const a=q.shift();for(const [i,j,gg] of E){const b=i===a?j:j===a?i:-1;if(b<0)continue;const want=s[a]*gg;if(!s[b]){s[b]=want;q.push(b);}else if(s[b]!==want)ok=false;}}}
  return {ok,E};
}
for (const [psi,d] of [[54,10],[53,0]]) {
  const r=rho1(psi,d);
  for (const [name,sides] of [['гребёнка',[1,1,1]],['чередование',[1,-1,1]]]) for (const [ud,ups] of [['все вверх',[1,1,1]],['через один',[1,-1,1]]]) {
    const hangs=[1,2,3].map((host,i)=>({host,side:sides[i],rho:r,psi:ups[i]>0?psi:360-psi,delta:ups[i]>0?d:-d}));
    const g=QN.build({N:5,links:[],hangs}); const fc=C.fullCheck(g); const J=graphJ5(g);
    const hangTouch=J.E.filter(([i,j])=>g.tori[i].kind==='hang'&&g.tori[j].kind==='hang').length;
    const why=[];const c=fc.c;if(c.torus.bad.length)why.push('2D–2D ×'+c.torus.bad.length);if(c.ringBody.bad.length)why.push('1D–2D ×'+c.ringBody.bad.length);if(c.cusp.bad.length)why.push('касп');if(c.ringRing.bad.length)why.push('1D–1D');if(c.a15bad.length)why.push('A-15');
    console.log(`ψ ${psi} δ ${d} ρ ${r.toFixed(2)} | ${name}, ${ud}: тела/кольца ${fc.ok?'допустимо':'нарушено ('+why.join(', ')+')'}; касаний ${J.E.length} (навес–навес ${hangTouch}); J5 по всему графу ${J.ok?'согласуется':'НЕ согласуется'}`);
  }
}
