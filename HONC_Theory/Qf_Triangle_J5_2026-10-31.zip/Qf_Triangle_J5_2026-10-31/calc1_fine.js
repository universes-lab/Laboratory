const QN=require('./core.js'), C=require('./calc1.js');
const [P0,P1,PS,D0,D1,DS]=process.argv.slice(2).map(Number);
const out=[]; const t0=Date.now();
function g1(r,psi,d){const g=QN.build(C.cfgOf(r,psi,d));const h=C.hangOf(g);if(g.fail.length||h<0)return null;return {g,h,v:C.gap(g.tori[1],g.tori[h])};}
for(let psi=P0;psi<=P1+1e-9;psi+=PS) for(let d=D0;d<=D1+1e-9;d+=DS){
  let prev=null, pr=null;
  for(let r=0;r<=89;r+=1){const x=g1(r,psi,d); if(!x){prev=null;continue;}
    if(prev!==null&&prev>0&&x.v<=0){let lo=r-1,hi=r;for(let k=0;k<32;k++){const m=(lo+hi)/2,y=g1(m,psi,d);if(!y)break;(y.v>0?lo=m:hi=m);}
      const z=g1((lo+hi)/2,psi,d); if(z){const fc=C.fullCheck(z.g), p=C.product(z.g,1);
        out.push({psi,d,rho:(lo+hi)/2,ok:fc.ok,rc:fc.rc,ord:fc.ord,bad:[fc.c.torus.bad.length,fc.c.ringBody.bad.length,fc.c.cusp.bad.length,fc.c.ringRing.bad.length].join(''),p:p.p,cs:p.edges.map(e=>+e.cs.toFixed(3)),ax:p.edges.map(e=>[+e.ax1.toFixed(2),+e.ax2.toFixed(2)])});}
      break;}
    prev=x.v;}
}
require('fs').writeFileSync(__dirname+'/calc1_fine_out.json',JSON.stringify(out));
const ok=out.filter(x=>x.ok), pos=ok.filter(x=>x.p>0);
console.log('лучей',out.length,'допустимых первых касаний',ok.length,'из них ∏=+1',pos.length,'время',((Date.now()-t0)/1000).toFixed(0),'с');
if(pos.length){const ps=pos.map(x=>x.psi), ds=pos.map(x=>x.d), rs=pos.map(x=>x.rho), cs=pos.map(x=>x.cs[2]);
 console.log('ψ',Math.min(...ps),'…',Math.max(...ps),' δ',Math.min(...ds),'…',Math.max(...ds),' ρ',Math.min(...rs).toFixed(2),'…',Math.max(...rs).toFixed(2),' cos(A–навес)',Math.min(...cs),'…',Math.max(...cs));
 const zero=pos.filter(x=>Math.abs(x.d)<1e-9); console.log('при δ = 0:', zero.length);
 // карта: строки δ, столбцы ψ
 const P=[...new Set(out.map(x=>x.psi))].sort((a,b)=>a-b), D=[...new Set(out.map(x=>x.d))].sort((a,b)=>a-b);
 console.log('      '+P.map(p=>String(p%10)).join(''));
 D.forEach(d=>{console.log(String(d).padStart(5)+' '+P.map(p=>{const x=out.find(y=>y.psi===p&&y.d===d); if(!x)return ' '; if(!x.ok) return '·'; return x.p>0?'+':'−';}).join(''));});
}
