const QN=require('./core.js'), C=require('./calc1.js');const {sub,len}=QN;
function first(psi,d){let lo=0,hi=89,prev=null;for(let r=0;r<=89;r+=1){const g=QN.build(C.cfgOf(r,psi,d));const v=C.gap(g.tori[1],g.tori[C.hangOf(g)]);if(prev!==null&&prev>0&&v<=0){lo=r-1;hi=r;break;}prev=v;}for(let k=0;k<40;k++){const m=(lo+hi)/2,g=QN.build(C.cfgOf(m,psi,d));(C.gap(g.tori[1],g.tori[C.hangOf(g)])>0?lo=m:hi=m);}return lo;}
const name=(g,ri)=>{const r=g.rings[ri];return (r.kind==='hang'?'кольцо навеса':'кольцо '+r.owner+'→'+(r.target<0?'св':r.target));};
for (const [psi,d] of [[54,10],[56,10],[53,0],[54,0]]) {
  const r0=first(psi,d), g=QN.build(C.cfgOf(r0,psi,d)), c=QN.check(g,false);
  // точное мин. расстояние между кольцами: плотная выборка + уточнение
  let best={m:9};
  for(let i=0;i<g.rings.length;i++)for(let j=i+1;j<g.rings.length;j++){const A=QN.ringPoints(g.rings[i],1440),B=QN.ringPoints(g.rings[j],1440);
    const sh=[g.rings[i].owner,g.rings[i].target].filter(e=>e>=0&&(e===g.rings[j].owner||e===g.rings[j].target)).map(e=>g.tori[e].A);
    let m=9;for(const X of A){if(sh.some(S=>len(sub(X,S))<0.05))continue;for(let k=0;k<B.length;k+=4){const dd=len(sub(X,B[k]));if(dd<m)m=dd;}}
    if(m<best.m)best={m,i,j,shared:sh.length};}
  console.log(`ψ ${psi} δ ${d} ρ ${r0.toFixed(2)}: нарушения кольцо–тело: ${c.ringBody.bad.map(([ri,ti,m])=>name(g,ri)+' в торе '+(g.tori[ti].kind==='hang'?'навеса':ti)+' ('+m.toFixed(3)+')').join('; ')||'нет'}; ближайшие кольца: ${name(g,best.i)} и ${name(g,best.j)}, ${best.m.toFixed(4)}${best.shared?' (общий касп)':''}`);
}
