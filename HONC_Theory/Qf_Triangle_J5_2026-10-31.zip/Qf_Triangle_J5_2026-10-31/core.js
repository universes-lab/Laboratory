// ===== Узел Qf-нити: геометрия ЛМ1 без обязательного зеркального правила, собственные оси латчеров, проверки.
// Единица длины R = 1. Рогатый тор a = b = 1/2: средняя окружность радиуса 1/2, трубка 1/2.
// Кольцо — плоский эллипс длины 2π через центры двух торов, касательный к их осям в каспах (ЛМ1).
// Оси торов звена и хорда лежат в плоскости кольца (касание в каспе). Зеркальное правило — частный случай δ = 0.
const QN = (function () {
  const TWO_PI = 2 * Math.PI;
  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const len = a => Math.hypot(a[0], a[1], a[2]);
  const nrm = a => { const l = len(a); return l > 1e-15 ? mul(a, 1 / l) : [0, 0, 0]; };
  const rot = (x, k, ang) => { const c = Math.cos(ang), s = Math.sin(ang); return add(add(mul(x, c), mul(cross(k, x), s)), mul(k, dot(k, x) * (1 - c))); };
  const reflect = (T, n) => sub(T, mul(n, 2 * dot(T, n)));
  const rad = d => d * Math.PI / 180, deg = r => r * 180 / Math.PI;
  const angle = (a, b) => deg(Math.acos(Math.max(-1, Math.min(1, dot(nrm(a), nrm(b))))));

  function perim(p, q) { const a = Math.max(p, q), b = Math.min(p, q), h = ((a - b) / (a + b)) ** 2; return Math.PI * (a + b) * (1 + 3 * h / (10 + Math.sqrt(4 - 3 * h))); }

  // ---------- эллипс длины 2π через A и B, касательный к осям TA (в A) и TB (в B) ----------
  // Пучок коник L_A·L_B − μ·y² = 0 касается обеих прямых в A и B при любом μ; μ подбирается по длине.
  function ringGeneral(A, TA, u, d, TB) {
    const X = nrm(u);
    let Yv = sub(TA, mul(X, dot(TA, X)));
    if (len(Yv) < 1e-9) return null;                       // ось тора вдоль хорды — вырождение
    Yv = nrm(Yv);
    const a = Math.atan2(dot(TA, Yv), dot(TA, X));        // ∈ (0, π)
    let tbx = dot(TB, X), tby = dot(TB, Yv);
    if (tby < 0) { tbx = -tbx; tby = -tby; }
    const outOfPlane = Math.abs(dot(TB, nrm(cross(X, Yv))));
    const b = Math.atan2(tby, tbx);
    const p1 = -Math.sin(a), q1 = Math.cos(a), p2 = -Math.sin(b), q2 = Math.cos(b), r2 = d * Math.sin(b);
    const cA = p1 * p2, cB = p1 * q2 + q1 * p2, cD = p1 * r2, cE = q1 * r2;
    if (cA < 1e-9) return null;
    const muStar = q1 * q2 - cB * cB / (4 * cA);
    function ell(mu) {
      const cC = q1 * q2 - mu;
      const det = 4 * cA * cC - cB * cB;
      if (det <= 0) return null;
      const xc = (cB * cE - 2 * cC * cD) / det, yc = (cB * cD - 2 * cA * cE) / det;
      const Fc = 0.5 * (cD * xc + cE * yc);
      const tr = cA + cC, dd = Math.sqrt(Math.max(0, (cA - cC) ** 2 + cB * cB));
      const l1 = (tr + dd) / 2, l2 = (tr - dd) / 2;
      if (l2 <= 0 || Fc >= 0) return null;
      const s1 = Math.sqrt(-Fc / l1), s2 = Math.sqrt(-Fc / l2);
      // собственный вектор для l1
      let e1 = Math.abs(cB) > 1e-14 ? [cB / 2, l1 - cA] : (cA >= cC ? [1, 0] : [0, 1]);
      const n1 = Math.hypot(e1[0], e1[1]); e1 = [e1[0] / n1, e1[1] / n1];
      const e2 = [-e1[1], e1[0]];
      return { xc, yc, s1, s2, e1, e2, P: perim(s1, s2) };
    }
    // длина растёт от 2d (μ → −∞) до ∞ (μ → μ*)
    let lo = 0, hi = 30; // t = ln(μ* − μ): μ = μ* − e^t
    const P = t => { const e = ell(muStar - Math.exp(t)); return e ? e.P : Infinity; };
    lo = -40; if (P(hi) > TWO_PI) return null;
    for (let k = 0; k < 100; k++) { const m = (lo + hi) / 2; (P(m) > TWO_PI ? lo = m : hi = m); }
    const e = ell(muStar - Math.exp((lo + hi) / 2));
    if (!e) return null;
    const to3 = (x, y) => add(A, add(mul(X, x), mul(Yv, y)));
    const E1 = add(mul(X, e.e1[0]), mul(Yv, e.e1[1])), E2 = add(mul(X, e.e2[0]), mul(Yv, e.e2[1]));
    const C = to3(e.xc, e.yc);
    const N = nrm(cross(E1, E2));                          // нормаль ориентации параметризации
    const ring = { A, B: add(A, mul(X, d)), u: X, W: Yv, C, E1, E2, s1: e.s1, s2: e.s2, N, d, a, b, outOfPlane,
      rmax: Math.max(e.s1, e.s2) };
    return ring;
  }
  function ringAt(r, t) { return add(r.C, add(mul(r.E1, r.s1 * Math.cos(t)), mul(r.E2, r.s2 * Math.sin(t)))); }
  function ringTan(r, t) { return add(mul(r.E1, -r.s1 * Math.sin(t)), mul(r.E2, r.s2 * Math.cos(t))); }
  function ringPoints(r, n) { const out = []; for (let k = 0; k < n; k++) out.push(ringAt(r, k / n * TWO_PI)); return out; }
  function ringParamOf(r, P) { const v = sub(P, r.C); return Math.atan2(dot(v, r.E2) / r.s2, dot(v, r.E1) / r.s1); }

  // ---------- торы ----------
  function circlePts(A, T, n) {
    const a = Math.abs(T[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0];
    const e1 = nrm(cross(T, a)), e2 = cross(T, e1), out = [];
    for (let k = 0; k < n; k++) { const t = k / n * TWO_PI; out.push(add(A, add(mul(e1, 0.5 * Math.cos(t)), mul(e2, 0.5 * Math.sin(t))))); }
    return out;
  }
  function distToMid(X, A, T) { const r = sub(X, A), z = dot(r, T), rho = len(sub(r, mul(T, z))); return Math.hypot(rho - 0.5, z); }
  function nearestOnMid(X, A, T) { const r = sub(X, A), z = dot(r, T); let p = sub(r, mul(T, z)); const l = len(p); p = l > 1e-12 ? mul(p, 0.5 / l) : mul(nrm(cross(T, [T[1], T[2], T[0]])), 0.5); return add(A, p); }
  function midGap(A1, T1, A2, T2, n = 96) {
    let best = Infinity, bt = 0; const pts = circlePts(A1, T1, n);
    pts.forEach((X, i) => { const g = distToMid(X, A2, T2); if (g < best) { best = g; bt = i; } });
    // уточнение по параметру
    const a = Math.abs(T1[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0], e1 = nrm(cross(T1, a)), e2 = cross(T1, e1);
    let lo = (bt - 1) / n * TWO_PI, hi = (bt + 1) / n * TWO_PI;
    const f = t => distToMid(add(A1, add(mul(e1, 0.5 * Math.cos(t)), mul(e2, 0.5 * Math.sin(t)))), A2, T2);
    for (let k = 0; k < 40; k++) { const m1 = lo + (hi - lo) / 3, m2 = hi - (hi - lo) / 3; (f(m1) < f(m2) ? hi = m2 : lo = m1); }
    const t = (lo + hi) / 2, q1 = add(A1, add(mul(e1, 0.5 * Math.cos(t)), mul(e2, 0.5 * Math.sin(t))));
    return { gap: Math.min(best, f(t)), q1, q2: nearestOnMid(q1, A2, T2) };
  }
  const support = u => 0.5 * Math.sqrt(Math.max(0, 1 - u * u)) + 0.5;
  // расстояние касания двух торов вдоль направления u (тела трубок соприкасаются)
  function contactDistance(TA, TB, u, mirror) {
    if (mirror) return 2 * support(Math.min(Math.abs(dot(TA, u)), 1));
    let lo = 0.3, hi = 2.05;
    for (let k = 0; k < 36; k++) { const m = (lo + hi) / 2; (midGap([0, 0, 0], TA, mul(u, m), TB, 72).gap < 1 ? lo = m : hi = m); }
    return hi;
  }

  // ---------- сборка ----------
  // cfg = { N, links: [{theta, phi, delta}] (N штук; последнее кольцо свободное), hangs: [{host, side, rho, psi, delta}] }
  function nodeFrame(ez, T) {
    let ey = sub(T, mul(ez, dot(T, ez)));
    if (len(ey) < 1e-6) ey = nrm(cross(ez, [1, 0, 0])); else ey = nrm(ey);
    const ex = cross(ey, ez);
    return { ex, ey, ez };
  }
  function makeLink(A, T, u, delta) {
    const mirror = Math.abs(delta) < 1e-9;
    let n = cross(u, T); if (len(n) < 1e-9) return null; n = nrm(n);
    const Tm = nrm(reflect(T, u));
    const T2 = mirror ? Tm : nrm(rot(Tm, n, delta));
    const d = contactDistance(T, T2, u, mirror);
    const ring = ringGeneral(A, T, u, d, T2);
    if (!ring) return null;
    return { A2: add(A, mul(u, d)), T2, d, ring, mirror, cosg: Math.abs(dot(T, u)) };
  }
  function build(cfg) {
    const tori = [], rings = [], frames = [];
    const T0 = [0, 1, 0];
    let A = [0, 0, 0], T = T0, ez = [0, 0, 1];
    tori.push({ A, T, kind: 'chain', idx: 0, label: '0', owner: -1 });
    const fail = [];
    for (let k = 0; k < cfg.N; k++) {
      const f = nodeFrame(ez, T); frames.push(f);
      const L = cfg.links[k] || { theta: 0, phi: 0, delta: 0 };
      const th = rad(L.theta), ph = rad(L.phi);
      const u = nrm(add(mul(f.ez, Math.cos(th)), mul(add(mul(f.ex, Math.cos(ph)), mul(f.ey, Math.sin(ph))), Math.sin(th))));
      const last = k === cfg.N - 1;
      const lk = makeLink(A, T, u, last ? 0 : rad(L.delta || 0));
      if (!lk) { fail.push('звено ' + k); break; }
      rings.push({ ...lk.ring, owner: k, target: last ? -1 : k + 1, kind: last ? 'free' : 'chain', idx: k, label: String(k), cosg: lk.cosg, mirror: lk.mirror });
      if (!last) { A = lk.A2; T = lk.T2; tori.push({ A, T, kind: 'chain', idx: k + 1, label: String(k + 1) }); }
      ez = u;
    }
    const nChain = tori.length;
    (cfg.hangs || []).forEach((h, j) => {
      if (h.host >= nChain) { fail.push('навес ' + (j + 1) + ': нет тора-хозяина'); return; }
      const host = tori[h.host];
      const f = frames[h.host];
      const e0 = mul(f.ex, h.side), r = rad(h.rho || 0), p = rad(h.psi || 0);
      const e = nrm(add(mul(e0, Math.cos(r)), mul(add(mul(f.ez, -Math.cos(p)), mul(f.ey, Math.sin(p))), Math.sin(r))));
      const lk = makeLink(host.A, host.T, e, rad(h.delta || 0));
      if (!lk) { fail.push('навес ' + (j + 1)); return; }
      const ti = tori.length;
      tori.push({ A: lk.A2, T: lk.T2, kind: 'hang', idx: ti, host: h.host, side: h.side, label: 'Н' + (j + 1), hang: j });
      rings.push({ ...lk.ring, owner: ti, target: h.host, kind: 'hang', idx: rings.length, label: 'Н' + (j + 1), hang: j, cosg: lk.cosg, mirror: lk.mirror });
    });
    // кольца по торам: собственное и входящие
    tori.forEach((t, i) => { t.own = rings.findIndex(r => r.owner === i); t.inRings = rings.map((r, ri) => r.target === i ? ri : -1).filter(x => x >= 0); });
    return { cfg, tori, rings, frames, fail };
  }

  // ---------- ориентации: Y по J5 (соседние торы вращаются встречно), обход колец по закону узла ----------
  // Знаки условные: затравка — тор 0 (Y = +ось) и кольцо 0 (обход такой, что X×Y смотрит к центру кольца).
  function orient(g) {
    const { tori, rings } = g;
    const Y = tori.map(() => null), sig = rings.map(() => 0), pass = tori.map(() => 0), conflicts = [];
    Y[0] = tori[0].T.slice();
    // J5: Y соседа — со знаком, противоположным зеркальному образу
    let changed = true;
    while (changed) {
      changed = false;
      rings.forEach(r => {
        if (r.target < 0) return;
        const i = r.owner, j = r.target, u = nrm(sub(tori[j].A, tori[i].A));
        if (Y[i] && !Y[j]) { const ref = mul(reflect(Y[i], u), -1); Y[j] = dot(tori[j].T, ref) >= 0 ? tori[j].T.slice() : mul(tori[j].T, -1); changed = true; }
        else if (Y[j] && !Y[i]) { const ref = mul(reflect(Y[j], u), -1); Y[i] = dot(tori[i].T, ref) >= 0 ? tori[i].T.slice() : mul(tori[i].T, -1); changed = true; }
      });
    }
    tori.forEach((t, i) => { if (!Y[i]) Y[i] = t.T.slice(); });
    const passSign = (ri, ti, s) => { const r = rings[ri]; const t = ringParamOf(r, tori[ti].A); return Math.sign(dot(mul(ringTan(r, t), s), Y[ti])) || 1; };
    // затравка: кольцо 0
    if (rings.length) {
      const r0 = rings[0], disp = sub(r0.C, tori[0].A);
      sig[0] = dot(cross(r0.N, Y[0]), disp) >= 0 ? 1 : -1;
      pass[0] = passSign(0, 0, sig[0]);
      if (r0.target >= 0) pass[r0.target] = passSign(0, r0.target, sig[0]);
    }
    changed = true;
    while (changed) {
      changed = false;
      rings.forEach((r, ri) => {
        if (sig[ri]) return;
        const ends = [r.owner, r.target].filter(x => x >= 0);
        const known = ends.find(t => pass[t]);
        if (known === undefined) return;
        sig[ri] = passSign(ri, known, 1) === pass[known] ? 1 : -1;
        ends.forEach(t => { const p = passSign(ri, t, sig[ri]); if (!pass[t]) pass[t] = p; else if (pass[t] !== p) conflicts.push([ri, t]); });
        changed = true;
      });
    }
    rings.forEach((r, ri) => { if (!sig[ri]) sig[ri] = 1; });
    // проверка закона узла по всем отверстиям
    tori.forEach((t, ti) => {
      const rs = rings.map((r, ri) => (r.owner === ti || r.target === ti) ? ri : -1).filter(x => x >= 0);
      const signs = rs.map(ri => passSign(ri, ti, sig[ri]));
      if (signs.some(s => s !== signs[0])) conflicts.push([-1, ti]);
    });
    const lat = tori.map((t, i) => {
      const ri = t.own; if (ri < 0) return null;
      const r = rings[ri], Xv = mul(r.N, sig[ri]), Yv = Y[i], Zv = nrm(cross(Xv, Yv));
      const disp = sub(r.C, t.A), dispU = nrm(disp);
      const dispPerp = nrm(sub(disp, mul(t.T, dot(disp, t.T))));
      return { torus: i, ring: ri, X: Xv, Y: Yv, Z: Zv, disp, dispU, dispPerp, cls: dot(Zv, disp) >= 0 ? 'XYZ' : 'YXZ', ZdotDisp: dot(Zv, dispPerp) };
    });
    return { Y, sig, lat, conflicts };
  }

  // ---------- проверки ЛМ1, A-5, A-15 ----------
  function check(g, fast) {
    const { tori, rings } = g;
    const SEC = fast ? 32 : 64, RS = fast ? 120 : 240, RC = fast ? 48 : 72;
    const res = { torus: { min: Infinity, bad: [] }, ringBody: { min: Infinity, bad: [] }, cusp: { min: Infinity, bad: [] }, ringRing: { min: Infinity, bad: [] }, a15: [], a15bad: [], tangent: 0, fail: g.fail.slice() };
    for (let i = 0; i < tori.length; i++) for (let j = i + 1; j < tori.length; j++) {
      if (len(sub(tori[i].A, tori[j].A)) > 2.05) continue;
      const mids = circlePts(tori[i].A, tori[i].T, SEC);
      let m = Infinity; for (const X of mids) m = Math.min(m, distToMid(X, tori[j].A, tori[j].T));
      const gap = m - 1;
      res.torus.min = Math.min(res.torus.min, gap);
      if (gap < -2e-3) res.torus.bad.push([i, j, gap]);
    }
    const pts = rings.map(r => ringPoints(r, RS));
    rings.forEach((r, ri) => {
      const own = [r.owner, r.target].filter(e => e >= 0);
      tori.forEach((t, ti) => {
        if (len(sub(t.A, r.C)) > r.rmax + 1.1) return;
        const isOwn = own.includes(ti);
        let m = Infinity;
        for (const X of pts[ri]) { if (isOwn && len(sub(X, t.A)) < 0.12) continue; m = Math.min(m, distToMid(X, t.A, t.T) - 0.5); }
        if (isOwn) { res.cusp.min = Math.min(res.cusp.min, m); if (m < -2e-3) res.cusp.bad.push([ri, ti, m]); }
        else { res.ringBody.min = Math.min(res.ringBody.min, m); if (m < -2e-3) res.ringBody.bad.push([ri, ti, m]); }
      });
      // касание оси в каспе: касательная кольца в центре тора параллельна оси
      own.forEach(ti => { const t = ringParamOf(r, tori[ti].A); res.tangent = Math.max(res.tangent, len(cross(nrm(ringTan(r, t)), tori[ti].T))); });
    });
    const coarse = rings.map(r => ringPoints(r, RC));
    for (let i = 0; i < rings.length; i++) for (let j = i + 1; j < rings.length; j++) {
      const ri = rings[i], rj = rings[j];
      if (len(sub(ri.C, rj.C)) > ri.rmax + rj.rmax + 0.2) continue;
      const shared = [ri.owner, ri.target].filter(e => e >= 0 && (e === rj.owner || e === rj.target)).map(e => tori[e].A);
      const far = X => !shared.some(S => len(sub(X, S)) < 0.25);
      let m = Infinity;
      for (const X of coarse[i]) { if (!far(X)) continue; for (const Y of coarse[j]) { const dd = len(sub(X, Y)); if (dd < m) m = dd; } }
      if (m < 0.15) { m = Infinity; for (const X of pts[i]) { if (!far(X)) continue; for (const Y of pts[j]) { const dd = len(sub(X, Y)); if (dd < m) m = dd; } } }
      res.ringRing.min = Math.min(res.ringRing.min, m);
      if (m < 0.01) res.ringRing.bad.push([i, j, m]);
    }
    tori.forEach((t, ti) => { const n = rings.filter(r => r.owner === ti || r.target === ti).length; res.a15.push(n); if (n > 3) res.a15bad.push(ti); });
    res.ok = !res.torus.bad.length && !res.ringBody.bad.length && !res.cusp.bad.length && !res.ringRing.bad.length && !res.a15bad.length && !res.fail.length;
    return res;
  }

  // точка касания двух торов (середина между ближайшими точками средних окружностей)
  function contactPoint(t1, t2) { const m = midGap(t1.A, t1.T, t2.A, t2.T, 96); return { P: mul(add(m.q1, m.q2), 0.5), gap: m.gap - 1 }; }

  return { build, orient, check, contactPoint, ringPoints, ringAt, ringTan, ringParamOf, ringGeneral, contactDistance, makeLink, nodeFrame, circlePts,
    add, sub, mul, dot, cross, len, nrm, rot, reflect, rad, deg, angle, perim };
})();
if (typeof module !== 'undefined') module.exports = QN;
