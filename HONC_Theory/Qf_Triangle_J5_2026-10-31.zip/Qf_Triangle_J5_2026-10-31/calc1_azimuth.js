// Сцена захвата: навес подходит поперёк нити под азимутом α от экватора хозяина (к его оси) и отклоняется назад на λ.
// e = cosλ (cosα ex + sinα ey) − sinλ ez. При каждом α: λ первого касания, знак ∏ по треугольнику, допустимость, путь.
const QN=require('./core.js'), C=require('./calc1.js');
const toRP=(a,l)=>{const A=a*Math.PI/180,L=l*Math.PI/180;return [Math.acos(Math.cos(L)*Math.cos(A))*180/Math.PI, Math.atan2(Math.cos(L)*Math.sin(A),Math.sin(L))*180/Math.PI];};
function at(a,l,d){const [r,p]=toRP(a,l);const g=QN.build(C.cfgOf(r,p,d));const h=C.hangOf(g);if(g.fail.length||h<0)return null;return {g,h};}
for (const d of [0,10]) {
  console.log('δ =',d,'   α | λ касания | с каким тором | cos(пред.–навес) | ∏ | допустимо | путь');
  for (let a=0;a<=88;a+=4) {
    let prev=null, hit=null;
    for (let l=0;l<=88;l+=1){const x=at(a,l,d);if(!x){prev=null;continue;}const gs={};[0,1,3,4].forEach(j=>gs[j]=C.gap(x.g.tori[j],x.g.tori[x.h]));
      if(prev){const j=[1,0,3,4].find(j=>prev[j]>0&&gs[j]<=0);if(j!==undefined){hit={j,l};break;}}prev=gs;}
    if(!hit){console.log(String(a).padStart(6),'| касания нет до 88°');continue;}
    let lo=hit.l-1,hi=hit.l;for(let k=0;k<36;k++){const m=(lo+hi)/2,x=at(a,m,d);(C.gap(x.g.tori[hit.j],x.g.tori[x.h])>0?lo=m:hi=m);}
    const x=at(a,lo,d), fc=C.fullCheck(x.g), pr=hit.j===1?C.product(x.g,1):null;
    let pathOk=true;for(let l=0;l<lo;l+=0.5){const y=at(a,l,d);if(!y||!C.fullCheck(y.g).ok){pathOk=false;break;}}
    console.log(String(a).padStart(6),'|',lo.toFixed(2).padStart(6),'|',String(hit.j).padStart(3),'|',pr?pr.edges[2].cs.toFixed(3).padStart(7):'   —   ','|',pr?(pr.p>0?' +':' −'):' ','|',fc.ok?' да':' нет','|',pathOk?'допустим':'нарушение');
  }
}
