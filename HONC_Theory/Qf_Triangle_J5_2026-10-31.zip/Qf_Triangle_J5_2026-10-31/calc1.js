// Расчёт 1 Раунда 2. Проверяемое утверждение:
// «В семействе навеса (ρ, ψ, δ) с ЛМ1-связью к хозяину и точными поверхностями торов существует касание
//  тора навеса с предыдущим тором нити, при котором произведение знаков J5 по треугольнику ∏g = +1
//  и нет проникновений». Если нет — треугольник исключён во всём семействе плоских колец.
// Знак касания g = sign(v1·v2), v = T × (c − A) — скорость основного вращения в точке касания
// при опорных осях; ∏g по циклу не зависит от выбора опор.
const QN = require('./core.js');
const { add, sub, mul, dot, cross, len, nrm } = QN;
const HOST = 2, N = 5, PREV = 1, NEXT = 3;

const cfgOf = (rho, psi, delta) => ({ N, links: [], hangs: [{ host: HOST, side: 1, rho, psi, delta }] });
function hangOf(g) { const h = g.tori.length - 1; return g.tori[h] && g.tori[h].kind === 'hang' ? h : -1; }

function gap(t1, t2) {
  const D = len(sub(t1.A, t2.A));
  if (D > 2.05) return D - 2;           // нижняя оценка зазора, касания нет
  return QN.contactPoint(t1, t2).gap;
}
function nearestMid(c, t) { const r = sub(c, t.A), z = dot(r, t.T); const p = sub(r, mul(t.T, z)); return add(t.A, mul(nrm(p), 0.5)); }
// знак J5 и тип касания
function contact(t1, t2) {
  const m = QN.contactPoint(t1, t2), c = m.P;
  const v1 = cross(t1.T, sub(c, t1.A)), v2 = cross(t2.T, sub(c, t2.A));
  const cs = dot(v1, v2) / (len(v1) * len(v2) + 1e-15);
  const n1 = nrm(sub(c, nearestMid(c, t1))), n2 = nrm(sub(c, nearestMid(c, t2)));
  return { g: Math.sign(cs), cs, gap: m.gap, ax1: Math.abs(dot(n1, t1.T)), ax2: Math.abs(dot(n2, t2.T)) };
}
const cycles = { 0: [[0, 1], [1, 2], [2, 'h'], [0, 'h']], 1: [[1, 2], [2, 'h'], [1, 'h']], 3: [[2, 3], [2, 'h'], [3, 'h']], 4: [[2, 3], [3, 4], [2, 'h'], [4, 'h']] };
function product(g, j) {
  const h = hangOf(g); let p = 1, minAbs = 1; const edges = [];
  for (const [a, b] of cycles[j]) {
    const c = contact(g.tori[a], g.tori[b === 'h' ? h : b]);
    p *= c.g; minAbs = Math.min(minAbs, Math.abs(c.cs)); edges.push(c);
  }
  return { p, minAbs, edges };
}
// кривизна кольца в каспах (контроль страницы λ-молекул: радиус ≥ 0,5)
function cuspRadius(r, P) { const t = QN.ringParamOf(r, P); const k = r.s1 * r.s2 / Math.pow(r.s1 ** 2 * Math.sin(t) ** 2 + r.s2 ** 2 * Math.cos(t) ** 2, 1.5); return 1 / k; }
// точный признак для колец одного каспа: полуплоскости вокруг оси различны
function cuspOrder(g) {
  let worst = 180;
  g.tori.forEach((t, ti) => {
    const ws = g.rings.filter(r => r.owner === ti || r.target === ti).map(r => { const w = sub(r.C, t.A); return nrm(sub(w, mul(t.T, dot(w, t.T)))); });
    for (let a = 0; a < ws.length; a++) for (let b = a + 1; b < ws.length; b++) worst = Math.min(worst, QN.angle(ws[a], ws[b]));
  });
  return worst;
}
function fullCheck(g) {
  const c = QN.check(g, false);
  let rc = Infinity;
  g.rings.forEach(r => { [r.owner, r.target].filter(e => e >= 0).forEach(ti => { rc = Math.min(rc, cuspRadius(r, g.tori[ti].A)); }); });
  const ord = cuspOrder(g);
  const otherGaps = [];
  return { ok: c.ok && rc >= 0.5 - 1e-6 && ord > 0.5, c, rc, ord };
}

module.exports = { cfgOf, hangOf, gap, contact, product, fullCheck, cuspOrder, HOST, PREV, NEXT };

if (require.main === module) {
  const t0 = Date.now();
  const STEP_R = +(process.argv[2] || 1), STEP_P = +(process.argv[3] || 3), DMAX = +(process.argv[4] || 60), STEP_D = +(process.argv[5] || 5);
  const found = [];       // все допустимые касания с тором навеса
  let rays = 0, broken = 0;
  for (let delta = -DMAX; delta <= DMAX + 1e-9; delta += STEP_D) for (let psi = 0; psi < 360; psi += STEP_P) {
    rays++;
    let prev = null;
    for (let rho = 0; rho <= 89.0001; rho += STEP_R) {
      const g = QN.build(cfgOf(rho, psi, delta)); const h = hangOf(g);
      if (g.fail.length || h < 0) { prev = null; broken++; continue; }
      const gs = {}; [0, 1, 3, 4].forEach(j => { gs[j] = gap(g.tori[j], g.tori[h]); });
      if (prev) for (const j of [0, 1, 3, 4]) {
        if ((prev.gs[j] > 0) !== (gs[j] > 0)) {
          // уточнение нуля зазора с тором j
          let lo = prev.rho, hi = rho, glo = prev.gs[j];
          for (let k = 0; k < 30; k++) {
            const m = (lo + hi) / 2, gm = QN.build(cfgOf(m, psi, delta)); const hm = hangOf(gm);
            if (gm.fail.length || hm < 0) break;
            const v = gap(gm.tori[j], gm.tori[hm]);
            if ((v > 0) === (glo > 0)) { lo = m; glo = v; } else hi = m;
          }
          const r0 = (lo + hi) / 2, gz = QN.build(cfgOf(r0, psi, delta));
          if (gz.fail.length || hangOf(gz) < 0) continue;
          const fc = fullCheck(gz), pr = product(gz, j);
          found.push({ psi, delta, rho: r0, j, entering: prev.gs[j] > 0, ok: fc.ok, why: fc.ok ? '' : whyBad(fc), p: pr.p, minAbs: pr.minAbs, edges: pr.edges.map(e => ({ g: e.g, cs: +e.cs.toFixed(3), ax: [+e.ax1.toFixed(2), +e.ax2.toFixed(2)] })) });
        }
      }
      prev = { rho, gs };
    }
  }
  function whyBad(fc) {
    const c = fc.c, w = [];
    if (c.torus.bad.length) w.push('2D–2D'); if (c.ringBody.bad.length) w.push('1D–2D'); if (c.cusp.bad.length) w.push('касп');
    if (c.ringRing.bad.length) w.push('1D–1D'); if (c.a15bad.length) w.push('A-15'); if (c.fail.length) w.push('сборка');
    if (fc.rc < 0.5 - 1e-6) w.push('кривизна<0,5'); if (fc.ord <= 0.5) w.push('порядок в каспе');
    return w.join(',');
  }
  require('fs').writeFileSync(__dirname + '/calc1_out.json', JSON.stringify({ STEP_R, STEP_P, DMAX, STEP_D, rays, broken, found }, null, 0));
  const S = (f) => found.filter(f).length;
  console.log('лучей', rays, 'несобранных точек', broken, 'нулей зазора', found.length, 'время', ((Date.now() - t0) / 1000).toFixed(1), 'с');
  for (const j of [1, 3, 0, 4]) {
    console.log(`тор ${j}: нулей ${S(x => x.j === j)}, допустимых ${S(x => x.j === j && x.ok)}, допустимых входов ${S(x => x.j === j && x.ok && x.entering)}, допустимых с ∏=+1 ${S(x => x.j === j && x.ok && x.p > 0)}`);
  }
}
