const QN=require('./core.js'), C=require('./calc1.js');
const {sub,add,mul,dot,cross,len,nrm}=QN;
// плотная независимая проверка касания: минимум по двум параметрам средних окружностей
function circ(t,ang){const a=Math.abs(t.T[0])<0.9?[1,0,0]:[0,1,0],e1=nrm(cross(t.T,a)),e2=cross(t.T,e1);return add(t.A,add(mul(e1,0.5*Math.cos(ang)),mul(e2,0.5*Math.sin(ang))));}
function dense(t1,t2){let best={d:1e9};const n=720;for(let i=0;i<n;i++)for(let j=0;j<n;j+=1){}
 // грубо 360×360, затем уточнение
 for(let i=0;i<360;i++){const p=circ(t1,i/360*2*Math.PI);for(let j=0;j<360;j++){const q=circ(t2,j/360*2*Math.PI);const d=len(sub(p,q));if(d<best.d)best={d,i,j};}}
 let a=best.i/360*2*Math.PI,b=best.j/360*2*Math.PI,s=2*Math.PI/360;
 for(let k=0;k<60;k++){let improved=false;for(const [da,db] of [[s,0],[-s,0],[0,s],[0,-s],[s,s],[-s,-s],[s,-s],[-s,s]]){const d=len(sub(circ(t1,a+da),circ(t2,b+db)));if(d<best.d){best.d=d;a+=da;b+=db;improved=true;}}if(!improved)s/=2;}
 const p=circ(t1,a),q=circ(t2,b),c=mul(add(p,q),0.5);
 const v1=cross(t1.T,sub(c,t1.A)),v2=cross(t2.T,sub(c,t2.A));
 return {gap:best.d-1,cs:dot(v1,v2)/(len(v1)*len(v2))};}
for (const [psi,d] of [[54,10],[53,0],[52,-4],[55,16]]) {
  // точка первого касания
  let lo=0,hi=89,prev=null; for(let r=0;r<=89;r+=1){const g=QN.build(C.cfgOf(r,psi,d));const h=C.hangOf(g);const v=C.gap(g.tori[1],g.tori[h]);if(prev!==null&&prev>0&&v<=0){lo=r-1;hi=r;break;}prev=v;}
  for(let k=0;k<40;k++){const m=(lo+hi)/2,g=QN.build(C.cfgOf(m,psi,d));(C.gap(g.tori[1],g.tori[C.hangOf(g)])>0?lo=m:hi=m);}
  const r0=lo, g=QN.build(C.cfgOf(r0,psi,d)), h=C.hangOf(g), fc=C.fullCheck(g), pr=C.product(g,1);
  const dn=dense(g.tori[1],g.tori[h]), dh=dense(g.tori[2],g.tori[h]), d12=dense(g.tori[1],g.tori[2]);
  console.log(`ψ ${psi} δ ${d}: ρ ${r0.toFixed(3)}  допустимо ${fc.ok}  ∏ ${pr.p}`);
  console.log(`   cos скоростей (быстрый/плотный): 1–2 ${pr.edges[0].cs.toFixed(4)}/${d12.cs.toFixed(4)}  хозяин–навес ${pr.edges[1].cs.toFixed(4)}/${dh.cs.toFixed(4)}  пред.–навес ${pr.edges[2].cs.toFixed(4)}/${dn.cs.toFixed(4)} (зазор ${dn.gap.toExponential(1)})`);
  console.log(`   запасы: тела ${fc.c.torus.min.toFixed(4)}, кольцо–тело ${fc.c.ringBody.min.toFixed(4)}, касп ${fc.c.cusp.min.toFixed(4)}, кольцо–кольцо ${fc.c.ringRing.min.toFixed(4)}, радиус кривизны в каспе ${fc.rc.toFixed(3)}, порядок ${fc.ord.toFixed(1)}°`);
  const e=sub(g.tori[h].A,g.tori[2].A), en=nrm(e); console.log(`   навес: направление от хозяина (поперёк, вдоль оси хозяина, назад) = (${en[0].toFixed(3)}, ${en[1].toFixed(3)}, ${(-en[2]).toFixed(3)}), расстояние ${len(e).toFixed(3)}; ось навеса (${g.tori[h].T.map(x=>x.toFixed(3)).join(', ')}); супер-Z навеса вдоль нити ${(-en[2]).toFixed(3)}`);
  // путь по лучу от поперечного положения
  let worst={tor:9,rb:9,cu:9,rr:9}, other=0, flips=0, lastSign=null, okAll=true, firstBad=null;
  for(let r=0;r<r0;r+=0.25){const gg=QN.build(C.cfgOf(r,psi,d));const hh=C.hangOf(gg);const f=C.fullCheck(gg);
    if(!f.ok&&firstBad===null)firstBad=r; okAll=okAll&&f.ok;
    const cg=C.contact(gg.tori[2],gg.tori[hh]); const s=Math.sign(cg.cs); if(lastSign!==null&&s!==lastSign)flips++; lastSign=s;
    for(const j of [0,1,3,4]) if(C.gap(gg.tori[j],gg.tori[hh])<=1e-6) other++;
    worst.rb=Math.min(worst.rb,f.c.ringBody.min); worst.rr=Math.min(worst.rr,f.c.ringRing.min); worst.cu=Math.min(worst.cu,f.c.cusp.min);}
  console.log(`   путь ρ 0 → ${r0.toFixed(2)}: всё допустимо ${okAll}${firstBad!==null?' (первое нарушение при ρ '+firstBad+')':''}, касаний с другими торами ${other}, смен знака J5 хозяин–навес ${flips}; мин. запасы кольцо–тело ${worst.rb.toFixed(3)}, касп ${worst.cu.toFixed(3)}, кольцо–кольцо ${worst.rr.toFixed(3)}`);
}
