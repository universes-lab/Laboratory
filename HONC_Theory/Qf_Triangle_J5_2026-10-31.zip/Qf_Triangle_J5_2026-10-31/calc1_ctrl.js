const QN=require('./core.js'), C=require('./calc1.js');
function first(psi,delta,j){let prev=null;for(let r=0;r<=89;r+=0.5){const g=QN.build(C.cfgOf(r,psi,delta));const h=C.hangOf(g);if(g.fail.length||h<0)continue;const v=C.gap(g.tori[j],g.tori[h]);if(prev!==null&&prev>0&&v<=0){let lo=r-0.5,hi=r;for(let k=0;k<30;k++){const m=(lo+hi)/2,gm=QN.build(C.cfgOf(m,psi,delta));(C.gap(gm.tori[j],gm.tori[C.hangOf(gm)])>0?lo=m:hi=m);}return (lo+hi)/2;}prev=v;}return null;}
let t=Date.now();
for (const [psi,j] of [[0,1],[180,3]]) { const r=first(psi,0,j); const g=QN.build(C.cfgOf(r,psi,0)); const p=C.product(g,j); const fc=C.fullCheck(g);
 console.log('psi',psi,'contact torus',j,'rho',r.toFixed(4),'prod',p.p,'edges',p.edges.map(e=>[e.g,e.cs.toFixed(3),e.ax1.toFixed(2),e.ax2.toFixed(2)].join(' ')).join(' | '),'ok',fc.ok,'rc',fc.rc.toFixed(3),'ord',fc.ord.toFixed(1)); }
// transverse
const g0=QN.build(C.cfgOf(0,0,0)); const fc0=C.fullCheck(g0); console.log('transverse ok',fc0.ok,'rc',fc0.rc.toFixed(3),'ord',fc0.ord.toFixed(1), 'J5 host-hang', C.contact(g0.tori[2],g0.tori[g0.tori.length-1]).g);
console.log('ms', Date.now()-t);
t=Date.now(); for(let i=0;i<200;i++){const g=QN.build(C.cfgOf(20,40,10)); C.gap(g.tori[1],g.tori[5]);} console.log('ms per build+gap', (Date.now()-t)/200);
