#!/usr/bin/env python3
# Мутант м3, редакция 2. Редакция 1 (выборка во ВСЕХ вызовах minimize) не дала завершить прогон: построение корня касания
# (fix, wp2_linkroot) тоже идёт через минимизацию, и на А4 прогон упёрся в предел 1800 с. Это свойство мутанта, а не набора.
# Редакция 2 вносит ту же ошибку «PASSED по выборке» только в ПРОВЕРОЧНЫЕ пути: зазор G-4 в torusPairs, кольцо–тор G-5а/G-5г
# и библиотечная точка K.minimize. Построение (корни, d звена, кольца) остаётся сертифицированным.
#   python3 -I build_m3v2.py <замороженный.zip> <папка вывода>
import hashlib, json, sys, zipfile
FROZEN = 'ecb35112d85911c810d70942f3655ddc25ed19c9047befff2cb7dfbf6ea268ea'
src, out = sys.argv[1], sys.argv[2]
assert hashlib.sha256(open(src, 'rb').read()).hexdigest() == FROZEN
SAMPLED = ("// МУТАНТ м3 (ред. 2): минимум по выборке 512 узлов + локальное уточнение; вилка ±1e-9 объявлена CERTIFIED\n"
 "function minimizeSampled({ f, a, b }) {\n"
 "  const N = 512, mid = x => { const v = f(x); return (v[0] + v[1]) / 2; };\n"
 "  let bx = a, bv = Infinity;\n"
 "  for (let i = 0; i <= N; i++) { const x = a + (b - a) * i / N, v = mid(x); if (v < bv) { bv = v; bx = x; } }\n"
 "  let lo = Math.max(a, bx - (b - a) / N), hi = Math.min(b, bx + (b - a) / N);\n"
 "  for (let k = 0; k < 80; k++) { const m1 = lo + (hi - lo) / 3, m2 = hi - (hi - lo) / 3; if (mid(m1) < mid(m2)) hi = m2; else lo = m1; }\n"
 "  const x = (lo + hi) / 2, v = Math.min(mid(x), bv);\n"
 "  return { min: [v - 1e-9, v + 1e-9], argmin: [[x - 1e-9, x + 1e-9]], evals: N + 161, converged: true, completeness: 'CERTIFIED' };\n"
 "}\n")
edits = [
 ('kt1/wp0_cert.js', "module.exports = { minimize, root, perimeter };", SAMPLED + "module.exports = { minimize, minimizeSampled, root, perimeter };"),
 ('kt1/wp2_gap.js', "const { minimize } = require('./wp0_cert');", "const { minimize, minimizeSampled } = require('./wp0_cert');"),
 ('kt1/wp2_gap.js', "  const r = minimize({ f, dfBox: dGapBox(t1, e1, e2, t2),", "  const r = (opts.sampled ? minimizeSampled : minimize)({ f, dfBox: dGapBox(t1, e1, e2, t2),"),
 ('kt1/wp4_contacts.js', "    const g = torusGap(a, b, { tol: 1e-13 + 4 * w });", "    const g = torusGap(a, b, { tol: 1e-13 + 4 * w, sampled: true });"),
 ('kt1/wp2_ringtorus.js', "const { minimize } = require('./wp0_cert');", "const { minimizeSampled: minimize } = require('./wp0_cert');"),
 ('kt1/kt1.js', "  minimize: C.minimize,", "  minimize: C.minimizeSampled,"),
]
zin = zipfile.ZipFile(src); names = zin.namelist(); files = {n: zin.read(n) for n in names}
for p, o, n in edits:
    s = files[p].decode('utf-8'); c = s.count(o); assert c == 1, f'{p}: {c} × {o[:60]!r}'; files[p] = s.replace(o, n).encode('utf-8')
zp = f'{out}/HONC_Qf_KT1_Mutant_m3v2.zip'
with zipfile.ZipFile(zp, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, date_time=(2026, 11, 5, 0, 0, 0)); zi.external_attr = zin.getinfo(n).external_attr; z.writestr(zi, files[n])
sha = hashlib.sha256(open(zp, 'rb').read()).hexdigest()
reg = json.load(open(f'{out}/registry.json'))
for m in reg['mutants']:
    if m['id'] == 'm3': m['status'] = 'ред. 1 — прогон не завершён: TIMEOUT 1800 с на А4 (выборка в построении корня); заменён на m3v2'
reg['mutants'] = [m for m in reg['mutants'] if m['id'] != 'm3v2'] + [{'id': 'm3v2', 'description': 'PASSED по выборке (ред. 2): выборка только в проверочных путях — G-4 в torusPairs, G-5а/G-5г, K.minimize; построение сертифицированное',
   'sha256': sha, 'archive': zp.split('/')[-1], 'edits': [{'file': p, 'old': o, 'new': n} for p, o, n in edits]}]
json.dump(reg, open(f'{out}/registry.json', 'w'), ensure_ascii=False, indent=1)
print('m3v2', sha)
