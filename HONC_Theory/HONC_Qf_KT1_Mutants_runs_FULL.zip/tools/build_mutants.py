#!/usr/bin/env python3
# Мутанты КТ-1 (план § 6.3): каждая — копия замороженной сборки ecb35112 с ОДНОЙ намеренно внесённой ошибкой.
# Замороженная сборка не трогается (читается из архива). Правки — точные замены строк; каждая обязана встретиться ровно один раз.
# Выход: mutants/HONC_Qf_KT1_Mutant_<id>.zip (та же раскладка kt1/…) и mutants/registry.json (id, описание, правки, sha256).
#   python3 -I build_mutants.py <замороженный.zip> <папка вывода>
import hashlib, json, sys, zipfile
FROZEN = 'ecb35112d85911c810d70942f3655ddc25ed19c9047befff2cb7dfbf6ea268ea'
src, out = sys.argv[1], sys.argv[2]
assert hashlib.sha256(open(src, 'rb').read()).hexdigest() == FROZEN, 'не замороженная сборка'
M = [
 ('m1', 'Приближённая формула периметра (Рамануджан II, как в qfnode/core.js) вместо сертифицированного AGM; вилка-точка',
  [('kt1/wp0_cert.js', "function perimeter(s1, s2) {\n",
    "function perimeter(s1, s2) {\n  { // МУТАНТ м1: приближённый периметр вместо AGM\n    const A0 = Array.isArray(s1) ? (s1[0] + s1[1]) / 2 : s1, B0 = Array.isArray(s2) ? (s2[0] + s2[1]) / 2 : s2;\n    const a = Math.max(A0, B0), b = Math.min(A0, B0), h = ((a - b) / (a + b)) ** 2;\n    const P = Math.PI * (a + b) * (1 + 3 * h / (10 + Math.sqrt(4 - 3 * h)));\n    return { value: [P, P], completeness: 'CERTIFIED' };\n  }\n")]),
 ('m2a', 'Нет проверки у каспа, сторона (а): кольца с общим каспом считаются разделёнными без сравнения полуплоскостей (R-1 всегда PASSED)',
  [('kt1/wp3_rings.js', "if (vec.dot(n1, n2)[1] < 1) {   // ν1 ≠ ν2 доказано", "if (true) {   // МУТАНТ м2а: полуплоскости не сравниваются")]),
 ('m2b', 'Нет проверки у каспа, сторона (б): кривизна кольца в каспе своего тора не проверяется (G-5в выключена; окно фиксированное)',
  [('kt1/wp2_ringtorus.js', "  if (kap[1] < 0) return mk(kap, cuspC, 'FORBIDDEN',", "  if (false) return mk(kap, cuspC, 'FORBIDDEN',"),
   ('kt1/wp2_ringtorus.js', "  if (kap[0] <= 0) cuspReason =", "  if (false) cuspReason ="),
   ('kt1/wp2_ringtorus.js', "  else if (kap[0] < kmin) cuspReason =", "  else if (false) cuspReason ="),
   ('kt1/wp2_ringtorus.js', "    if (!Theta) cuspReason = 'G-5г: окрестность исключения r₀ не получена';", "    // МУТАНТ м2б: без окрестности — фиксированное окно, без причины")]),
 ('m3', 'PASSED по выборке: minimize — выборка 512 узлов + локальное уточнение, вилка ±1e-9 объявлена CERTIFIED (без гарантии Липшица)',
  [('kt1/wp0_cert.js', "function minimize({ f, dfBox, a, b, L, tol = 1e-12, maxEval = 200000, keepTol }) {\n",
    "function minimize({ f, dfBox, a, b, L, tol = 1e-12, maxEval = 200000, keepTol }) {\n  { // МУТАНТ м3: минимум по выборке, а не гарантированный поиск\n    const N = 512, mid = x => { const v = f(x); return (v[0] + v[1]) / 2; };\n    let bx = a, bv = Infinity;\n    for (let i = 0; i <= N; i++) { const x = a + (b - a) * i / N, v = mid(x); if (v < bv) { bv = v; bx = x; } }\n    let lo = Math.max(a, bx - (b - a) / N), hi = Math.min(b, bx + (b - a) / N);\n    for (let k = 0; k < 80; k++) { const m1 = lo + (hi - lo) / 3, m2 = hi - (hi - lo) / 3; if (mid(m1) < mid(m2)) hi = m2; else lo = m1; }\n    const x = (lo + hi) / 2, v = Math.min(mid(x), bv);\n    return { min: [v - 1e-9, v + 1e-9], argmin: [[x - 1e-9, x + 1e-9]], evals: N + 161, converged: true, completeness: 'CERTIFIED' };\n  }\n")]),
 ('m4', 'K-6 только по циклам: неканонические существенные рёбра и мосты не учитываются (J5-CANON PASSED без них)',
  [('kt1/wp4_contacts.js', "  else if (!nonCanon.length) canon = { verdict: 'PASSED'", "  else if (true) canon = { verdict: 'PASSED'")]),
 ('m5', 'Параллельность по допуску: |T_A × T_B| < 1e-9 ⇒ PARALLEL-ESTABLISHED без тождества',
  [('kt1/wp4_contacts.js', "  return x[0] > 0 ? { parallel: 'NON-PARALLEL', cross_abs: x } : { parallel: 'PARALLEL-UNCERTAIN', cross_abs: x };",
    "  if (x[1] < 1e-9) return { parallel: 'PARALLEL-ESTABLISHED', parallel_basis: { rule: 'МУТАНТ м5: допуск 1e-9' } };\n  return x[0] > 0 ? { parallel: 'NON-PARALLEL', cross_abs: x } : { parallel: 'PARALLEL-UNCERTAIN', cross_abs: x };")]),
 ('m8', 'Кандидат как подтверждённое касание: 0 в вилке зазора ⇒ IMPOSED (без ветвления K-1)',
  [('kt1/wp4_contacts.js', "g.gap[1] < 0 ? 'PENETRATION' : 'CANDIDATE';", "g.gap[1] < 0 ? 'PENETRATION' : 'IMPOSED'; // МУТАНТ м8")]),
 ('m12', 'Граф касаний только из звеньев: CONTACT-ONLY не входит в граф J5',
  [('kt1/wp4_contacts.js', "  const touching = contacts.filter(c => c.existence === 'IMPOSED' || c.existence === 'CANDIDATE');",
    "  const touching = contacts.filter(c => (c.existence === 'IMPOSED' || c.existence === 'CANDIDATE') && c.cls === 'LINK'); // МУТАНТ м12")]),
 ('m13', 'Условие кривизны в каспе с допуском 1e-6: равенство и малое превышение κ_r над 2 не дают ни FORBIDDEN, ни «вилка содержит 2»',
  [('kt1/wp2_ringtorus.js', "  if (kap[1] < 0) return mk(kap, cuspC, 'FORBIDDEN',", "  if (kap[1] < -1e-6) return mk(kap, cuspC, 'FORBIDDEN',"),
   ('kt1/wp2_ringtorus.js', "  if (kap[0] <= 0) cuspReason =", "  if (kap[0] <= -1e-6) cuspReason =")]),
 ('m14', 'Допуск на проникновение 2e-3 (порог прежнего ядра): зазор тор–тор и запас кольцо–тор выше −2e-3 считаются допустимыми',
  [('kt1/wp4_contacts.js', "else existence = g.gap[0] > 0 ? 'SEPARATED'", "else existence = g.gap[0] > -2e-3 ? 'SEPARATED'"),
   ('kt1/wp2_ringtorus.js', "const verdictOf = (m, canForbid = true) => (m[0] > 0 ? 'PASSED'", "const verdictOf = (m, canForbid = true) => (m[0] > -2e-3 ? 'PASSED'")]),
]
zin = zipfile.ZipFile(src); names = zin.namelist(); base = {n: zin.read(n) for n in names}
reg = {'frozen_kernel_sha256': FROZEN, 'source': src.split('/')[-1], 'mutants': []}
for mid, desc, edits in M:
    files = dict(base)
    for path, old, new in edits:
        s = files[path].decode('utf-8'); c = s.count(old)
        assert c == 1, f'{mid}: строка встречается {c} раз в {path}: {old[:60]!r}'
        files[path] = s.replace(old, new).encode('utf-8')
    zp = f'{out}/HONC_Qf_KT1_Mutant_{mid}.zip'
    with zipfile.ZipFile(zp, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for n in names:
            zi = zipfile.ZipInfo(n, date_time=(2026, 11, 5, 0, 0, 0)); zi.external_attr = zin.getinfo(n).external_attr
            z.writestr(zi, files[n])
    sha = hashlib.sha256(open(zp, 'rb').read()).hexdigest()
    reg['mutants'].append({'id': mid, 'description': desc, 'sha256': sha, 'archive': zp.split('/')[-1],
                           'edits': [{'file': p, 'old': o, 'new': n} for p, o, n in edits]})
    print(mid, sha)
json.dump(reg, open(f'{out}/registry.json', 'w'), ensure_ascii=False, indent=1)
