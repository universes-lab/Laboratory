#!/bin/bash
# Прогон зафиксированного набора Д-3 rev4 на каждом мутанте — последовательно, ожидание по PID.
S=/tmp/claude-0/-home-claude/6935880b-5ec3-55fe-acf8-346b2d2a291f/scratchpad
A=$S/d3_pack/HONC_Qf_KT1_D3_DeepSeek_2026-11-05_rev4.zip
for m in ${MUTANTS:-m1 m2a m2b m3 m4 m5 m8 m12 m13 m14}; do
  python3 -I $S/harness/kt1_mutant_run.py --mutant-registry $S/mutants/registry.json --mutant-id $m \
    --mode d3-run --label MUTANT-$m --archive $A --sha 5cc71cc7caffd15a33d5fce27132ae56daa036b2bb07bf16c4fce7093577071a \
    --entry d3/run.js --kernel $S/mutants/HONC_Qf_KT1_Mutant_$m.zip > $S/mutants/run_$m.json 2> $S/mutants/run_$m.err &
  PID=$!; wait $PID; rc=$?; cp "$(python3 -c "import json;print(json.load(open('$S/mutants/run_$m.json'))['out_zip'])" 2>/dev/null)" $S/mutants/out/ 2>/dev/null; echo "$m exit $rc $(date -u +%H:%M:%S)"
done
echo ALL_DONE
