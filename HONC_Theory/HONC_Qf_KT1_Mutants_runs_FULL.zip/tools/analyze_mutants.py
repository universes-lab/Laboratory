#!/usr/bin/env python3
# Сводка прогонов набора на мутантах: какие испытания изменили исход относительно замороженного ядра,
# пойман ли мутант испытаниями из expected.json → mutants[*].caught_by. «Пойман» = хотя бы одно испытание
# из caught_by на мутанте не PASS (FAIL или ERROR), а на замороженном ядре — PASS.
import json, sys, zipfile
S = sys.argv[1]
base = {x['id']: x for x in json.load(open(f'{S}/d3_runs/ACCEPTANCE_out/work/d3_results.json'))['results']}
exp = json.load(open(f'{S}/d3_runs/rev4_src/d3/expected.json'))['mutants']
reg = {m['id']: m for m in json.load(open(f'{S}/mutants/registry.json'))['mutants']}
plan_key = {'m1': 'm1', 'm2a': 'm2', 'm2b': 'm2', 'm3': 'm3', 'm4': 'm4', 'm5': 'm5', 'm8': 'm8', 'm12': 'm12', 'm13': 'm13', 'm14': 'm14'}
rows = []
for mid in ['m1', 'm2a', 'm2b', 'm3', 'm4', 'm5', 'm8', 'm12', 'm13', 'm14']:
    rec = json.load(open(f'{S}/mutants/run_{mid}.json'))
    z = zipfile.ZipFile(rec['out_zip']); res = {x['id']: x for x in json.loads(z.read('work/d3_results.json'))['results']}
    changed = {t: (base[t]['status'], res[t]['status']) for t in base if res.get(t, {}).get('status') != base[t]['status']}
    cb = exp[plan_key[mid]]['caught_by']
    by = [t for t in cb if base[t]['status'] == 'PASS' and res[t]['status'] != 'PASS']
    rows.append({'mutant': mid, 'sha256': reg[mid]['sha256'], 'runner_status': rec['runner_status'], 'test_status': rec['test_status'],
                 'kernel_sha256': rec.get('kernel_sha256'), 'out_zip_sha256': rec['out_zip_sha256'], 'caught_by_declared': cb,
                 'caught_by_declared_hit': by, 'caught': bool(by), 'changed_tests': changed,
                 'problems': {t: res[t]['problems'][:2] for t in changed}})
json.dump(rows, open(f'{S}/mutants/mutant_summary.json', 'w'), ensure_ascii=False, indent=1)
for r in rows:
    print(f"{r['mutant']:4} {r['runner_status']}/{r['test_status']}  поймано заявленными: {r['caught']} {r['caught_by_declared_hit']}  "
          f"изменились: {', '.join(f'{t}:{a}→{b}' for t, (a, b) in r['changed_tests'].items()) or '—'}")
