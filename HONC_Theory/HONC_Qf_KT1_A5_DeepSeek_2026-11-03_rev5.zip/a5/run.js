'use strict';
const fs = require('fs');
const path = require('path');
const { check1_root } = require('./check1_root');
const { check2_penetration } = require('./check2_penetration');

function parseArgs(argv) {
  const args = { psi: 56, delta: 10, rho_lo: 45, rho_hi: 65 };
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    const take = (key) => { if (i + 1 >= argv.length) { console.error('missing value for ' + key); process.exit(2); } return parseFloat(argv[++i]); };
    if (a === '--psi') args.psi = take(a);
    else if (a === '--delta') args.delta = take(a);
    else if (a === '--rho-lo') args.rho_lo = take(a);
    else if (a === '--rho-hi') args.rho_hi = take(a);
    else if (a.startsWith('--psi=')) args.psi = parseFloat(a.slice(6));
    else if (a.startsWith('--delta=')) args.delta = parseFloat(a.slice(8));
    else if (a.startsWith('--rho-lo=')) args.rho_lo = parseFloat(a.slice(9));
    else if (a.startsWith('--rho-hi=')) args.rho_hi = parseFloat(a.slice(9));
    else { console.error('unknown arg: ' + a); process.exit(2); }
  }
  for (const k of ['psi', 'delta', 'rho_lo', 'rho_hi']) {
    if (!isFinite(args[k])) { console.error('invalid --' + k.replace('_', '-') + ': ' + args[k]); process.exit(2); }
  }
  if (args.rho_lo >= args.rho_hi) { console.error('rho-lo must be < rho-hi'); process.exit(2); }
  return args;
}

function main() {
  const outDir = process.env.KT1_OUT;
  if (!outDir) { console.error('KT1_OUT not set'); process.exit(2); }
  const { psi, delta, rho_lo, rho_hi } = parseArgs(process.argv);
  console.log(`a5/run.js: psi=${psi} delta=${delta} rho=[${rho_lo}, ${rho_hi}]`);
  console.log('a5/run.js: starting check1_root...');
  const c1 = check1_root(psi, delta, rho_lo, rho_hi);
  const gs = c1.grid_summary;
  console.log(`  existence=${c1.existence} uniqueness=${c1.uniqueness} W_deg=${JSON.stringify(c1.W_deg)}`);
  console.log(`  grid_summary: min_gap_lo=${gs.min_gap_lo.toFixed(6)}@rho=${gs.min_gap_lo_rho_deg.toFixed(2)}deg max_gap_hi=${gs.max_gap_hi.toFixed(6)}@rho=${gs.max_gap_hi_rho_deg.toFixed(2)}deg uncertain=${gs.count_uncertain} widened=${gs.count_widened} max_mult=${gs.max_d_multiplicity}`);
  fs.writeFileSync(path.join(outDir, 'a5.check1.root.json'), JSON.stringify(c1, null, 2));

  let c2;
  if (c1.W_deg) {
    const W = c1.W_deg;
    let d_lo = Infinity, d_hi = -Infinity;
    for (const g of c1.grid) {
      if (g.rho_deg >= W[0] && g.rho_deg <= W[1]) {
        if (g.d_lo < d_lo) d_lo = g.d_lo;
        if (g.d_hi > d_hi) d_hi = g.d_hi;
      }
    }
    if (d_lo === Infinity) { d_lo = 1.5; d_hi = 2.0; }
    console.log(`a5/run.js: starting check2_penetration W_deg=${JSON.stringify(W)} d∈[${d_lo.toFixed(4)}, ${d_hi.toFixed(4)}]...`);
    c2 = check2_penetration(W, d_lo, d_hi, psi, delta);
    console.log(`  found=${c2.found} theta_deg=${c2.theta_deg} dist_hi=${c2.dist_H1_body_hi}`);
  } else {
    c2 = {
      check: 'check2_penetration',
      found: false,
      error: 'no_W_from_check1',
      coverage: 'NONE',
      notes: 'check1 returned no single-interval W; check2 cannot run.'
    };
    console.log('a5/run.js: no W from check1, check2 skipped.');
  }
  fs.writeFileSync(path.join(outDir, 'a5.check2.result.json'), JSON.stringify(c2, null, 2));

  console.log('a5/run.js: done. Wrote a5.check1.root.json, a5.check2.result.json to KT1_OUT.');
}

main();
