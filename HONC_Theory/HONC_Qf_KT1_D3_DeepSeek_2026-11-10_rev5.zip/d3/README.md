# d3 — исполняемый набор КТ-1 (R1 / D-3), rev5

Задание: `DEEPSEEK_KT1_D3_REV5_TASK_2026-11-05.md`.
Формат сдачи: процедура изолированного исполнения ред. 3.2, § 6–7.
Все файлы — LF (без CR).

## 1. Состав и запуск

- С ядром: `KT1_DIR=/sandbox/kernel/kt1 KT1_OUT=/sandbox/work node d3/run.js`
- Без ядра: `KT1_OUT=/sandbox/work node d3/selftest.js`
- `d3/run.js` — 35 испытаний (m1b снят).
- `d3/selftest.js` — 47 испытаний, ожидается 47/47 PASS.

## 2. Происхождение

- rev4 — зафиксирован 05.11 (`5cc71cc7…071a`).
- Part 1c — `expected.json` от предшественника, принят как основа 06.11.
- Part 2 — `run.js` от предшественника, NOT READY (Б-5…Б-11, С-1…С-4).
- Part 2b — мои правки по Part 2.
- Part 3 — вынос операций в `lib/ops.js`; испытания операций в `selftest.js`; усиление m14tt (вердикт и метка); перестройка m2b по G-1/G-5б/G-5в; усиление m3i (m3i-F); снятие m1b; удаление `KL1.json`/`KL3.json`/`m1b.json`.

## 3. Смысл операций

Из `meta.op_definitions` дословно:

| op | смысл |
|---|---|
| `contains` | fork ⊆ [v−tol, v+tol] |
| `contains_half_open` | fork ⊆ [v−tol, v+tol) |
| `certificate_only` | width < width_max И lo > lo_min; значение не сравнивается |
| `certificate_plus_contains_half_open` | сначала `certificate_only`, затем `contains_half_open` (в наборе не используется) |
| `all_contains` / `all_contains_half_open` | для каждого форка в списке — соответствующий `contains*` |
| `list_contains_set` | для каждого v в списке — хотя бы один форк удовлетворяет `contains` |
| `check_min` | минимум поля f по записям `checks[]` с заданными `r`/`case` |
| `value_contains` | fork.lo − tol ≤ v ≤ fork.hi + tol |
| `le` | fork.hi ≤ v |
| `le_with_margin` | fork.hi ≤ v + tol |

**Правило `[NaN, NaN]`:** если `check_min` находит форк, содержащий 0, возвращается `[NaN, NaN]` с `ctx='degenerate_zero'` → `FAIL`. В отчёте — `[null, null]`.

## 4. Где какой ключ проверяется

| Испытание | Ключи `expect` | Записи `num` | Обработчик |
|---|---|---|---|
| A1 | verdict, j5, contacts, rings | 5 | `checkExpect`/`checkNum` |
| A2i | verdict, j5 | 2 | `extractNum`: `check`+`halfplane_angles`, `triple` |
| A2ii, A2iii | verdict, j5 | 1 | `extractNum`: `contact` |
| A2iv | verdict | — | — |
| A3 | verdict, j5 | 1 | `j5_edges_canon` |
| A4 | verdict, j5, completeness | 8 | `check`, `contact`, `contact_point`, `check_min`, `certificate_only` |
| A5 | verdict | — | — |
| Kλ1 | d_formula/theta_list/tolerance | — | `runKλ1` |
| Kλ3 | all_rings_* | — | `runKλ3` |
| B1 | verdict, edges | 1 | `j5_edges_canon` |
| B2 | verdict | 1 | `contact_point` |
| B3 | verdict | 1 | `contact_point` (полуоткрытый) |
| B5 | reading/sign/epsilon/contact_class | — | `K.j5Reading` |
| B8 | verdict | — | `checkExpect` |
| B9 | j5 canon/ext | — | `K.j5Graph` |
| B10 | contacts[0].*, j5 | — | `checkExpect` |
| m1a | width_le_1e-12, fork_contains_true | — | `K.perimeter` |
| m2a | contact_class | — | `K.ringRing` |
| m2b | verdict | — | `K.ringTorus` |
| m3i | per-case gap/tol | — | `runM3i` |
| m3ii | min_value_contains, min_point_contains_x0, tolerance | — | `K.minimize` |
| m4 | j5 canon/ext | — | `K.j5Graph` (`params_from`) |
| m5i/m5ii | contacts[0].* | — | `checkExpect` |
| m8 | verdict | — | `checkExpect` |
| m12 | j5.canon | — | `checkExpect` |
| own1/own4 | violations_non_empty | — | `K.validate` |
| own2 | verdict | — | `K.ringTorus` |
| own3 | contacts[0].* | — | `checkExpect` |
| m13A/B | verdict | — | `K.ringTorus` |
| m14tt | verdict, contacts[0].existence, gap_* | — | `checkExpect` |
| m14rt | verdict | 1 | `single_check` + `value_contains` |

## 5. Чтения источников

- **Наименьший угол R-1:** минимум `value` по всем записям `R-1` с `case='shared-cusp'`; форк, содержащий 0, — вырожденное совпадение, `FAIL`.
- **Г-1:** пара (R1, H1) для «кольцо–тело ≈ 0,078». Второе чтение — «наименьший запас по всем G-5а». Окончательно — Грок.
- **Б-3:** порог `cos = +0,051` — семантика «при ε < 0,051 знак определён»; в наборе — **полуоткрытый интервал `[0,0505; 0,0515)`**.
- **Кλ3:** κ_r ≤ 2 + 10⁻¹² (ветка `runKλ3`; С-1: `num` удалён).

## 6. `pending` и OPEN

| Метка | Что | Кто |
|---|---|---|
| Р-1 | запас у каспа К4: «≈0,006» vs «0,0057» | Интегратор |
| Р-2 | «кольцо–кольцо 0,0325» — не включено | Интегратор |
| В-1 | допуск строки А-2 к «тройке» | Интегратор |
| В-2 | точные целые §2.10, К1 | Интегратор |
| Г-1 | пара для «кольцо–тело» | Грок |
| m2b | правильный исход решает построение по G-1/G-5б/G-5в | закрыто |

## 7. Мутанты

- **m1b снят автором набора.** П. 4 решения Интегратора допускает «обосновать или снять». m1a ловит m1 через `K.perimeter`.
- **m13A** — маскируется κ_min = 0.05 (κ_r = 2 → κ = 0 < κ_min → UNRESOLVED).
- **m14tt усилен:** проверяются `verdict = FORBIDDEN` и `contacts[0].existence = PENETRATION`.
- **m2b усилен по G-1/G-5б/G-5в:** тор рогатый R=r=0,5, A=[0,0,0], T=[0,1,0]; κ_r = s1/s2² = 2+10⁻⁸ > 2 → FORBIDDEN от каспа. Граница проникновения от A: √(u_pen²·s1² + 2u_pen·s2²) ≈ 8,17·10⁻⁵, u_pen=(κ_r−2)/(κ_r²−1). Вне 10⁻⁴ от A кольцо вне обоих кругов сечения. Глубина: **верхняя оценка** (κ_r−2)²/4 ≈ 2,5·10⁻¹⁷; фактический наименьший запас ≈−8,3·10⁻¹⁸ (пересчёт Клода). **m2b теперь одного семейства с m13B** (κ_r−2 = 10⁻⁸ против 10⁻⁷) — покрытие мутантов m2 и m13 частично пересекается.
- **m3i усилен:** m3i-F (T1 в [2−10⁻⁹, 0, 0], gap=−10⁻⁹, ширина контактной области ~3·10⁻⁵) — узкая особенность ниже любого разумного шага выборки. Правильный исход при любой ширине следует из G-4. Мутант m3, ищущий минимум по выборке, пропускает эту особенность. **Предположение** о шаге выборки мутанта.
- **m3ii:** провал лежит **между узлами выборки** (x0 = 403713233027/2⁴⁰, L=65536); выборочный мутант его пропускает и ловится.

## 8. Слепота

**Видел:** пакет формирования (Stage 1), сверки Клода (Part 1c, Part 2, Part 2b), рабочий текст набора rev4→rev5, сводку состояния разработки. Ядра — нет, протоколов — нет, A5-выходов — нет.

**Не видел и не должен:** значения ядра, протоколы rev4/rev5, мутантные прогоны, A5-выходы, код ядра. Раздел §10.3 сводки не открывал.
