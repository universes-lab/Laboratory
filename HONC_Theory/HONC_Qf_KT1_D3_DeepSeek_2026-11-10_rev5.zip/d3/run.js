'use strict';
const fs = require('fs');
const path = require('path');

const K = require(path.join(process.env.KT1_DIR, 'kt1'));
const { truePerimeter } = require('./lib/agm');
const SV = require('./lib/schema-validator');
const CV = require('./lib/config-validator');
const ops = require('./lib/ops');
const { isFork, deepGet, findContact, pairEq, findCusp, getCusps, checkNum } = ops;

const OUT = process.env.KT1_OUT;
const PROTO = path.join(OUT, 'protocols');
if (!fs.existsSync(PROTO)) fs.mkdirSync(PROTO, { recursive: true });

const expected = JSON.parse(fs.readFileSync(path.join(__dirname, 'expected.json'), 'utf8'));
const KAPPA_MIN = expected.meta.kappa_min || 0.05;

function loadCase(name) {
  const p = path.join(__dirname, 'cases', name + '.json');
  if (!fs.existsSync(p)) return null;
  const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
  if (raw.same_as) return loadCase(raw.same_as);
  return raw;
}
function safeCall(fn) { try { return { ok: true, value: fn() }; } catch (e) { return { ok: false, err: String(e && e.stack || e) }; } }
function saveProto(id, v) { try { fs.writeFileSync(path.join(PROTO, id + '.json'), JSON.stringify(v, null, 2)); } catch (e) {} }

function checkExpect(proto, exp, target) {
  const problems = [];
  const g = (p) => deepGet(proto, p);
  const push = (s) => problems.push(s);
  if (exp['verdict.geometry'] && !exp['verdict.geometry'].includes(g('verdict.geometry'))) push(`verdict.geometry=${g('verdict.geometry')}`);
  if (exp['j5.canon.verdict'] && !exp['j5.canon.verdict'].includes(g('j5.canon.verdict'))) push(`j5.canon.verdict=${g('j5.canon.verdict')}`);
  if (exp['j5.ext.verdict'] && !exp['j5.ext.verdict'].includes(g('j5.ext.verdict'))) push(`j5.ext.verdict=${g('j5.ext.verdict')}`);
  for (const k of ['contacts[0].existence','contacts[0].parallel','contacts[0].type','contacts[0].reading'])
    if (exp[k] && g(k) !== exp[k]) push(`${k}=${g(k)}`);
  if (exp['contacts.count_imposed'] !== undefined) { const n = (proto.contacts||[]).filter(c=>c.existence==='IMPOSED').length; if (n !== exp['contacts.count_imposed']) push(`IMPOSED count=${n}`); }
  if (exp['contacts.all_imposed_side']) { const b = (proto.contacts||[]).filter(c=>c.existence==='IMPOSED'&&c.type!=='SIDE'); if (b.length) push(`IMPOSED type≠SIDE: ${b.map(c=>c.pair).join(',')}`); }
  if (exp['contacts.all_imposed_sign_minus_1']) { const b = (proto.contacts||[]).filter(c=>c.existence==='IMPOSED'&&c.sign!==-1); if (b.length) push(`IMPOSED sign≠-1: ${b.map(c=>c.pair).join(',')}`); }
  if (exp['j5.edges.all_imposed_sign_minus_1']) {
    const impPairs = (proto.contacts||[]).filter(c=>c.existence==='IMPOSED').map(c=>c.pair);
    const edges = (proto.j5?.edges)||[];
    const imp = edges.filter(e => impPairs.some(p => pairEq(p, e.pair||[e.a,e.b])));
    if (imp.length === 0) push('no IMPOSED edges in j5');
    for (const e of imp) if (e.sign !== -1) push(`j5 edge ${JSON.stringify(e.pair)} sign=${e.sign}`);
  }
  if (exp['rings.count'] !== undefined) { const n = (proto.configuration?.rings||[]).length; if (n !== exp['rings.count']) push(`rings.count=${n}`); }
  if (exp['rings.length_all_close_2pi']) {
    const tol = 1e-6;
    for (const r of (proto.configuration?.rings||[])) if (isFork(r.length) && !(2*Math.PI >= r.length[0]-tol && 2*Math.PI <= r.length[1]+tol)) push(`ring ${r.name} length fork ${r.length}`);
  }
  if (exp['check.kappa_r_completeness']) {
    let rec = null;
    if (target) rec = findCusp(proto, target.ring, target.torus).record;
    else rec = getCusps(proto)[0] || null;
    if (!rec) push('no cusp record for completeness');
    else { const c = rec.cusp?.completeness || rec.completeness; if (!exp['check.kappa_r_completeness'].includes(c)) push(`cusp.completeness=${c}`); }
  }
  if (exp['gap_hi_negative']) {
    const c = findContact(proto, ['T0','T1']);
    if (!c || !isFork(c.gap) || !(c.gap[1] < 0)) push('gap.hi not negative');
  }
  if (exp['gap_contains_minus_1e-6_with_1e-15']) {
    const c = findContact(proto, ['T0','T1']); const tol = 1e-15;
    if (!c || !isFork(c.gap) || !(c.gap[0] <= -1e-6 + tol && c.gap[1] >= -1e-6 - tol)) push('gap ⊉ -1e-6 ± 1e-15');
  }
  return problems;
}

function runKλ1(spec) {
  const problems = [];
  const thetas = spec.expect.theta_list_deg;
  const tol = spec.expect.tolerance;
  for (const th of thetas) {
    const c = { id: `Kλ1_${th}`, thread: { n: 2, links: [{ theta: th, phi: 90, delta: 0 }, { theta: 0, phi: 0, delta: 0 }] }, hangs: [] };
    const call = safeCall(() => K.run(c));
    if (!call.ok) { problems.push(`θ=${th}: K.run threw`); continue; }
    const dCheck = (call.value.checks||[]).find(ch => ch.req === 'G-3' && (ch.quantity === 'link_distance' || ch.quantity === 'd'));
    if (!dCheck || !isFork(dCheck.value)) { problems.push(`θ=${th}: no d fork`); continue; }
    const dExp = 1 + Math.cos(th * Math.PI / 180);
    const [lo, hi] = dCheck.value;
    if (!(lo >= dExp - tol && hi <= dExp + tol)) problems.push(`θ=${th}: d=[${lo},${hi}] not within [${dExp-tol},${dExp+tol}]`);
  }
  return { id: 'Kλ1', status: problems.length ? 'FAIL' : 'PASS', problems };
}

function runKλ3(spec) {
  const problems = [];
  for (const cname of spec.cases || []) {
    const cd = loadCase(cname);
    if (!cd) { problems.push(`${cname}: no case`); continue; }
    const call = safeCall(() => K.run(cd));
    if (!call.ok) { problems.push(`${cname}: K.run threw`); continue; }
    const cs = getCusps(call.value);
    if (cs.length === 0) { problems.push(`${cname}: no cusp records`); continue; }
    for (const cr of cs) {
      const kr = cr.kappa_r;
      const krHi = isFork(kr) ? kr[1] : (typeof kr === 'number' ? kr : null);
      if (krHi === null) { problems.push(`${cname} ${cr.objects}: no kappa_r`); continue; }
      if (krHi > 2 + 1e-12) problems.push(`${cname} ${cr.objects}: κ_r_hi=${krHi} > 2 + 10⁻¹²`);
      const kap = cr.value;
      const kLo = isFork(kap) ? kap[0] : (typeof kap === 'number' ? kap : null);
      if (kLo !== null && kLo < KAPPA_MIN) problems.push(`${cname} ${cr.objects}: κ_lo=${kLo} < ${KAPPA_MIN}`);
      const comp = cr.cusp?.completeness || cr.completeness;
      if (!['EXACT','CERTIFIED'].includes(comp)) problems.push(`${cname} ${cr.objects}: completeness=${comp}`);
    }
  }
  return { id: 'Kλ3', status: problems.length ? 'FAIL' : 'PASS', problems };
}
function runM3i(spec) {
  const problems = [];
  const cases = spec.cases;
  const entries = Array.isArray(cases)
    ? cases.map(c => [c, { gap: -0.002, tol: 1e-15 }])
    : Object.entries(cases);
  for (const [cname, cexp] of entries) {
    const cd = loadCase(cname);
    if (!cd) { problems.push(`${cname}: no case`); continue; }
    const call = safeCall(() => K.run(cd));
    if (!call.ok) { problems.push(`${cname}: K.run threw`); continue; }
    const c = findContact(call.value, ['T0', 'T1']);
    if (!c || !isFork(c.gap)) { problems.push(`${cname}: no T0-T1 gap`); continue; }
    const [lo, hi] = c.gap;
    if (!(hi < 0)) problems.push(`${cname}: gap.hi=${hi} not negative`);
    const tol = (cexp && cexp.tol) || 1e-15;
    const g = (cexp && cexp.gap !== undefined) ? cexp.gap : -0.002;
    if (!(lo <= g + tol && hi >= g - tol)) problems.push(`${cname}: gap=${JSON.stringify(c.gap)} not ⊇ ${g} ± ${tol}`);
  }
  return { id: 'm3i', status: problems.length ? 'FAIL' : 'PASS', problems };
}

function runTest(id, spec) {
  const r = { id, kind: spec.kind, status: 'PASS', problems: [] };
  try {
    if (spec.kind === 'K.run') {
      const cd = loadCase(spec.case);
      if (!cd) { r.status = 'ERROR'; r.problems.push(`case not found: ${spec.case}`); return r; }
      const call = safeCall(() => K.run(cd));
      if (!call.ok) { r.status = 'ERROR'; r.problems.push(`K.run threw: ${call.err}`); return r; }
      saveProto(id, call.value);
      const svErrs = SV.validate(call.value);
      if (svErrs.length > 0) r.problems.push('schema: ' + svErrs.slice(0,3).join('; ') + (svErrs.length>3 ? ` ... (${svErrs.length})` : ''));
      const cvErrs = CV.check(call.value);
      if (cvErrs.length > 0) r.problems.push('config: ' + cvErrs.join('; '));
      r.problems.push(...checkExpect(call.value, spec.expect, spec.cusp_target));
      r.problems.push(...checkNum(call.value, call.value, spec.num));
    } else if (spec.kind === 'K.perimeter') {
      const [s1, s2] = spec.params;
      const call = safeCall(() => K.perimeter(s1, s2));
      if (!call.ok) { r.status = 'ERROR'; r.problems.push(`K.perimeter threw: ${call.err}`); return r; }
      saveProto(id, call.value);
      let fork = Array.isArray(call.value) ? call.value : call.value.value;
      if (!isFork(fork)) { r.status = 'FAIL'; r.problems.push('perimeter not fork'); return r; }
      if (fork[1] - fork[0] > 1e-12) r.problems.push(`width=${fork[1]-fork[0]} > 1e-12`);
      const pTrue = truePerimeter(s1, s2);
      if (!(fork[0] - 1e-10 <= pTrue && pTrue <= fork[1] + 1e-10)) r.problems.push(`perimeter fork ${fork} not ⊇ ${pTrue}`);
    } else if (spec.kind === 'K.ringRing') {
      const p = spec.params;
      const call = safeCall(() => K.ringRing(p.r1, p.r2, p.sharedCusp));
      if (!call.ok) { r.status = 'ERROR'; r.problems.push(`K.ringRing threw: ${call.err}`); return r; }
      saveProto(id, call.value);
      if (spec.expect.contact_class && call.value.contact_class !== spec.expect.contact_class) r.problems.push(`contact_class=${call.value.contact_class}`);
    } else if (spec.kind === 'K.ringTorus') {
      const p = spec.params;
      const call = safeCall(() => K.ringTorus(p.ring, p.torus, p.threaded));
      if (!call.ok) { r.status = 'ERROR'; r.problems.push(`K.ringTorus threw: ${call.err}`); return r; }
      saveProto(id, call.value);
      const expV = spec.expect.verdict;
      const av = call.value.verdict;
      if (Array.isArray(expV)) { if (!expV.includes(av)) r.problems.push(`verdict=${av}`); }
      else if (av !== expV) r.problems.push(`verdict=${av}`);
      if (spec.expect.value_contains !== undefined) {
        const tol = spec.expect.value_contains_tol || 1e-15;
        const v = call.value.value;
        if (!isFork(v) || !(v[0] <= spec.expect.value_contains + tol && v[1] >= spec.expect.value_contains - tol)) r.problems.push(`value fork ${v} ⊉ ${spec.expect.value_contains}`);
      }
      r.problems.push(...checkNum(null, call.value, spec.num));
    } else if (spec.kind === 'K.j5Reading') {
      const call = safeCall(() => K.j5Reading(spec.params));
      if (!call.ok) { r.status = 'ERROR'; r.problems.push(`K.j5Reading threw: ${call.err}`); return r; }
      saveProto(id, call.value);
      const e = spec.expect;
      if (call.value.reading !== e.reading) r.problems.push(`reading=${call.value.reading}`);
      if (call.value.sign !== e.sign) r.problems.push(`sign=${call.value.sign}`);
      if (e.contact_class && call.value.contact_class !== e.contact_class) r.problems.push(`contact_class=${call.value.contact_class}`);
      if (e.epsilon_range && !(call.value.epsilon >= e.epsilon_range[0] && call.value.epsilon <= e.epsilon_range[1])) r.problems.push(`epsilon=${call.value.epsilon}`);
    } else if (spec.kind === 'K.j5Graph') {
      const p = spec.params_from ? expected.tests[spec.params_from].params : spec.params;
      const call = safeCall(() => K.j5Graph(p));
      if (!call.ok) { r.status = 'ERROR'; r.problems.push(`K.j5Graph threw: ${call.err}`); return r; }
      saveProto(id, call.value);
      const j5 = (call.value.canon && call.value.ext) ? call.value : (call.value.j5 || call.value);
      if (spec.expect['j5.canon.verdict'] && !spec.expect['j5.canon.verdict'].includes(j5.canon?.verdict)) r.problems.push(`canon.verdict=${j5.canon?.verdict}`);
      if (spec.expect['j5.ext.verdict'] && !spec.expect['j5.ext.verdict'].includes(j5.ext?.verdict)) r.problems.push(`ext.verdict=${j5.ext?.verdict}`);
    } else if (spec.kind === 'K.validate') {
      const call = safeCall(() => K.validate(spec.params.constructed));
      if (!call.ok) { r.status = 'ERROR'; r.problems.push(`K.validate threw: ${call.err}`); return r; }
      saveProto(id, call.value);
      if (!Array.isArray(call.value) || call.value.length === 0) r.problems.push('K.validate empty');
    } else if (spec.kind === 'K.minimize') {
      const p = spec.params;
      const x0 = p.x0_num / p.x0_den;
      const tol = spec.expect.tolerance || 1e-12;
      const f = (x) => { const dx = x - x0; if (Math.abs(dx) > 1/65536) return [0, 0]; const v = -1 + Math.abs(dx) * 65536; return [v, v]; };
      const call = safeCall(() => K.minimize({ f, a: p.a, b: p.b, L: p.L, periodic: p.periodic }));
      if (!call.ok) { r.status = 'ERROR'; r.problems.push(`K.minimize threw: ${call.err}`); return r; }
      saveProto(id, call.value);
      const minv = call.value.min || call.value.min_value || call.value.value;
      if (!isFork(minv) || !(minv[0] <= -1 + tol && minv[1] >= -1 - tol)) r.problems.push(`min fork ${JSON.stringify(minv)} ⊉ -1`);
      const arg = call.value.argmin || call.value.min_points || [];
      const found = Array.isArray(arg) && arg.some(pt => isFork(pt) && pt[0] - tol <= x0 && x0 <= pt[1] + tol);
      if (!found) r.problems.push(`argmin ∌ x0=${x0}`);
    } else {
      r.status = 'ERROR'; r.problems.push(`unknown kind: ${spec.kind}`);
    }
  } catch (e) { r.status = 'ERROR'; r.problems.push(String(e && e.stack || e)); }
  if (r.problems.length && r.status === 'PASS') r.status = 'FAIL';
  return r;
}

function main() {
  const results = [];
  for (const id of Object.keys(expected.tests)) {
    const s = expected.tests[id];
    if (id === 'Kλ1') results.push(runKλ1(s));
    else if (id === 'Kλ3') results.push(runKλ3(s));
    else if (id === 'm3i') results.push(runM3i(s));
    else results.push(runTest(id, s));
  }
  fs.writeFileSync(path.join(OUT, 'd3_results.json'), JSON.stringify({ meta: expected.meta, results, mutants: expected.mutants, run_date: new Date().toISOString() }, null, 2));
  const p = results.filter(r => r.status === 'PASS').length;
  const f = results.filter(r => r.status === 'FAIL').length;
  const e = results.filter(r => r.status === 'ERROR').length;
  console.log(`d3 rev5: ${results.length} tests; PASS=${p} FAIL=${f} ERROR=${e}`);
  process.exit(0);
}

main();
