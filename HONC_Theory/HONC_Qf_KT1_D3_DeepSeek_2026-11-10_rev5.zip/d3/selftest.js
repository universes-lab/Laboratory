'use strict';
const fs = require('fs');
const path = require('path');
const SV = require('./lib/schema-validator');
const CV = require('./lib/config-validator');
const K6 = require('./lib/k6-enumerator');
const { truePerimeter, perimeterFork } = require('./lib/agm');
const ops = require('./lib/ops');
const { isFork, applyOp, extractNum } = ops;

const OUT = process.env.KT1_OUT;
const results = [];
function record(id, status, details) { results.push({ id, status, details: details || null }); }

function testK6_B9() {
  const g = {
    vertices: ['T1','T2','T3','T4'],
    edges: [
      {a:'T1',b:'T2',cls:'LINK',existence:'IMPOSED',reading:'J5-CANON',sign:1},
      {a:'T2',b:'T3',cls:'LINK',existence:'IMPOSED',reading:'J5-CANON',sign:1},
      {a:'T3',b:'T1',cls:'LINK',existence:'IMPOSED',reading:'J5-CANON',sign:1},
      {a:'T3',b:'T4',cls:'CONTACT-ONLY',existence:'IMPOSED',reading:'J5-EXT',sign:1}
    ]
  };
  const r = K6.evaluate(g);
  record('k6_B9', (r.j5.canon.verdict === 'UNRESOLVED' && r.j5.ext.verdict === 'PASSED-EXT') ? 'PASS' : 'FAIL', r.j5);
}

function testK6_B1() {
  const g = {
    vertices: ['T1','T2','T3'],
    edges: [
      {a:'T1',b:'T2',cls:'LINK',existence:'IMPOSED',reading:'J5-CANON',sign:-1},
      {a:'T2',b:'T3',cls:'LINK',existence:'IMPOSED',reading:'J5-CANON',sign:-1},
      {a:'T3',b:'T1',cls:'LINK',existence:'IMPOSED',reading:'J5-CANON',sign:-1}
    ]
  };
  const r = K6.evaluate(g);
  record('k6_B1', r.j5.canon.verdict === 'FORBIDDEN' ? 'PASS' : 'FAIL', r.j5);
}

function testK6_B10() {
  const g = {
    vertices: ['S1','S2'],
    edges: [{a:'S1',b:'S2',cls:'LINK',existence:'IMPOSED',reading:'J5-CLASS-UNRESOLVED',sign:1}]
  };
  const r = K6.evaluate(g);
  record('k6_B10_single', (r.j5.canon.verdict === 'UNRESOLVED' && r.j5.ext.verdict === 'PASSED-EXT') ? 'PASS' : 'FAIL', r.j5);
}

function testK6_empty() {
  const g = { vertices: ['T1'], edges: [] };
  const r = K6.evaluate(g);
  record('k6_empty', (r.j5.canon.verdict === 'PASSED' && r.j5.ext.verdict === 'PASSED-EXT') ? 'PASS' : 'FAIL', r.j5);
}

function testSV() {
  const bad = {
    checks: [{ id:'x', req:'G-4', objects:[], quantity:'gap', value:[-0.001,0.001], completeness:'SAMPLED', verdict:'PASSED', where:null, level:'L2', layer:'CARRIER' }],
    configuration: { rings: [] }, verdict: { geometry: 'PASSED' }
  };
  const errs = SV.validate(bad);
  record('sv_PASSED_with_SAMPLED', errs.some(e => e.indexOf('SAMPLED') >= 0) ? 'PASS' : 'FAIL', errs);

  const ringNoWidths = {
    checks: [],
    configuration: { rings: [{ name: 'R0', source: 'construction', C:[[0,0],[0,0],[0,0]], E1:[[1,1],[0,0],[0,0]], E2:[[0,0],[1,1],[0,0]], s1:[0.5,0.5], s2:[0.5,0.5] }] },
    verdict: { geometry: 'PASSED' }
  };
  const errs2 = SV.validate(ringNoWidths);
  record('sv_ring_missing_widths', errs2.some(e => e.indexOf('widths') >= 0) ? 'PASS' : 'FAIL', errs2);

  const forkBad = {
    checks: [{ id:'x', req:'G-4', objects:[], quantity:'gap', value:[0.5,0.1], completeness:'CERTIFIED', verdict:'PASSED', where:null, level:'L2', layer:'CARRIER' }],
    configuration: { rings: [] }, verdict: { geometry: 'PASSED' }
  };
  const errs3 = SV.validate(forkBad);
  record('sv_lo_gt_hi', errs3.some(e => e.indexOf('lo > hi') >= 0) ? 'PASS' : 'FAIL', errs3);
}

function testCV() {
  const ok = CV.check({ checks: [{verdict:'PASSED'},{verdict:'PASSED'}], verdict: { geometry: 'PASSED' } });
  record('cv_all_passed_ok', ok.length === 0 ? 'PASS' : 'FAIL', ok);
  const bad = CV.check({ checks: [{verdict:'PASSED'},{verdict:'FORBIDDEN'}], verdict: { geometry: 'PASSED' } });
  record('cv_one_forbidden_flagged', bad.length > 0 ? 'PASS' : 'FAIL', bad);
  const unsolved = CV.check({ checks: [{verdict:'PASSED'},{verdict:'UNRESOLVED'}], verdict: { geometry: 'PASSED' } });
  record('cv_unsolved_flagged', unsolved.length > 0 ? 'PASS' : 'FAIL', unsolved);
  const badC = CV.check({ checks: [{verdict:'UNRESOLVED'},{verdict:'UNRESOLVED'}], verdict: { geometry: 'UNRESOLVED' } });
  record('cv_all_unsolved_ok', badC.length === 0 ? 'PASS' : 'FAIL', badC);
}

function testTruePerimeter() {
  const p1 = truePerimeter(1, 1);
  record('perimeter_circle_r1', Math.abs(p1 - 2 * Math.PI) < 1e-9 ? 'PASS' : 'FAIL', { computed: p1, expected: 2 * Math.PI });
  const p2 = truePerimeter(0.5, 0.5);
  record('perimeter_circle_r05', Math.abs(p2 - Math.PI) < 1e-9 ? 'PASS' : 'FAIL', { computed: p2, expected: Math.PI });
  const p3 = truePerimeter(1, 0.5);
  const p3_known = 4.84422411;
  record('perimeter_ellipse_1_05', Math.abs(p3 - p3_known) < 1e-6 ? 'PASS' : 'FAIL', { computed: p3, expected: p3_known });
}

function testPerimeterFork() {
  const f = perimeterFork([1, 1], [0.5, 0.5]);
  const expected = 4.84422411;
  const ok = Math.abs(f[0] - expected) < 1e-6 && Math.abs(f[1] - expected) < 1e-6;
  record('perimeterFork_exact_1_05', ok ? 'PASS' : 'FAIL', { fork: f, expected });
}

function testFindCheck() {
  const { findCheck } = require('./lib/compare');
  const recs = [
    { id: 'x', req: 'G-5а', quantity: 'gap', value: [-0.01, -0.001] },
    { id: 'y', req: 'G-5б–г', quantity: 'kappa_margin', value: [0.5, 0.6] },
    { id: 'z', req: 'G-4', quantity: 'gap', value: [0.5, 1.0] }
  ];
  const byReq = findCheck(recs, { req: 'G-5б–г' });
  const byQ = findCheck(recs, { quantity: 'kappa_margin' });
  record('findCheck_by_req', byReq && byReq.id === 'y' ? 'PASS' : 'FAIL', byReq && byReq.id);
  record('findCheck_by_quantity', byQ && byQ.id === 'y' ? 'PASS' : 'FAIL', byQ && byQ.id);
}

function testOps() {
  record('isFork_true', isFork([0, 1]) ? 'PASS' : 'FAIL');
  record('isFork_false_len', !isFork([0]) ? 'PASS' : 'FAIL');
  record('isFork_false_type', !isFork([0, 'a']) ? 'PASS' : 'FAIL');

  record('ops_contains_pos', applyOp({op:'contains', v: 1, tol: 0.1}, {type:'single', fork: [0.95, 1.05]}) ? 'PASS' : 'FAIL');
  record('ops_contains_neg_width', !applyOp({op:'contains', v: 1, tol: 0.1}, {type:'single', fork: [0.95, 1.15]}) ? 'PASS' : 'FAIL');
  record('ops_contains_neg_value', !applyOp({op:'contains', v: 1, tol: 0.1}, {type:'single', fork: [0.5, 0.6]}) ? 'PASS' : 'FAIL');

  record('ops_contains_half_open_pos', applyOp({op:'contains_half_open', v: 1, tol: 0.1}, {type:'single', fork: [0.95, 1.0999]}) ? 'PASS' : 'FAIL');
  record('ops_contains_half_open_neg_closed', !applyOp({op:'contains_half_open', v: 1, tol: 0.1}, {type:'single', fork: [0.95, 1.1]}) ? 'PASS' : 'FAIL');

  record('ops_cert_only_pos', applyOp({op:'certificate_only', width_max: 0.01, lo_min: 0}, {type:'single', fork: [0.005, 0.010]}) ? 'PASS' : 'FAIL');
  record('ops_cert_only_neg_width', !applyOp({op:'certificate_only', width_max: 0.001, lo_min: 0}, {type:'single', fork: [0.005, 0.010]}) ? 'PASS' : 'FAIL');
  record('ops_cert_only_neg_lo', !applyOp({op:'certificate_only', width_max: 0.01, lo_min: 0.005}, {type:'single', fork: [0.004, 0.010]}) ? 'PASS' : 'FAIL');

  record('ops_cert_plus_contains_pos', applyOp({op:'certificate_plus_contains_half_open', width_max: 0.01, lo_min: 0, v: 1, tol: 0.1}, {type:'single', fork: [0.999, 1.001]}) ? 'PASS' : 'FAIL');
  record('ops_cert_plus_contains_neg_cert', !applyOp({op:'certificate_plus_contains_half_open', width_max: 0.001, lo_min: 0, v: 1, tol: 0.1}, {type:'single', fork: [0.999, 1.001]}) ? 'PASS' : 'FAIL');
  record('ops_cert_plus_contains_neg_contains', !applyOp({op:'certificate_plus_contains_half_open', width_max: 0.01, lo_min: 0, v: 1, tol: 0.001}, {type:'single', fork: [0.5, 0.505]}) ? 'PASS' : 'FAIL');

  record('ops_all_contains_pos', applyOp({op:'all_contains', v: 1, tol: 0.1}, {type:'list', entries: [{fork: [0.95, 1.05]}, {fork: [0.99, 1.01]}]}) ? 'PASS' : 'FAIL');
  record('ops_all_contains_neg', !applyOp({op:'all_contains', v: 1, tol: 0.1}, {type:'list', entries: [{fork: [0.95, 1.05]}, {fork: [0.99, 1.15]}]}) ? 'PASS' : 'FAIL');

  record('ops_all_contains_half_open_pos', applyOp({op:'all_contains_half_open', v: 1, tol: 0.1}, {type:'list', entries: [{fork: [0.95, 1.05]}, {fork: [0.99, 1.0999]}]}) ? 'PASS' : 'FAIL');
  record('ops_all_contains_half_open_neg', !applyOp({op:'all_contains_half_open', v: 1, tol: 0.1}, {type:'list', entries: [{fork: [0.95, 1.05]}, {fork: [0.99, 1.1]}]}) ? 'PASS' : 'FAIL');

  record('ops_list_contains_set_pos', applyOp({op:'list_contains_set', v: [-90, 0, 90], tol: 0.01}, {type:'list', entries: [{fork: [-90.001, -89.999]}, {fork: [-0.001, 0.001]}, {fork: [89.999, 90.001]}]}) ? 'PASS' : 'FAIL');
  record('ops_list_contains_set_neg', !applyOp({op:'list_contains_set', v: [-90, 0, 90], tol: 1e-6}, {type:'list', entries: [{fork: [-90.001, -89.999]}, {fork: [-0.001, 0.001]}]}) ? 'PASS' : 'FAIL');

  record('ops_value_contains_pos', applyOp({op:'value_contains', v: -0.5, tol: 0.1}, {type:'single', fork: [-0.6, -0.4]}) ? 'PASS' : 'FAIL');
  record('ops_value_contains_neg', !applyOp({op:'value_contains', v: -0.5, tol: 0.1}, {type:'single', fork: [-0.3, -0.1]}) ? 'PASS' : 'FAIL');

  record('ops_le_pos', applyOp({op:'le', v: 5}, {type:'single', fork: [3, 4]}) ? 'PASS' : 'FAIL');
  record('ops_le_neg', !applyOp({op:'le', v: 5}, {type:'single', fork: [3, 6]}) ? 'PASS' : 'FAIL');

  record('ops_le_with_margin_pos', applyOp({op:'le_with_margin', v: 5, tol: 0.1}, {type:'single', fork: [3, 5.05]}) ? 'PASS' : 'FAIL');
  record('ops_le_with_margin_neg', !applyOp({op:'le_with_margin', v: 5, tol: 0.01}, {type:'single', fork: [3, 5.05]}) ? 'PASS' : 'FAIL');

  {
    const proto = { checks: [
      { req: 'R-1', case: 'shared-cusp', value: [50, 51] },
      { req: 'R-1', case: 'shared-cusp', value: [47.55, 47.65] }
    ]};
    const ex = extractNum(proto, {}, { k: 'check_min', r: 'R-1', case: 'shared-cusp', f: 'value' });
    record('ops_check_min_pos', ex && isFork(ex.fork) && ex.fork[0] === 47.55 && ex.fork[1] === 47.55 ? 'PASS' : 'FAIL', ex);
  }

  {
    const proto = { checks: [{ req: 'R-2', case: 'other', value: [50, 51] }] };
    const ex = extractNum(proto, {}, { k: 'check_min', r: 'R-1', case: 'shared-cusp', f: 'value' });
    record('ops_check_min_neg_no_records', ex === null ? 'PASS' : 'FAIL', ex);
  }

  {
    const proto = { checks: [
      { req: 'R-1', case: 'shared-cusp', value: [-1, 1] },
      { req: 'R-1', case: 'shared-cusp', value: [50, 51] }
    ]};
    const ex = extractNum(proto, {}, { k: 'check_min', r: 'R-1', case: 'shared-cusp', f: 'value' });
    record('ops_check_min_zero_fork', ex && isFork(ex.fork) && isNaN(ex.fork[0]) && isNaN(ex.fork[1]) && ex.ctx === 'degenerate_zero' ? 'PASS' : 'FAIL', ex);
  }

  {
    const proto = { checks: [
      { req: 'R-1', case: 'shared-cusp', id: 'r1-1', halfplane_angles: [[-90.001, -89.999], [-0.001, 0.001]] },
      { req: 'R-1', case: 'shared-cusp', id: 'r1-2', halfplane_angles: [[89.999, 90.001]] }
    ]};
    const ex = extractNum(proto, {}, { k: 'check', r: 'R-1', case: 'shared-cusp', f: 'halfplane_angles' });
    record('ops_halfplane_angles_list', ex && ex.type === 'list' && ex.entries.length === 3 ? 'PASS' : 'FAIL', ex && { n: ex.entries && ex.entries.length });
  }
}

function main() {
  testK6_B9(); testK6_B1(); testK6_B10(); testK6_empty();
  testSV(); testCV(); testTruePerimeter(); testPerimeterFork(); testFindCheck();
  testOps();
  fs.writeFileSync(path.join(OUT, 'd3_selftest.json'), JSON.stringify({
    results, run_date: new Date().toISOString()
  }, null, 2));
  const passed = results.filter(r => r.status === 'PASS').length;
  const failed = results.filter(r => r.status === 'FAIL').length;
  console.log('d3_selftest: ' + results.length + '; PASS=' + passed + ' FAIL=' + failed);
  process.exit(0);
}

main();
