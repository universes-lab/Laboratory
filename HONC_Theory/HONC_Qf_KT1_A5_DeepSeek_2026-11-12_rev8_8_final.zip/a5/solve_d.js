'use strict';
const { I } = require('./lib/ia');
const { gapTorusTorus } = require('./lib/geom');
const { buildH1, A_T2, Y_HAT, X_HAT, Z_HAT } = require('./lib/build');
const { hangDirection } = require('./lib/frame');

function dExact(rho, psi) {
  const e = hangDirection(rho, psi, X_HAT, Y_HAT, Z_HAT, 1);
  const uT = e.dot(Y_HAT);
  return I.of(1).sub(uT.mul(uT)).sqrt().add(I.of(1));
}

function gapH1T2(rho_box, psi, delta, d_val, opts, tolOverride) {
  const H = buildH1(rho_box, psi, delta, I.of(d_val));
  const subOpts = tolOverride !== undefined
    ? Object.assign({}, opts, { gap_tol: tolOverride })
    : opts;
  return gapTorusTorus(H.A_H1, H.T_H1, A_T2, Y_HAT, subOpts);
}

function certify(rho_box, psi, delta, a, b, opts, tol_tight_eff) {
  for (let w = 0; w <= 6; w++) {
    const dhW = w * (b - a) / 2;
    const a2 = a - dhW, b2 = b + dhW;
    const gA = gapH1T2(rho_box, psi, delta, a2, opts, tol_tight_eff);
    const gB = gapH1T2(rho_box, psi, delta, b2, opts, tol_tight_eff);
    const sA = gA.isPos() ? '+' : (gA.isNeg() ? '-' : '?');
    const sB = gB.isPos() ? '+' : (gB.isNeg() ? '-' : '?');
    if (sA !== '?' && sB !== '?' && sA !== sB) {
      return { ok: true, d_lo: a2, d_hi: b2, sign_lo: sA, sign_hi: sB, cert_widen: w };
    }
  }
  return { ok: false, d_lo: a, d_hi: b };
}

function bisect(rho_box, psi, delta, a, b, signA, opts, tol_tight_eff) {
  let iter = 0;
  while ((b - a) > 2 * tol_tight_eff && iter < 80) {
    iter++;
    const w = b - a;
    const tol_step = Math.max(tol_tight_eff, Math.min(opts.gap_tol_loose, w * 0.2));
    const m = (a + b) / 2;
    const g = gapH1T2(rho_box, psi, delta, m, opts, tol_step);
    const s = g.isPos() ? '+' : (g.isNeg() ? '-' : '?');
    if (s === '?') {
      if (tol_step < w * 0.5) { a = m - tol_step; b = m + tol_step; continue; }
      break;
    }
    if (s === signA) a = m; else b = m;
  }
  return { a, b, iter };
}

// solveD: parent inheritance (быстрая ветка) или full scan (root box).
//
// Fix от rev8.8 (Клод 12.11, speed):
//   Child ρ_box ⊂ parent ρ_box ⇒ gap_child(d) ⊆ gap_parent(d) для того же d.
//   Значит parent certified [d_lo_p, d_hi_p] является certified и для child:
//   его root лежит внутри (d_lo_p, d_hi_p). Skip scan 40 вызовов, bisect
//   начинается сразу с [d_lo_p, d_hi_p]. Skip initial verify.
//
//   На 16 уровнях дерева K4 сэкономит ~40·600 = 24 000 loose-вызовов
//   (~260 s из rev8.7 профиля).
function solveD(rho_box, psi, delta, opts) {
  const rho_rad = rho_box.width();
  const box_floor = 5 * rho_rad;
  const tol_tight_eff = Math.max(opts.gap_tol_tight, box_floor);
  const parent = opts.parent_bracket;

  if (parent && parent.d_lo !== null && parent.d_hi !== null && parent.sign_lo && parent.sign_hi) {
    // Fast path: parent inheritance.
    const { a, b, iter } = bisect(rho_box, psi, delta, parent.d_lo, parent.d_hi,
      parent.sign_lo, opts, tol_tight_eff);
    const c = certify(rho_box, psi, delta, a, b, opts, tol_tight_eff);
    if (c.ok) {
      return { d_lo: c.d_lo, d_hi: c.d_hi, sign_lo: c.sign_lo, sign_hi: c.sign_hi,
               ok: true, width: c.d_hi - c.d_lo, cert_widen: c.cert_widen,
               bisect_iters: iter, tol_tight_eff, inherited: true };
    }
    // Fall through to full scan if cert fails.
  }

  // Full scan (root box, or inheritance failed).
  const dLo = 0.3, dHi = 3.5;
  const N_scan = 40;
  const dh = (dHi - dLo) / N_scan;
  let prev_sign = null, prev_d = dLo, straddle = null;
  for (let j = 0; j <= N_scan; j++) {
    const d = dLo + j * dh;
    const g = gapH1T2(rho_box, psi, delta, d, opts, opts.gap_tol_loose);
    const s = g.isPos() ? '+' : (g.isNeg() ? '-' : '?');
    if (prev_sign !== null && prev_sign !== '?' && s !== '?' && prev_sign !== s) {
      straddle = [prev_d, d]; break;
    }
    if (s !== '?') { prev_sign = s; prev_d = d; }
  }
  if (!straddle) return { d_lo: dLo, d_hi: dHi, ok: false, reason: 'no straddle (scan)', tol_tight_eff };

  let a = straddle[0], b = straddle[1];
  const gA0 = gapH1T2(rho_box, psi, delta, a, opts, opts.gap_tol_loose);
  const signA = gA0.isPos() ? '+' : (gA0.isNeg() ? '-' : '?');
  if (signA === '?') return { d_lo: a, d_hi: b, ok: false, reason: 'sign ? at a0', tol_tight_eff };

  const { a: a2, b: b2, iter } = bisect(rho_box, psi, delta, a, b, signA, opts, tol_tight_eff);
  const c = certify(rho_box, psi, delta, a2, b2, opts, tol_tight_eff);
  if (c.ok) {
    return { d_lo: c.d_lo, d_hi: c.d_hi, sign_lo: c.sign_lo, sign_hi: c.sign_hi,
             ok: true, width: c.d_hi - c.d_lo, cert_widen: c.cert_widen,
             bisect_iters: iter, tol_tight_eff, inherited: false };
  }
  return { d_lo: a2, d_hi: b2, ok: false, reason: 'cert failed', bisect_iters: iter, tol_tight_eff };
}

module.exports = { solveD, dExact, gapH1T2 };
