'use strict';
const fs = require('fs');
const path = require('path');
const { check1_root } = require('./check1_root');
const { check2_penetration } = require('./check2_penetration');
const { OPTS } = require('./lib/opts');

function parseArgs(argv) {
  const args = { psi: 56, delta: 10, rho_lo: 45, rho_hi: 65 };
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    const take = (k) => { if (i + 1 >= argv.length) { console.error('missing ' + k); process.exit(2); } return parseFloat(argv[++i]); };
    if (a === '--psi') args.psi = take('psi');
    else if (a === '--delta') args.delta = take('delta');
    else if (a === '--rho-lo') args.rho_lo = take('rho-lo');
    else if (a === '--rho-hi') args.rho_hi = take('rho-hi');
    else { console.error('unknown arg: ' + a); process.exit(2); }
  }
  if (!isFinite(args.psi) || !isFinite(args.delta) || !isFinite(args.rho_lo) || !isFinite(args.rho_hi)) {
    console.error('invalid arg'); process.exit(2);
  }
  if (args.rho_lo >= args.rho_hi) { console.error('rho-lo >= rho-hi'); process.exit(2); }
  return args;
}

function main() {
  const outDir = process.env.KT1_OUT;
  if (!outDir) { console.error('KT1_OUT not set'); process.exit(2); }
  const args = parseArgs(process.argv);
  console.log(`a5/run.js rev8.8: psi=${args.psi} delta=${args.delta} rho=[${args.rho_lo}, ${args.rho_hi}]`);
  console.log('a5/run.js rev8.8: OPTS =', JSON.stringify(OPTS));

  const t0 = Date.now();
  console.log('a5/run.js: check1_root ...');
  const c1 = check1_root(args.psi, args.delta, args.rho_lo, args.rho_hi, OPTS);
  fs.writeFileSync(path.join(outDir, 'a5.check1.root.json'), JSON.stringify(c1, null, 2));
  const t1 = Date.now();
  console.log(`  existence=${c1.existence} all_roots_in_W=${c1.all_roots_in_W} uniqueness=${c1.uniqueness}`);
  console.log(`  boxes=${c1.boxes_count} signChanges=${c1.signChanges.length} W=${JSON.stringify(c1.W.map(w => ({ rho_lo: w.rho_lo, rho_hi: w.rho_hi, w: w.rho_hi - w.rho_lo, d_certified: w.d_certified })))}`);
  console.log(`  check1 elapsed: ${(t1 - t0) / 1000}s`);

  console.log('a5/run.js: check2_penetration ...');
  const c2 = check2_penetration(c1.W, args.psi, args.delta, OPTS);
  fs.writeFileSync(path.join(outDir, 'a5.check2.result.json'), JSON.stringify(c2, null, 2));
  const t2 = Date.now();
  console.log(`  pass=${c2.pass} boxes=${c2.results.length}`);
  console.log(`  check2 elapsed: ${(t2 - t1) / 1000}s`);

  let A5_VERDICT;
  if (c1.existence === 'yes' && c1.all_roots_in_W && c2.pass) A5_VERDICT = 'FORBIDDEN';
  else A5_VERDICT = 'UNDETERMINED';
  console.log('A5_VERDICT: ' + A5_VERDICT);

  fs.writeFileSync(path.join(outDir, 'a5.summary.json'), JSON.stringify({
    args, options: OPTS, existence: c1.existence, all_roots_in_W: c1.all_roots_in_W,
    uniqueness: c1.uniqueness, W: c1.W, signChanges: c1.signChanges.length,
    check2: { pass: c2.pass, boxes: c2.results.length },
    elapsed: { check1_s: (t1 - t0) / 1000, check2_s: (t2 - t1) / 1000 },
    A5_VERDICT
  }, null, 2));
  console.log('a5/run.js rev8.8: done.');
}

main();
