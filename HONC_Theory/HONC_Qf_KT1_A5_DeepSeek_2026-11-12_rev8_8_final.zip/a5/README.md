# A-5 rev8.8 — строгое независимое покрытие

Проверка вердикта А-5 (кольцо 1→2 в торе навеса — `FORBIDDEN`, G-5а) без ядра.
Всё доказано интервальной арифметикой и адаптивным делением с объявленной
точностью. Никаких эмпирических допусков; ни одно число не подогнано.

## 1. Что доказано и каким доводом

### 1.1 `lib/ia.js` — строгая интервальная арифметика

`nextUp`/`nextDown` (IEEE 754 nextafter), наружное округление `+`, `−`, `×`, `÷`,
`π` с гарантированной вилкой, correctly-rounded `sqrt`, `sin`/`cos` через
приведение к `k·π/2 + r` + Тейлор N=10 (остаток ≤ 1.7·10⁻²⁵), критические
точки — явно, на границах секторов и узких вилках — 1-липшицево расширение
(fix от rev8.2).

### 1.2 `lib/vec.js` — интервальные векторы

Покомпонентные `+`, `−`, `×`, `dot`, `norm`, `unit`, `cross`.

### 1.3 `lib/geom.js` — зазор тор–тор (G-4), B&B с плато-детектором

`N_min = 180`, `K_refine = 8`, `L_φ = 0.5`. Ветвление только по ячейкам
с `d.lo − L·h/2 ≤ minHi`. Верхняя граница — `min_j d.hi`, нижняя —
`min_j(d.lo − L·h/2)`. Плато-детектор: если range не уменьшилось вдвое за
проход — стоп. Floor B&B `π/(2·N_max)` = 7.5·10⁻⁷ при `N_max = 2²¹`.
Box floor ≈ 5·width(ρ_box_rad) (эмпирическая константа, замер Клода).

### 1.4 `lib/opts.js` — единый источник параметров

`run.js` и `selftest.js` импортируют `OPTS` из `lib/opts.js` (fix от rev8.7).

### 1.5 `lib/build.js` — построение H1 по интерфейсу v6 § 2

`e = s·ex·cos ρ + (−ez·cos ψ + ey·sin ψ)·sin ρ`;
`T' = T_h − 2(T_h·e)·e`; `n = norm(e × T_h)`;
`T_H1 = rodrigues(T', n, δ)`; `A_H1 = A_T2 + e·d`.
Для К3 (ψ=0, δ=0): `g(ρ) = √(8 − 8 sin ρ) − 2`.

### 1.6 `solve_d.js` — поиск d(ρ): parent inheritance + box-aware tightness

**Fix от rev8.8 (Клод 12.11, speed).** В rev8.7 на каждый `?`-ящик 600 раз
вызывался full-scan `solveD`, до 7 с на узких ящиках. К4 и А-5 упирались
в 1800 с. В rev8.8:

**Parent inheritance.** Child ρ_box ⊂ parent ρ_box ⇒ `gap(H1(ρ_child, d), T2) ⊆
gap(H1(ρ_parent, d), T2)` для того же d (интервал, ширина которого растёт с
ρ_box). Если parent certified `sign_lo` в `d_lo_p` и `sign_hi` в `d_hi_p`,
то child тоже: его root лежит в `(d_lo_p, d_hi_p)`. Значит, `[d_lo_p, d_hi_p]`
— **certified bracket child'а**. Skip 41-point scan, skip initial verify;
bisection начинается с `[d_lo_p, d_hi_p]` (ширина ~10×box_floor_parent).

**Корректность inheritance.** Держится на монотонности: `gap_child(d) ⊆
gap_parent(d)`. Знак certified parent'а автоматически certified для child'а
(подмножество положительного — положительно; подмножество отрицательного —
отрицательно). Корректность конечного результата — всё равно по финальной
сертификации с расширением; inheritance — эвристика для skip scan.

**Fallback.** Если parent не certified (sign_lo/sign_hi не определены), child
делает full scan.

**Box-aware tightness.** `tol_tight_eff = max(gap_tol_tight, 5·width(ρ_box_rad))` —
на широких ящиках сертификация идёт с реально достижимой точностью; на узких
(1e-5°) box_floor мала и работает базовый `gap_tol_tight = 1e-6`.

**Shrink-in-place при `?`.** В bisection `tol_step = max(tol_tight_eff,
min(loose, w·0.2))`. При `?` в середине: если `tol_step < w/2` — shrink
до `[m − tol_step, m + tol_step]` (гарантированное сужение до `0.4·w`);
иначе `break`. Корректность **не** держится на гипотезе наклона ~1:
сужение — эвристика; финальная сертификация — единственный критерий.

**Сертификация.** На `tol_tight_eff` с расширением `w = 0..6` — страхует
вырожденный случай, когда root попал на конец вилки.

**Оговорка о единственности.** Единственность корня d в `[0.3, 3.5]` не
доказана — берётся первая смена знака.

### 1.7 `check1_root.js` — знак gap(H1, T1) на ρ-ящиках

`d = dExact` (δ=0) или `solveD` (δ≠0); `H1 = buildH1`; `gap(H1, T1)`:
`+`/`−`/`?`. Разбиение: `?` и ширина > `rho_min_width` → делим пополам.

**Передача bracket.** Если родитель certified (`d_certified && sign_lo &&
sign_hi`), его `[d_lo, d_hi, sign_lo, sign_hi]` передаётся в `solveD` детей
как `parent_bracket` — fast path inheritance.

**All-roots-in-W = true по построению.** Не-`?` ящик сертифицирован:
`gap` целиком одного знака — корня нет. Все `?` в W; ящики покрывают
всю `[rho_lo, rho_hi]`.

### 1.8 `check2_penetration.js` — проникновение R1 в тело H1

Для ρ-ящика из W: если `d_certified: false` — честный отказ; иначе
`H1 = buildH1`, `E(θ) = (0, sin θ, 3 − cos θ)`,
`dist_hi(E(θ), mid_circle H1) < 0.5` → прокол.
`Number.isFinite(null) === true` → явная проверка `d_lo !== null && d_hi !==
null && Number.isFinite(d_lo) && Number.isFinite(d_hi)`.

### 1.9 `run.js` — итог

`a5.summary.json`: `existence`, `all_roots_in_W`, `uniqueness`, `W`,
`check2`, `elapsed`, `A5_VERDICT`.

## 2. Объявленные параметры

Значения **фиксированы до прогона** в `lib/opts.js`.

```js
const OPTS = {
  gap_tol: 3e-6,
  gap_tol_loose: 1e-3,
  gap_tol_tight: 1e-6,
  d_tol: 1e-7,
  rho_min_width: 1e-5,
  check2_step: 1e-2,
  N_theta: 720,
  N_min: 180,
  K_refine: 8,
  N_max: 2097152
};
```

Параметры не меняются против rev8.7 — наследуются оттуда без изменения.
Единственное отличие — внутренний алгоритм `solveD` (inheritance).

## 3. Случаи и ожидания

| Случай | Команда | Ожидание |
|---|---|---|
| К3 | `--psi 0 --delta 0 --rho-lo 29.5 --rho-hi 30.5` | `existence: yes`, `all_roots_in_W: true`, W ∋ 30°, ширина W < 0.001° |
| К4 | `--psi 54 --delta 10 --rho-lo 57.0 --rho-hi 57.5` | `existence: yes`, `all_roots_in_W: true`, W ⊆ [57.260°, 57.262°] |
| А-5 | `--psi 56 --delta 10 --rho-lo 45 --rho-hi 65` | `existence: yes`, `all_roots_in_W: true`, `check2.pass: true`, `A5_VERDICT: FORBIDDEN` |

Значений ядра нет: 30°, 57.261°, `FORBIDDEN` — из спецификации § 2.11
(А-2, А-4, А-5).

**Ожидаемая скорость.**

**К3** — ~5–6 с (закрытая форма `dExact`, B&B плато). Не меняется.

**К4** (0.5° вилка, 16 уровней до 1e-5°):

- root box — full scan (~5 с), bracket cert (2 вызова), сертификация (~4).
- child-уровни (inheritance): bisection (~6–8 итераций из parent bracket
  ширины ~10×box_floor_parent до 2e-6), сертификация (~4 вызова). Итого
  **~10–12 `gapH1T2` на child-`solveD`** (было ~50–80 в rev8.7).
- на узком box (1e-5°): `tol_tight_eff = 1e-6`; каждый `gapH1T2` ~80–150 мс.
  Один `solveD` ≈ 1.0–1.5 с.
- ~600 solveD × 1.2 с ≈ **~720 с на К4**.

**А-5** (20° вилка, 20 уровней): ~800 solveD × 1.2 с ≈ **~960 с**.

В пределах 1800 с с запасом 1.8×.

## 4. Что остаётся оговоркой

1. **Единственность корня ρ** — только `practical_one_change`.
2. **Единственность корня d в `[0.3, 3.5]`** — не доказана.
3. **`check2` — верхняя граница.** `dist_hi < 0.5` — «внутри»;
   `dist_lo < 0.5 < dist_hi` → `found: false`.
4. **`check2` использует d из check1.**
5. **Предел `N_max`.**
6. **Shrink-in-place — эвристика**, корректность — только по финальной
   сертификации (§ 1.6).
7. **`box_floor ≈ 5·width(ρ_box_rad)`** — эмпирическая константа.
8. **Parent inheritance.** Держится на монотонности: `child ρ_box ⊂ parent
   ρ_box ⇒ gap_child(d) ⊆ gap_parent(d)`. Если parent certified — child
   certified на том же bracket. Fallback на full scan при неудаче.

## 5. Слепота

**Видел:** источники (спецификация v0.3 § 2.1, § 2.11; интерфейс v6
§§ 1–4), свой код rev7. Ядро, его код, протоколы — не видел.
`A5.json` — HELD.

**Не видел:** эталонов ядра для К4/А-5, протоколов ядра, кода ядра,
выходов прогонов А-5 на ядре. Все эталоны взяты из спецификации.

## 6. Проверка перед сдачей (`a5/selftest.js`)

- `sin`/`cos` на 45°/135°/225°/315°: вилка содержит точное значение;
- без падения на соседних double и узких вилках;
- `deg2rad(30)` и `deg2radI([30,30])`;
- `gapTorusTorus` на К3 при ρ ∈ {29.9°, 30.0°, 30.1°}: вилка содержит
  аналитику `√(8 − 8 sin ρ) − 2`, ширина ≤ 2·`gap_tol`;
- **`solveD_K4_narrow`**: на 1e-5° ящике у корня К4 `solveD` ok, вилка
  g(H1, T1) ≤ 4·10⁻⁶;
- **`inheritance_parent` / `inheritance_child_fast` / `inheritance_child_full` /
  `inheritance_agreement`** (новое от rev8.8):
  - parent solveD ok, sign_lo ≠ sign_hi;
  - child (parent_bracket) ok, `inherited: true`, d-root ⊆ parent bracket;
  - child (full scan) ok — тот же root, что fast path;
  - `inheritance_agreement`: |d_lo_fast − d_lo_full| < 1e-4,
    |d_hi_fast − d_hi_full| < 1e-4; speedup печатается.
- Все параметры — из `lib/opts.js`.
