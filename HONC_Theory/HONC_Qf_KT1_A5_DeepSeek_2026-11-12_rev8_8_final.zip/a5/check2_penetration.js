'use strict';
const { I } = require('./lib/ia');
const { V } = require('./lib/vec');
const { distPointToMidCircle } = require('./lib/geom');
const { buildH1 } = require('./lib/build');
const { solveD, dExact } = require('./solve_d');

function penetrationBox(rho_lo, rho_hi, psi, delta, opts, dPre) {
  const rho_I = I.deg2radI(new I(rho_lo, rho_hi));
  const psi_I = I.deg2rad(psi);
  const delta_I = I.deg2rad(delta);
  let d_lo, d_hi;

  // Явная проверка валидности d (Клод 12.11, Н-4): isFinite(null) === true,
  // поэтому «if (isFinite(d_lo))» пропускал null. Различаем «число» и «null»
  // через Number.isFinite + явный не-null.
  const hasValidD = dPre
    && dPre.d_lo !== null && dPre.d_hi !== null
    && Number.isFinite(dPre.d_lo) && Number.isFinite(dPre.d_hi);

  if (hasValidD) {
    d_lo = dPre.d_lo; d_hi = dPre.d_hi;
  } else if (delta === 0) {
    const d = dExact(rho_I, psi_I);
    d_lo = d.lo; d_hi = d.hi;
  } else {
    const dR = solveD(rho_I, psi_I, delta_I, opts);
    if (!dR.ok) return { found: false, reason: 'no certified d: ' + dR.reason };
    d_lo = dR.d_lo; d_hi = dR.d_hi;
  }

  const H = buildH1(rho_I, psi_I, delta_I, new I(d_lo, d_hi));
  const zero = I.of(0), three = I.of(3);
  for (let j = 0; j < opts.N_theta; j++) {
    const thetaDeg = 360 * j / opts.N_theta;
    const theta = I.deg2rad(thetaDeg);
    const E = new V(zero, theta.sin(), three.sub(theta.cos()));
    const dist = distPointToMidCircle(E, H.A_H1, H.T_H1);
    if (dist.hi < 0.5) return { found: true, theta_deg: thetaDeg, dist_hi: dist.hi };
  }
  return { found: false, reason: 'no theta in grid' };
}

function check2_penetration(W, psi, delta, opts) {
  if (!W || W.length === 0) return { pass: false, reason: 'empty W', results: [] };
  const results = [];
  for (const w of W) {
    // Если W пришёл с d_certified: false — никаких расчётов, честный отказ.
    if (w.d_certified === false) {
      results.push({ rho_lo: w.rho_lo, rho_hi: w.rho_hi, found: false, reason: 'W without certified d' });
      continue;
    }
    const nSub = Math.max(1, Math.ceil((w.rho_hi - w.rho_lo) / opts.check2_step));
    for (let k = 0; k < nSub; k++) {
      const a = w.rho_lo + k * (w.rho_hi - w.rho_lo) / nSub;
      const b = w.rho_lo + (k + 1) * (w.rho_hi - w.rho_lo) / nSub;
      const r = penetrationBox(a, b, psi, delta, opts, { d_lo: w.d_lo, d_hi: w.d_hi });
      results.push({ rho_lo: a, rho_hi: b, ...r });
    }
  }
  return { pass: results.every(r => r.found), results };
}

module.exports = { check2_penetration };
