'use strict';
const { I } = require('./lib/ia');
const { gapTorusTorus } = require('./lib/geom');
const { buildH1, A_T1, Y_HAT } = require('./lib/build');
const { solveD, dExact } = require('./solve_d');

function signGapH1T1(rho_lo, rho_hi, psi, delta, opts, parentBracket) {
  const rho_I = I.deg2radI(new I(rho_lo, rho_hi));
  const psi_I = I.deg2rad(psi);
  const delta_I = I.deg2rad(delta);
  let d_lo, d_hi, d_certified, sign_lo, sign_hi;
  if (delta === 0) {
    const d = dExact(rho_I, psi_I);
    d_lo = d.lo; d_hi = d.hi; d_certified = true; sign_lo = null; sign_hi = null;
  } else {
    const subOpts = parentBracket ? Object.assign({}, opts, { parent_bracket: parentBracket }) : opts;
    const dR = solveD(rho_I, psi_I, delta_I, subOpts);
    if (!dR.ok) {
      return { sign: '?', gap_lo: null, gap_hi: null, d_lo: null, d_hi: null,
               d_certified: false, sign_lo: null, sign_hi: null, reason: dR.reason };
    }
    d_lo = dR.d_lo; d_hi = dR.d_hi; d_certified = true;
    sign_lo = dR.sign_lo; sign_hi = dR.sign_hi;
  }
  const H = buildH1(rho_I, psi_I, delta_I, new I(d_lo, d_hi));
  const g = gapTorusTorus(H.A_H1, H.T_H1, A_T1, Y_HAT, opts);
  return {
    sign: g.isPos() ? '+' : (g.isNeg() ? '-' : '?'),
    gap_lo: g.lo, gap_hi: g.hi,
    d_lo, d_hi, d_certified, sign_lo, sign_hi, reason: null
  };
}

function buildBoxes(rho_lo, rho_hi, psi, delta, opts, parentBracket) {
  const r = signGapH1T1(rho_lo, rho_hi, psi, delta, opts, parentBracket);
  const box = { rho_lo, rho_hi, ...r };
  if (r.sign === '?' && (rho_hi - rho_lo) > opts.rho_min_width) {
    const mid = (rho_lo + rho_hi) / 2;
    const childBracket = (r.d_certified && r.sign_lo && r.sign_hi)
      ? { d_lo: r.d_lo, d_hi: r.d_hi, sign_lo: r.sign_lo, sign_hi: r.sign_hi }
      : null;
    const left = buildBoxes(rho_lo, mid, psi, delta, opts, childBracket);
    const right = buildBoxes(mid, rho_hi, psi, delta, opts, childBracket);
    return [...left, ...right];
  }
  return [box];
}

function check1_root(psi, delta, rho_lo, rho_hi, opts) {
  const boxes = buildBoxes(rho_lo, rho_hi, psi, delta, opts, null);
  boxes.sort((a, b) => a.rho_lo - b.rho_lo);

  const W = [];
  for (const b of boxes) {
    if (b.sign !== '?') continue;
    if (W.length && Math.abs(W[W.length - 1].rho_hi - b.rho_lo) < 1e-9) {
      const last = W[W.length - 1];
      last.rho_hi = b.rho_hi;
      last.d_certified = last.d_certified && b.d_certified;
      if (b.d_certified && b.d_lo !== null && b.d_hi !== null) {
        last.d_lo = (last.d_lo === null) ? b.d_lo : Math.min(last.d_lo, b.d_lo);
        last.d_hi = (last.d_hi === null) ? b.d_hi : Math.max(last.d_hi, b.d_hi);
      }
    } else {
      W.push({
        rho_lo: b.rho_lo, rho_hi: b.rho_hi,
        d_lo: b.d_certified ? b.d_lo : null,
        d_hi: b.d_certified ? b.d_hi : null,
        d_certified: b.d_certified
      });
    }
  }

  const signChanges = [];
  let prevSign = null, prevBox = null;
  for (const b of boxes) {
    if (b.sign === '?') continue;
    if (prevSign !== null && prevSign !== b.sign) {
      signChanges.push({ rho_a_lo: prevBox.rho_lo, rho_b_hi: b.rho_hi, sign_a: prevSign, sign_b: b.sign });
    }
    prevSign = b.sign; prevBox = b;
  }

  const all_roots_in_W = true;
  const existence = signChanges.length > 0 ? 'yes' : (W.length > 0 ? 'undetermined_with_W' : 'no');
  const uniqueness = signChanges.length === 1 ? 'practical_one_change'
    : (signChanges.length === 0 ? 'no_change' : 'multiple_changes');

  return { config: { psi, delta, rho_bracket: [rho_lo, rho_hi] }, boxes_count: boxes.length,
    boxes, W, signChanges, existence, uniqueness, all_roots_in_W };
}

module.exports = { check1_root };
