'use strict';
const { I } = require('./lib/ia');
const { gapTorusTorus } = require('./lib/geom');
const { buildH1, A_T1, Y_HAT } = require('./lib/build');
const { dExact, solveD } = require('./solve_d');
const { OPTS } = require('./lib/opts');

const results = [];
function record(id, status, details) { results.push({ id, status, details: details || null }); }

function testTrig() {
  const sqrt2half = Math.SQRT2 / 2;
  const cases = [
    { deg: 45,  rad: Math.PI/4,   sin: sqrt2half,  cos: sqrt2half  },
    { deg: 135, rad: 3*Math.PI/4, sin: sqrt2half,  cos: -sqrt2half },
    { deg: 225, rad: 5*Math.PI/4, sin: -sqrt2half, cos: -sqrt2half },
    { deg: 315, rad: 7*Math.PI/4, sin: -sqrt2half, cos: sqrt2half  }
  ];
  for (const c of cases) {
    try {
      const s = I.of(c.rad).sin();
      record('sin_at_' + c.deg + 'deg', (s.lo - 1e-15 <= c.sin && c.sin <= s.hi + 1e-15) ? 'PASS' : 'FAIL',
        { lo: s.lo, hi: s.hi, exact: c.sin });
    } catch (e) { record('sin_at_' + c.deg + 'deg', 'FAIL', { err: String(e) }); }
    try {
      const co = I.of(c.rad).cos();
      record('cos_at_' + c.deg + 'deg', (co.lo - 1e-15 <= c.cos && c.cos <= co.hi + 1e-15) ? 'PASS' : 'FAIL',
        { lo: co.lo, hi: co.hi, exact: c.cos });
    } catch (e) { record('cos_at_' + c.deg + 'deg', 'FAIL', { err: String(e) }); }
    try {
      const s = (new I(c.rad - 3e-16, c.rad + 3e-16)).sin();
      record('sin_adj_' + c.deg, isFinite(s.lo) && isFinite(s.hi) ? 'PASS' : 'FAIL', { lo: s.lo, hi: s.hi });
    } catch (e) { record('sin_adj_' + c.deg, 'FAIL', { err: String(e) }); }
    try {
      const s = (new I(c.rad - 1e-10, c.rad + 1e-10)).sin();
      record('sin_narrow_' + c.deg, (s.lo - 1e-12 <= c.sin && c.sin <= s.hi + 1e-12) ? 'PASS' : 'FAIL',
        { lo: s.lo, hi: s.hi });
    } catch (e) { record('sin_narrow_' + c.deg, 'FAIL', { err: String(e) }); }
  }
}

function testDeg2Rad() {
  const r = I.deg2rad(30);
  const exact = Math.PI / 6;
  record('deg2rad_30', r.lo <= exact && exact <= r.hi ? 'PASS' : 'FAIL', { lo: r.lo, hi: r.hi, exact });
  const r2 = I.deg2radI(new I(30, 30));
  record('deg2radI_30_30', r2.lo <= exact && exact <= r2.hi ? 'PASS' : 'FAIL', { lo: r2.lo, hi: r2.hi });
  const r3 = I.deg2radI(new I(30, 31));
  record('deg2radI_30_31', r3.lo < r3.hi ? 'PASS' : 'FAIL', { lo: r3.lo, hi: r3.hi });
}

function testK3Analytic() {
  for (const rho_deg of [29.9, 30.0, 30.1]) {
    const rho = I.deg2rad(rho_deg);
    const psi = I.of(0), delta = I.of(0);
    const d = dExact(rho, psi);
    const H = buildH1(rho, psi, delta, d);
    const t0 = Date.now();
    let g;
    try { g = gapTorusTorus(H.A_H1, H.T_H1, A_T1, Y_HAT, OPTS); }
    catch (e) { record('k3_gap_rho_' + rho_deg, 'FAIL', { err: String(e) }); continue; }
    const dt = Date.now() - t0;
    const rhoRad = rho_deg * Math.PI / 180;
    const analytic = Math.sqrt(8 - 8 * Math.sin(rhoRad)) - 2;
    const margin = 1e-9;
    const contains = g.lo - margin <= analytic && analytic <= g.hi + margin;
    const widthOk = (g.hi - g.lo) <= 2 * OPTS.gap_tol;
    record('k3_gap_rho_' + rho_deg, (contains && widthOk) ? 'PASS' : 'FAIL',
      { lo: g.lo, hi: g.hi, analytic, width: g.hi - g.lo, ms: dt });
  }
}

function testSolveDK4Narrow() {
  const rho_lo = 57.2, rho_hi = 57.2 + OPTS.rho_min_width;
  const psi = 54, delta = 10;
  const rho_I = I.deg2radI(new I(rho_lo, rho_hi));
  const psi_I = I.deg2rad(psi);
  const delta_I = I.deg2rad(delta);
  const t0 = Date.now();
  let res;
  try { res = solveD(rho_I, psi_I, delta_I, OPTS); }
  catch (e) { record('solveD_K4_narrow', 'FAIL', { err: String(e), ms: Date.now() - t0 }); return; }
  const dt = Date.now() - t0;
  if (!res.ok) {
    record('solveD_K4_narrow', 'FAIL', { ok: false, reason: res.reason, ms: dt });
    return;
  }
  const d_I = new I(res.d_lo, res.d_hi);
  const H = buildH1(rho_I, psi_I, delta_I, d_I);
  let gH1T1;
  try { gH1T1 = gapTorusTorus(H.A_H1, H.T_H1, A_T1, Y_HAT, OPTS); }
  catch (e) { record('solveD_K4_narrow', 'FAIL', { ok: true, err: String(e), ms: dt }); return; }
  const forkWidth = gH1T1.hi - gH1T1.lo;
  record('solveD_K4_narrow', forkWidth <= 4e-6 ? 'PASS' : 'FAIL', {
    ok: true, d_lo: res.d_lo, d_hi: res.d_hi, d_width: res.width,
    gH1T1_lo: gH1T1.lo, gH1T1_hi: gH1T1.hi, gH1T1_width: forkWidth,
    budget_max: 4e-6, ms: dt, inherited: res.inherited
  });
}

// Parent inheritance test (rev8.8): child box ⊂ parent box.
//   1. solveD(parent) даёт certified bracket [d_lo_p, d_hi_p] с sign_lo / sign_hi.
//   2. solveD(child, parent_bracket) должен вернуть ok, inherited=true, и
//      child d-root ⊆ parent bracket. Скорость child'а << parent.
//   Корректность: child ρ_box ⊂ parent ρ_box ⇒ gap_child(d) ⊆ gap_parent(d) для
//   того же d; parent sign'ы certified ⇒ child тоже; root child в (d_lo_p, d_hi_p).
function testParentInheritance() {
  const psi = 54, delta = 10;
  const psi_I = I.deg2rad(psi);
  const delta_I = I.deg2rad(delta);

  // Parent: [57.19°, 57.20°], 1e-2° ширина.
  const p_lo = 57.19, p_hi = 57.20;
  // Child: [57.195°, 57.196°], 1e-3° ширина, ⊂ parent.
  const c_lo = 57.195, c_hi = 57.196;

  const pRhoI = I.deg2radI(new I(p_lo, p_hi));
  const cRhoI = I.deg2radI(new I(c_lo, c_hi));

  let t0 = Date.now();
  let pR;
  try { pR = solveD(pRhoI, psi_I, delta_I, OPTS); }
  catch (e) { record('inheritance_parent', 'FAIL', { err: String(e) }); return; }
  const pMs = Date.now() - t0;
  if (!pR.ok) {
    record('inheritance_parent', 'FAIL', { ok: false, reason: pR.reason });
    return;
  }
  record('inheritance_parent', (pR.sign_lo && pR.sign_hi && pR.sign_lo !== pR.sign_hi) ? 'PASS' : 'FAIL',
    { ok: true, d_lo: pR.d_lo, d_hi: pR.d_hi, sign_lo: pR.sign_lo, sign_hi: pR.sign_hi, ms: pMs });

  // Child with parent bracket (fast path).
  t0 = Date.now();
  let cFast;
  try { cFast = solveD(cRhoI, psi_I, delta_I, Object.assign({}, OPTS, { parent_bracket: pR })); }
  catch (e) { record('inheritance_child_fast', 'FAIL', { err: String(e) }); return; }
  const cFastMs = Date.now() - t0;

  // Child without parent bracket (full scan) — для сверки.
  t0 = Date.now();
  let cFull;
  try { cFull = solveD(cRhoI, psi_I, delta_I, OPTS); }
  catch (e) { record('inheritance_child_full', 'FAIL', { err: String(e) }); return; }
  const cFullMs = Date.now() - t0;

  const subsetOk = cFast.ok && cFull.ok
    && cFast.d_lo >= pR.d_lo - 1e-12 && cFast.d_hi <= pR.d_hi + 1e-12;
  const agreeOk = cFast.ok && cFull.ok
    && Math.abs(cFast.d_lo - cFull.d_lo) < 1e-4
    && Math.abs(cFast.d_hi - cFull.d_hi) < 1e-4;

  record('inheritance_child_fast', (cFast.ok && cFast.inherited === true && subsetOk) ? 'PASS' : 'FAIL',
    { ok: cFast.ok, inherited: cFast.inherited, d_lo: cFast.d_lo, d_hi: cFast.d_hi,
      d_width: cFast.width, parent_bracket: { lo: pR.d_lo, hi: pR.d_hi },
      subset: subsetOk, ms: cFastMs, bisect_iters: cFast.bisect_iters });

  record('inheritance_child_full', cFull.ok ? 'PASS' : 'FAIL',
    { ok: cFull.ok, d_lo: cFull.d_lo, d_hi: cFull.d_hi, d_width: cFull.width,
      ms: cFullMs, inherited: cFull.inherited });

  record('inheritance_agreement', agreeOk ? 'PASS' : 'FAIL',
    { d_lo_fast: cFast.d_lo, d_lo_full: cFull.d_lo,
      d_hi_fast: cFast.d_hi, d_hi_full: cFull.d_hi,
      speedup: (cFullMs / Math.max(1, cFastMs)).toFixed(2) + 'x' });
}

function main() {
  testTrig();
  testDeg2Rad();
  testK3Analytic();
  testSolveDK4Narrow();
  testParentInheritance();
  const passed = results.filter(r => r.status === 'PASS').length;
  const failed = results.filter(r => r.status === 'FAIL').length;
  console.log('=== a5/selftest.js rev8.8 ===');
  console.log('OPTS =', JSON.stringify(OPTS));
  for (const r of results) {
    console.log(`  ${r.status}  ${r.id}`);
    if (r.status !== 'PASS') console.log('    details:', JSON.stringify(r.details));
  }
  console.log(`Total: ${results.length}; PASS=${passed} FAIL=${failed}`);
  process.exit(failed > 0 ? 1 : 0);
}

main();
