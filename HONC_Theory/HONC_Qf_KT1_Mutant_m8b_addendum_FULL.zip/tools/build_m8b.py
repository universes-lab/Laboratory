#!/usr/bin/env python3
# Мутант м8, вариант б («с подставным основанием») — по решению Интегратора 05.11, п. 5: различить ошибку в логике K-1,
# а не только срабатывание встроенной самопроверки ядра. Кандидат (0 в вилке зазора) записывается как IMPOSED И получает
# подставное основание, поэтому самопроверка схемы «IMPOSED без основания» его не останавливает.
#   python3 -I build_m8b.py <замороженный.zip> <папка вывода>
import hashlib, json, sys, zipfile
FROZEN = 'ecb35112d85911c810d70942f3655ddc25ed19c9047befff2cb7dfbf6ea268ea'
src, out = sys.argv[1], sys.argv[2]
assert hashlib.sha256(open(src, 'rb').read()).hexdigest() == FROZEN
edits = [
 ('kt1/wp4_contacts.js', "g.gap[1] < 0 ? 'PENETRATION' : 'CANDIDATE';", "g.gap[1] < 0 ? 'PENETRATION' : 'IMPOSED'; // МУТАНТ м8б"),
 ('kt1/wp4_contacts.js', "contacts.push({ pair: [a.name, b.name], cls, existence, basis: imp ? imp.basis : null,",
  "contacts.push({ pair: [a.name, b.name], cls, existence, basis: imp ? imp.basis : (existence === 'IMPOSED' ? { rule: 'П-8а', note: 'МУТАНТ м8б: подставное основание' } : null),"),
]
zin = zipfile.ZipFile(src); names = zin.namelist(); files = {n: zin.read(n) for n in names}
for p, o, n in edits:
    s = files[p].decode('utf-8'); c = s.count(o); assert c == 1, f'{p}: {c}'; files[p] = s.replace(o, n).encode('utf-8')
zp = f'{out}/HONC_Qf_KT1_Mutant_m8b.zip'
with zipfile.ZipFile(zp, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, date_time=(2026, 11, 5, 0, 0, 0)); zi.external_attr = zin.getinfo(n).external_attr; z.writestr(zi, files[n])
sha = hashlib.sha256(open(zp, 'rb').read()).hexdigest()
reg = json.load(open(f'{out}/registry.json'))
reg['mutants'] = [m for m in reg['mutants'] if m['id'] != 'm8b'] + [{'id': 'm8b', 'description': 'Кандидат как подтверждённое касание, с подставным основанием (обходит самопроверку схемы «IMPOSED без основания»); решение Интегратора 05.11, п. 5',
   'sha256': sha, 'archive': zp.split('/')[-1], 'edits': [{'file': p, 'old': o, 'new': n} for p, o, n in edits]}]
json.dump(reg, open(f'{out}/registry.json', 'w'), ensure_ascii=False, indent=1)
print('m8b', sha)
