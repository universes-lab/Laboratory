'use strict';
const fs = require('fs');
const path = require('path');
const ops = require('./lib/ops');
const SV = require('./lib/schema-validator');
const CV = require('./lib/config-validator');
const { applyExpect, checkNum } = ops;

const K = require(path.join(process.env.KT1_DIR, 'kt1'));
const OUT = process.env.KT1_OUT;
if (!OUT) { console.error('KT1_OUT not set'); process.exit(2); }
const PROTO = path.join(OUT, 'protocols');
if (!fs.existsSync(PROTO)) fs.mkdirSync(PROTO, { recursive: true });

const expected = JSON.parse(fs.readFileSync(path.join(__dirname, 'expected.json'), 'utf8'));

function loadCase(name) {
  const p = path.join(__dirname, 'cases', name + '.json');
  if (!fs.existsSync(p)) return null;
  const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
  if (raw.same_as) return loadCase(raw.same_as);
  return raw;
}
function safeCall(fn) {
  try { return { ok: true, value: fn() }; }
  catch (e) { return { ok: false, err: String(e && e.stack || e) }; }
}
function saveProto(id, v) {
  try { fs.writeFileSync(path.join(PROTO, id + '.json'), JSON.stringify(v, null, 2)); } catch (e) {}
}

function runOne(caseId, spec, expectArr, numArr) {
  const r = { id: caseId, status: 'PASS', problems: [] };
  const cd = loadCase(caseId);
  if (!cd) { r.status = 'ERROR'; r.problems.push(`case not found: ${caseId}`); return r; }
  const call = safeCall(() => K.run(cd));
  if (!call.ok) { r.status = 'ERROR'; r.problems.push(`K.run threw: ${call.err}`); return r; }
  saveProto(caseId, call.value);
  if (!cd.family) {
    const svErrs = SV.validate(call.value);
    if (svErrs.length > 0) r.problems.push('schema: ' + svErrs.slice(0,3).join('; ') + (svErrs.length>3 ? ` ... (${svErrs.length})` : ''));
    const cvErrs = CV.check(call.value);
    if (cvErrs.length > 0) r.problems.push('config: ' + cvErrs.join('; '));
  }
  for (const exp of (expectArr || [])) r.problems.push(...applyExpect(call.value, exp));
  r.problems.push(...checkNum(call.value, numArr || []));
  if (r.problems.length && r.status === 'PASS') r.status = 'FAIL';
  return r;
}

function runTest(id, spec) {
  if (spec.kind === 'K.composite') {
    const results = [];
    for (const cid of spec.cases) {
      const expArr = (spec.expect && spec.expect[cid]) || [];
      const numArr = (spec.num && spec.num[cid]) || [];
      results.push(runOne(cid, spec, expArr, numArr));
    }
    const pass = results.every(r => r.status === 'PASS');
    const allProblems = [];
    for (const r of results) for (const p of r.problems) allProblems.push(`${r.id}: ${p}`);
    return { id, kind: spec.kind, status: pass ? 'PASS' : 'FAIL', problems: allProblems, sub: results };
  }
  if (spec.kind === 'K.run') {
    return Object.assign({ kind: spec.kind }, runOne(spec.case, spec, spec.expect, spec.num));
  }
  return { id, kind: spec.kind, status: 'ERROR', problems: [`unknown kind: ${spec.kind}`] };
}

function main() {
  const results = [];
  for (const id of Object.keys(expected.tests)) {
    results.push(runTest(id, expected.tests[id]));
  }
  fs.writeFileSync(path.join(OUT, 'd6_results.json'),
    JSON.stringify({ meta: expected.meta, results, mutants: expected.mutants, run_date: new Date().toISOString() }, null, 2));
  const p = results.filter(r => r.status === 'PASS').length;
  const f = results.filter(r => r.status === 'FAIL').length;
  const e = results.filter(r => r.status === 'ERROR').length;
  console.log(`d6: ${results.length} tests; PASS=${p} FAIL=${f} ERROR=${e}`);
  process.exit(0);
}
main();
