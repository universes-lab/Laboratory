# d6 — исполняемый набор КТ-2 (R1 / Д-6), rev1

Задание: `DEEPSEEK_KT2_D6_ORDER_2026-11-13.md`
Ожидания: `D-5 ред. 3`, фиксирован 13.11
База: `d3/` rev5.1 (`HONC_Qf_KT1_D3_DeepSeek_2026-11-10_rev5_1.zip`, sha256 `5e9282cb…2b19`)
Все файлы — LF.

## 1. Состав

- `run.js` — прогон с ядром: 20 испытаний, 1 мутант m7.
- `selftest.js` — испытания операций, валидаторов и путей без ядра.
- `expected.json` — все ожидания.
- `cases/<id>.json` — 17 входов.
- `lib/` — 6 файлов: `agm.js`, `compare.js`, `config-validator.js`, `k6-enumerator.js`, `ops.js`, `schema-validator.js`.

## 2. Запуск

- С ядром: `KT1_DIR=/sandbox/kernel/kt1 KT1_OUT=/sandbox/work node d6/run.js`
- Без ядра: `KT1_OUT=/sandbox/work node d6/selftest.js`
- Вызов ядра: `K = require(path.join(process.env.KT1_DIR, 'kt1'))`, `K.run(case)`.
- Итог: `KT1_OUT/d6_results.json`, протоколы в `KT1_OUT/protocols/<id>.json`, финальная строка печати:
  `d6: N tests; PASS=… FAIL=… ERROR=…`.
- Протокол ядра КТ-2 печатает `"interface": 7.1`, `"protocol": "honc-qf-r1-kt1"`.
- Валидатор схемы — по интерфейсу v6, § 6, с добавлениями v7 и v7.1. Новые ключи (`output`, `crosschecks`, `plane_relation_basis`, `parallel_class`, `family`, `interface: 7.1`) принимаются. Поле `layer` проверяется по-прежнему — `CARRIER` (v6, § 6.1).

## 3. Происхождение

- Ожидания — из Д-5 ред. 3 (таблица «Ожидаемое» и § 4 «Итоги» каждой карточки), с поправками П1, П2, П3 фиксации.
- Логика прогона, операции, структура `expected.json` — по образцу `d3/` rev5.1.
- Строки правил в протоколе — без скобок (интерфейс v7.1, поправка 1, FIXED 13.11).

## 4. Формат `expect`

В Д-3 `expect` — объект «путь → список допустимых значений». В Д-6 `expect` — **массив записей**, потому что у каждого ожидания задания (§ 5, п. 2) должен быть свой `src` и `ref`. Формат:

- **Простое ожидание по пути** в протоколе:
  ```json
  {"path": "verdict.geometry", "in": ["PASSED"], "src": "…", "ref": "…"}
  ```
  `path` — путь через `deepGet` (точки и скобки). `in` — список допустимых значений; если `in` нет — одиночное `value`.
- **Ожидание на пару `contacts[]`**:
  ```json
  {"kind": "contacts", "pairs": [["T1","T2"],["T2","T3"]],
   "field": "existence", "value": "IMPOSED", "src": "…", "ref": "…"}
  ```
- **Ожидание на ребро `j5.edges[]`**:
  ```json
  {"kind": "j5_edges", "pairs": [["H1","H2"]],
   "field": "cls", "value": "CONTACT-ONLY", "src": "…", "ref": "…"}
  ```
- **Ожидание на запись `checks[]`**:
  ```json
  {"kind": "checks", "req": "R-3", "objects_list": [["RH1","RH2"]],
   "field": "completeness", "value": "EXACT", "src": "…", "ref": "…"}
  ```
- **Составное испытание**: `cases` (список входов), `expect` — `{ "<вход>": [ … ] }`, `num` — `{ "<вход>": [ … ] }`. `PASS` составного — только если `PASS` по всем входам.

**Обработчик.** Формат обрабатывается в `lib/ops.js` функциями `applyExpect(proto, spec)` и `checkNum(proto, nums)`. `applyExpect` различает виды по полям `kind` (отсутствует — простой `path`); `checkNum` — цикл по массиву `num` с вызовом `extractNum` (виды `k: "contact"` и `k: "path"`) и `applyOp`. Для `contacts[]`, `j5.edges[]` и `checks[]` поиск идёт по паре (порядок не важен), по множеству `objects` или по `req`+`objects` — не по номеру в массиве и не по `id`.

## 5. Таблица «ключ ожидания → путь в протоколе → параграф интерфейса»

| Ключ в `expect` / путь | Путь в протоколе | Интерфейс |
|---|---|---|
| `path = "verdict.geometry"` | `verdict.geometry` | v6, § 6 |
| `path = "j5.canon.verdict"` | `j5.canon.verdict` | v6, § 6.3 |
| `path = "j5.ext.verdict"` | `j5.ext.verdict` | v6, § 6.3 |
| `kind = "j5_edges"`, `field = "cls"` | `j5.edges[]`, запись по `pair`, поле `cls` | v6, § 6.3, § 7 |
| `kind = "contacts"`, `field = "existence"` | `contacts[]`, запись по `pair`, поле `existence` | v6, § 6.2 |
| `kind = "contacts"`, `field = "basis.rule"` | `contacts[]`, поле `basis.rule` | v6, § 6.2; v7.1, поправка 1 |
| `kind = "contacts"`, `field = "gap"` (через `num` вид `contact`, `f = "gap"`) | `contacts[]`, поле `gap` | v6, § 6.2; спецификация, G-4 |
| `kind = "checks"`, `req ∈ {R-2, R-3, R-5, R-6}`, `field = "completeness" / "verdict" / "contact_class" / "plane_relation_basis.rule"` | `checks[]`, запись по `req` и `objects`, соответствующее поле | v6, § 6.4; v7, § 4; v7.1, § 3; v7.1, поправка 1 |
| `path = "output.family.first_stop.value"` | `output.family.first_stop.value` | v7, § 5 |
| `path = "output.family.last_admissible.value"` | `output.family.last_admissible.value` | v7, § 5 |

## 6. Допуски

Из карточки (`tol`, `tol_src`). Где допуска нет — правило округления (полуоткрытый интервал до последнего опубликованного разряда).

## 7. Изменения в `lib/` против `d3/lib/`

| Файл | Изменение |
|---|---|
| `agm.js` | код как в Д-3; комментарии и пустые строки убраны |
| `compare.js` | код как в Д-3; комментарии и пустые строки убраны |
| `config-validator.js` | код как в Д-3; комментарии и пустые строки убраны |
| `k6-enumerator.js` | код как в Д-3; комментарии убраны |
| `schema-validator.js` | код как в Д-3; в двух сообщениях убрано «in KT-1» — требование `layer: CARRIER` (v6, § 6.1) сохранено |
| `ops.js` | переписан под формат `expect` Д-6. Функции: `isFork`, `pairEq`, `deepGet`, `findCheck`, `findContact`, `findEdge`, `findCheckByObjects`, `applyExpect`, `extractNum`, `applyOp`, `checkNum`. Убраны функции `d3/lib/ops.js`, использовавшиеся только в `checkExpect` Д-3: `getCusps`, `isCusp`, `findCusp`, `checkExpect`. Логика `deepGet` и `pairEq` — как в Д-3. |

## 8. Открытые вопросы

1. **Проверка схемы протокола для входа `family`.** Интерфейс v7, § 5 не задаёт состав протокола верхнего уровня для входа `family`. Для `B7-B1-property` проверки `SV.validate` и `CV.check` в `run.js` не выполняются. Для остальных испытаний — выполняются после `saveProto`.

2. **`output.geometry` и `output.admissible` для входа `family`.** Интерфейс v7, § 5 для `family` определяет только `output.family`. Ожидания на верхнеуровневые `output.geometry` и `output.admissible` в `B7-B1-property` сняты как не определённые интерфейсом.

3. **Имя ключа значения в `output.family.first_stop` и `output.family.last_admissible`.** Интерфейс v7, § 5 говорит «значение», имя ключа не задаёт. В `expected.json` принято `value`. Если в протоколе ядра ключ называется иначе — это уточнение пути, не ожидания.

## 9. Слепота

**Видел:** Д-5 ред. 3 (свой текст), интерфейс v6/v7/v7.1 + поправка 1, `d3/` rev5.1, `DEEPSEEK_KT2_D6_ORDER_2026-11-13.md`.
**Не видел:** протоколы ядра КТ-2, код ядра КТ-2, значений ядра КТ-2, разделы § 10.3 сводки состояния.
