'use strict';
const fs = require('fs');
const path = require('path');
const ops = require('./lib/ops');
const SV = require('./lib/schema-validator');
const CV = require('./lib/config-validator');
const { applyExpect, checkNum, deepGet } = ops;

const OUT = process.env.KT1_OUT;
if (!OUT) { console.error('KT1_OUT not set'); process.exit(2); }
const results = [];
function record(id, status, details) { results.push({ id, status, details: details || null }); }

function testDeepGet() {
  const o = { a: { b: [{ c: 42 }] }, contacts: [{ existence: 'IMPOSED' }, { existence: 'SEPARATED' }] };
  record('deepGet_dot', deepGet(o, 'a.b.0.c') === 42 ? 'PASS' : 'FAIL');
  record('deepGet_brackets', deepGet(o, 'contacts[1].existence') === 'SEPARATED' ? 'PASS' : 'FAIL');
  record('deepGet_none', deepGet(o, 'x.y.z') === undefined ? 'PASS' : 'FAIL');
}

function testPath() {
  const proto = { verdict: { geometry: 'PASSED' }, output: { geometry: null, family: { first_stop: { value: 5 } } } };
  record('path_ok', applyExpect(proto, { path: 'verdict.geometry', in: ['PASSED'] }).length === 0 ? 'PASS' : 'FAIL');
  record('path_mismatch', applyExpect(proto, { path: 'verdict.geometry', in: ['FORBIDDEN'] }).length > 0 ? 'PASS' : 'FAIL');
  record('path_null', applyExpect(proto, { path: 'output.geometry', in: [null] }).length === 0 ? 'PASS' : 'FAIL');
  record('path_nested', applyExpect(proto, { path: 'output.family.first_stop.value', in: [5] }).length === 0 ? 'PASS' : 'FAIL');
}

function testContacts() {
  const proto = { contacts: [
    { pair: ['H1', 'H2'], existence: 'IMPOSED', basis: { rule: 'П-8г' }, gap: [0, 0] },
    { pair: ['H2', 'H3'], existence: 'SEPARATED', gap: [2.47, 2.48] },
    { pair: ['T1', 'H1'], existence: 'PENETRATION', gap: [-1.1, -1.0] }
  ] };
  record('contacts_pos', applyExpect(proto, { kind: 'contacts', pairs: [['H1','H2']], field: 'existence', value: 'IMPOSED' }).length === 0 ? 'PASS' : 'FAIL');
  record('contacts_neg', applyExpect(proto, { kind: 'contacts', pairs: [['H1','H2']], field: 'existence', value: 'SEPARATED' }).length > 0 ? 'PASS' : 'FAIL');
  record('contacts_basis', applyExpect(proto, { kind: 'contacts', pairs: [['H1','H2']], field: 'basis.rule', value: 'П-8г' }).length === 0 ? 'PASS' : 'FAIL');
  record('contacts_swap', applyExpect(proto, { kind: 'contacts', pairs: [['H2','H1']], field: 'existence', value: 'IMPOSED' }).length === 0 ? 'PASS' : 'FAIL');
  record('contacts_missing', applyExpect(proto, { kind: 'contacts', pairs: [['X','Y']], field: 'existence', value: 'IMPOSED' }).length > 0 ? 'PASS' : 'FAIL');
}

function testJ5Edges() {
  const proto = { j5: { edges: [
    { pair: ['T1', 'T2'], cls: 'LINK', sign: 1 },
    { pair: ['H1', 'H2'], cls: 'CONTACT-ONLY', sign: -1 }
  ] } };
  record('j5edges_pos', applyExpect(proto, { kind: 'j5_edges', pairs: [['T1','T2']], field: 'cls', value: 'LINK' }).length === 0 ? 'PASS' : 'FAIL');
  record('j5edges_neg', applyExpect(proto, { kind: 'j5_edges', pairs: [['H1','H2']], field: 'cls', value: 'LINK' }).length > 0 ? 'PASS' : 'FAIL');
  record('j5edges_missing', applyExpect(proto, { kind: 'j5_edges', pairs: [['X','Y']], field: 'cls', value: 'LINK' }).length > 0 ? 'PASS' : 'FAIL');
}

function testChecks() {
  const proto = { checks: [
    { req: 'R-3', objects: ['RH1','RH2'], completeness: 'EXACT', verdict: 'PASSED', plane_relation_basis: { rule: 'П-9б' } },
    { req: 'R-6', objects: ['Q1','Q2','Q3'], contact_class: 'DEGENERATE MEETING', verdict: 'UNRESOLVED' }
  ] };
  record('checks_R3_pos', applyExpect(proto, { kind: 'checks', req: 'R-3', objects_list: [['RH1','RH2']], field: 'completeness', value: 'EXACT' }).length === 0 ? 'PASS' : 'FAIL');
  record('checks_R3_rule', applyExpect(proto, { kind: 'checks', req: 'R-3', objects_list: [['RH1','RH2']], field: 'plane_relation_basis.rule', value: 'П-9б' }).length === 0 ? 'PASS' : 'FAIL');
  record('checks_swap', applyExpect(proto, { kind: 'checks', req: 'R-3', objects_list: [['RH2','RH1']], field: 'completeness', value: 'EXACT' }).length === 0 ? 'PASS' : 'FAIL');
  record('checks_R6_pos', applyExpect(proto, { kind: 'checks', req: 'R-6', objects_list: [['Q1','Q2','Q3']], field: 'contact_class', value: 'DEGENERATE MEETING' }).length === 0 ? 'PASS' : 'FAIL');
  record('checks_missing', applyExpect(proto, { kind: 'checks', req: 'R-5', objects_list: [['Q1','Q2']], field: 'verdict', value: 'UNRESOLVED' }).length > 0 ? 'PASS' : 'FAIL');
}

function testCheckNum() {
  const proto = { contacts: [
    { pair: ['H1','H2'], gap: [0, 0] },
    { pair: ['H1','H3'], gap: [2.47, 2.48] }
  ] };
  record('num_contains_pos', checkNum(proto, [{ id: 'g', extract: { k: 'contact', pair: ['H1','H2'], f: 'gap' }, op: 'contains', v: 0, tol: 1e-9 }]).length === 0 ? 'PASS' : 'FAIL');
  record('num_contains_neg', checkNum(proto, [{ id: 'g', extract: { k: 'contact', pair: ['H1','H2'], f: 'gap' }, op: 'contains', v: 5, tol: 1e-9 }]).length > 0 ? 'PASS' : 'FAIL');
  record('num_value_contains_pos', checkNum(proto, [{ id: 'g', extract: { k: 'contact', pair: ['H1','H3'], f: 'gap' }, op: 'value_contains', v: 2.472135955, tol: 1e-6 }]).length === 0 ? 'PASS' : 'FAIL');
  record('num_value_contains_neg', checkNum(proto, [{ id: 'g', extract: { k: 'contact', pair: ['H1','H3'], f: 'gap' }, op: 'value_contains', v: 3.0, tol: 1e-6 }]).length > 0 ? 'PASS' : 'FAIL');
  record('num_missing', checkNum(proto, [{ id: 'g', extract: { k: 'contact', pair: ['X','Y'], f: 'gap' }, op: 'contains', v: 0, tol: 1e-9 }]).length > 0 ? 'PASS' : 'FAIL');
}

function testOpsCoverage() {
  record('op_cho_pos', checkNum({contacts:[{pair:['A','B'],gap:[0.9995,1.0005]}]}, [{id:'x',extract:{k:'contact',pair:['A','B'],f:'gap'},op:'contains_half_open',v:1,tol:0.001}]).length === 0 ? 'PASS' : 'FAIL');
  record('op_cho_neg', checkNum({contacts:[{pair:['A','B'],gap:[0.9995,1.001]}]}, [{id:'x',extract:{k:'contact',pair:['A','B'],f:'gap'},op:'contains_half_open',v:1,tol:0.001}]).length > 0 ? 'PASS' : 'FAIL');
  record('op_le_pos', checkNum({contacts:[{pair:['A','B'],gap:[3,4]}]}, [{id:'x',extract:{k:'contact',pair:['A','B'],f:'gap'},op:'le',v:5}]).length === 0 ? 'PASS' : 'FAIL');
  record('op_le_neg', checkNum({contacts:[{pair:['A','B'],gap:[3,6]}]}, [{id:'x',extract:{k:'contact',pair:['A','B'],f:'gap'},op:'le',v:5}]).length > 0 ? 'PASS' : 'FAIL');
  record('op_lwm_pos', checkNum({contacts:[{pair:['A','B'],gap:[3,5.05]}]}, [{id:'x',extract:{k:'contact',pair:['A','B'],f:'gap'},op:'le_with_margin',v:5,tol:0.1}]).length === 0 ? 'PASS' : 'FAIL');
  record('op_lwm_neg', checkNum({contacts:[{pair:['A','B'],gap:[3,5.05]}]}, [{id:'x',extract:{k:'contact',pair:['A','B'],f:'gap'},op:'le_with_margin',v:5,tol:0.01}]).length > 0 ? 'PASS' : 'FAIL');
}

function testSV() {
  const bad = {
    checks: [{ id:'x', req:'G-4', objects:[], quantity:'gap', value:[-0.001,0.001], completeness:'SAMPLED', verdict:'PASSED', where:null, level:'L2', layer:'CARRIER' }],
    configuration: { rings: [] }, verdict: { geometry: 'PASSED' }
  };
  const errs = SV.validate(bad);
  record('sv_PASSED_with_SAMPLED', errs.some(e => e.indexOf('SAMPLED') >= 0) ? 'PASS' : 'FAIL', errs);

  const ringNoWidths = {
    checks: [],
    configuration: { rings: [{ name: 'R0', source: 'construction', C:[[0,0],[0,0],[0,0]], E1:[[1,1],[0,0],[0,0]], E2:[[0,0],[1,1],[0,0]], s1:[0.5,0.5], s2:[0.5,0.5] }] },
    verdict: { geometry: 'PASSED' }
  };
  const errs2 = SV.validate(ringNoWidths);
  record('sv_ring_missing_widths', errs2.some(e => e.indexOf('widths') >= 0) ? 'PASS' : 'FAIL', errs2);

  const forkBad = {
    checks: [{ id:'x', req:'G-4', objects:[], quantity:'gap', value:[0.5,0.1], completeness:'CERTIFIED', verdict:'PASSED', where:null, level:'L2', layer:'CARRIER' }],
    configuration: { rings: [] }, verdict: { geometry: 'PASSED' }
  };
  const errs3 = SV.validate(forkBad);
  record('sv_lo_gt_hi', errs3.some(e => e.indexOf('lo > hi') >= 0) ? 'PASS' : 'FAIL', errs3);
}

function testCV() {
  const ok = CV.check({ checks: [{verdict:'PASSED'},{verdict:'PASSED'}], verdict: { geometry: 'PASSED' } });
  record('cv_all_passed_ok', ok.length === 0 ? 'PASS' : 'FAIL', ok);
  const bad = CV.check({ checks: [{verdict:'PASSED'},{verdict:'FORBIDDEN'}], verdict: { geometry: 'PASSED' } });
  record('cv_one_forbidden_flagged', bad.length > 0 ? 'PASS' : 'FAIL', bad);
  const unsolved = CV.check({ checks: [{verdict:'PASSED'},{verdict:'UNRESOLVED'}], verdict: { geometry: 'PASSED' } });
  record('cv_unsolved_flagged', unsolved.length > 0 ? 'PASS' : 'FAIL', unsolved);
  const badC = CV.check({ checks: [{verdict:'UNRESOLVED'},{verdict:'UNRESOLVED'}], verdict: { geometry: 'UNRESOLVED' } });
  record('cv_all_unsolved_ok', badC.length === 0 ? 'PASS' : 'FAIL', badC);
}

function main() {
  testDeepGet(); testPath(); testContacts(); testJ5Edges(); testChecks(); testCheckNum();
  testOpsCoverage();
  testSV(); testCV();
  fs.writeFileSync(path.join(OUT, 'd6_selftest.json'),
    JSON.stringify({ results, run_date: new Date().toISOString() }, null, 2));
  const passed = results.filter(r => r.status === 'PASS').length;
  const failed = results.filter(r => r.status === 'FAIL').length;
  console.log(`d6_selftest: ${results.length}; PASS=${passed} FAIL=${failed}`);
  process.exit(failed > 0 ? 1 : 0);
}
main();
