'use strict';
const { I } = require('./lib/ia');
const { V } = require('./lib/vec');
const { gapTorusTorus } = require('./lib/geom');
const { hangDirection, rodrigues } = require('./lib/frame');

const A_T1 = V.of([0, 0, 2]);          // torus T1 at (0,0,2), axis +ŷ
const A_T2 = V.of([0, 0, 4]);          // torus T2 at (0,0,4), axis +ŷ
const Y_HAT = V.of([0, 1, 0]);
const X_HAT = V.of([1, 0, 0]);
const Z_HAT = V.of([0, 0, 1]);

// Frame at T2 (host): e_x = x̂, e_y = ŷ, e_z = ẑ (direct thread, all mirror links)
const EX = X_HAT, EY = Y_HAT, EZ = Z_HAT;

const PSI = 56 * Math.PI / 180;
const DELTA = 10 * Math.PI / 180;
const SIDE = 1;

function direction(rho_I) {
  return hangDirection(rho_I, PSI, EX, EY, EZ, SIDE);
}

function buildH1(rho_I, d_I) {
  const e = direction(rho_I);
  const n_raw = e.cross(Y_HAT);
  let n;
  try {
    n = n_raw.unit();
  } catch (err) {
    throw new Error('n degenerate at ρ=' + (rho_I.mid()*180/Math.PI));
  }
  const T_H1 = rodrigues(Y_HAT, n, DELTA);
  const A_H1 = A_T2.add(e.scale(d_I));
  return { A_H1, T_H1, e };
}

// Solve d_H1(ρ) as the root of gap(H1 at A2 + d·e, T_H1, T2) = 0
function solveD(rho_I) {
  let dLo = 0.5, dHi = 3.0;
  const g_lo_box = evaluateGapH1T2(rho_I, dLo);
  const g_hi_box = evaluateGapH1T2(rho_I, dHi);
  if (!(g_lo_box.isNeg())) return { lo: dLo, hi: dLo + 0.01, uncertain: true };
  if (!(g_hi_box.isPos())) return { lo: dHi - 0.01, hi: dHi, uncertain: true };
  for (let iter = 0; iter < 40 && (dHi - dLo) > 1e-6; iter++) {
    const dMid = (dLo + dHi) / 2;
    const g = evaluateGapH1T2(rho_I, dMid);
    if (g.isPos()) dHi = dMid;
    else if (g.isNeg()) dLo = dMid;
    else {
      dLo = dMid - 1e-4; dHi = dMid + 1e-4; break;
    }
  }
  return { lo: dLo, hi: dHi, uncertain: false };
}

function evaluateGapH1T2(rho_I, d_mid) {
  const d_I = I.of(d_mid);
  const { A_H1, T_H1 } = buildH1(rho_I, d_I);
  return gapTorusTorus(A_H1, T_H1, A_T2, Y_HAT, 180, 1.0);
}

function gapH1T1(rho_I) {
  const d = solveD(rho_I);
  if (d.uncertain) {
    return { gap: new I(-1, 1), d, uncertain: true };
  }
  const d_I = new I(d.lo, d.hi);
  const { A_H1, T_H1 } = buildH1(rho_I, d_I);
  const gap = gapTorusTorus(A_H1, T_H1, A_T1, Y_HAT, 360, 1.0);
  return { gap, d, uncertain: false };
}

function check1_root() {
  const rhoMin = 45 * Math.PI / 180;
  const rhoMax = 65 * Math.PI / 180;
  const N = 80;  // 80 intervals → 0.25° spacing
  const grid = [];
  for (let j = 0; j <= N; j++) {
    const rhoDeg = 45 + j * (65 - 45) / N;
    const rho = new I(rhoDeg * Math.PI / 180, rhoDeg * Math.PI / 180);
    const { gap, d, uncertain } = gapH1T1(rho);
    const sign = uncertain ? '?' : (gap.isPos() ? '+' : (gap.isNeg() ? '-' : '?'));
    grid.push({ rho_deg: rhoDeg, gap_lo: gap.lo, gap_hi: gap.hi, d_lo: d.lo, d_hi: d.hi, sign, uncertain });
  }
  // Find sign changes
  const changes = [];
  for (let j = 0; j < N; j++) {
    const a = grid[j], b = grid[j+1];
    if (a.sign === '+' && b.sign === '-') changes.push({ rho_a_deg: a.rho_deg, rho_b_deg: b.rho_deg, dir: '+-' });
    else if (a.sign === '-' && b.sign === '+') changes.push({ rho_a_deg: a.rho_deg, rho_b_deg: b.rho_deg, dir: '-+' });
  }
  // W = single interval spanning all sign changes (if exactly one change, else null)
  let W = null;
  let existence = 'undetermined';
  let uniqueness = 'unknown';
  if (changes.length === 1) {
    W = [changes[0].rho_a_deg, changes[0].rho_b_deg];
    existence = 'yes';
    uniqueness = 'practical_one_change';
  } else if (changes.length === 0) {
    existence = 'no';
    uniqueness = 'no_change';
  } else {
    existence = 'undetermined';
    uniqueness = 'multiple_sign_changes';
  }
  return {
    check: 'check1_root',
    config: { psi_deg: 56, delta_deg: 10, with: 'T1', side: 1 },
    rho_bracket_deg: [45, 65],
    grid_points: N + 1,
    grid_step_deg: 20 / N,
    grid: grid,
    sign_changes: changes,
    W_deg: W,
    existence,
    uniqueness,
    notes: 'Existence via IVT on gap_H1_T1(ρ) = 0; uniqueness is practical (one sign change on grid), not formal Lipschitz on ρ. sin/cos via Math.* with field 1e-12; not a strict libm bound — practical envelope.'
  };
}

module.exports = { check1_root };
