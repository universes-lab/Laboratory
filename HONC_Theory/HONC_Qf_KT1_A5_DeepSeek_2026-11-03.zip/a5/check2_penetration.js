'use strict';
const { I } = require('./lib/ia');
const { V } = require('./lib/vec');
const { distPointToMidCircle } = require('./lib/geom');
const { hangDirection, rodrigues } = require('./lib/frame');

const A_T2 = V.of([0, 0, 4]);
const Y_HAT = V.of([0, 1, 0]);
const EX = V.of([1, 0, 0]), EY = Y_HAT, EZ = V.of([0, 0, 1]);
const PSI = 56 * Math.PI / 180;
const DELTA = 10 * Math.PI / 180;
const SIDE = 1;

function buildH1(rho_I, d_I) {
  const e = hangDirection(rho_I, PSI, EX, EY, EZ, SIDE);
  const n = e.cross(Y_HAT).unit();
  const T_H1 = rodrigues(Y_HAT, n, DELTA);
  const A_H1 = A_T2.add(e.scale(d_I));
  return { A_H1, T_H1 };
}

// For fixed theta, check dist(R1(theta), midCircle_H1) − 0.5 over rho ∈ W
// R1 = circle of radius 1 in plane x=0, center (0,0,3), point (0, sin θ, 3 − cos θ)
function checkTheta(theta, W_deg, N_rho, d_table) {
  const px = 0, py = Math.sin(theta), pz = 3 - Math.cos(theta);
  const P = V.of([px, py, pz]);
  let distMax = -Infinity; // max over rho grid of upper dist
  let distMin = Infinity;
  for (let j = 0; j <= N_rho; j++) {
    const rhoDeg = W_deg[0] + j * (W_deg[1] - W_deg[0]) / N_rho;
    const rho = new I(rhoDeg * Math.PI / 180, rhoDeg * Math.PI / 180);
    // interpolate d from table
    const t = j / N_rho;
    const dMid = d_table[0] + t * (d_table[1] - d_table[0]);
    const d_I = new I(dMid - d_table[2], dMid + d_table[2]);
    let H;
    try {
      H = buildH1(rho, d_I);
    } catch (e) { continue; }
    const dist = distPointToMidCircle(P, H.A_H1, H.T_H1);
    if (dist.hi > distMax) distMax = dist.hi;
    if (dist.lo < distMin) distMin = dist.lo;
  }
  return { distMax, distMin, body_bound: 0.5 };
}

function check2_penetration(W_deg, d_lo, d_hi) {
  if (!W_deg) {
    return {
      check: 'check2_penetration',
      found: false,
      error: 'no_W_from_check1',
      notes: 'Cannot run: check1 returned no single-interval W.'
    };
  }
  const N_theta = 720;
  const N_rho = 50;
  // Use d interval from check1 as [d_lo, d_hi] with ±0.01 padding
  const pad = 0.01;
  const d_table = [(d_lo + d_hi) / 2, (d_lo + d_hi) / 2, (d_hi - d_lo) / 2 + pad];
  const thetaGrid = [];
  let bestFound = null;
  for (let j = 0; j < N_theta; j++) {
    const thetaDeg = j * 360 / N_theta;
    const theta = thetaDeg * Math.PI / 180;
    const r = checkTheta(theta, W_deg, N_rho, d_table);
    if (r.distMax < 0.5) {
      if (!bestFound || r.distMax < bestFound.distMax) {
        bestFound = { theta_deg: thetaDeg, distMax: r.distMax, distMin: r.distMin };
      }
    }
  }
  const found = !!bestFound;
  return {
    check: 'check2_penetration',
    config: { psi_deg: 56, delta_deg: 10, side: 1 },
    W_deg: W_deg,
    theta_grid_points: N_theta,
    rho_grid_points: N_rho + 1,
    found,
    theta_deg: found ? bestFound.theta_deg : null,
    dist_H1_body_hi: found ? bestFound.distMax : null,
    body_bound: 0.5,
    coverage: found
      ? 'PARTIAL — W is a union of undetermined boxes; uniqueness of the root is not proven. Penetration shown for all sampled roots ρ ∈ W and all θ in a 720-point grid.'
      : 'NOT_FOUND — no θ in the grid gave strict penetration for all ρ ∈ W.',
    notes: 'If found=true: point on R1 is strictly inside H1 body (dist to mid circle < 0.5). Per Integrator 03.11: PARTIAL coverage without proven uniqueness.'
  };
}

module.exports = { check2_penetration };
