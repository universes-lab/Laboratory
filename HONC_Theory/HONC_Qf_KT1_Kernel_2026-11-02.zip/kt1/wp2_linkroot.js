'use strict';
// HONC / Qf / R1 / КТ-1 — корни, опирающиеся на G-4:
//  • G-3, незеркальное звено: расстояние d — корень g(d) = 0, где g — зазор G-4 между тором-хозяином и тором,
//    центр которого A + d·e, ось TH (поворот зеркальной оси на δ). Интерфейс v6, § 2.
//  • Уравнение касания (fix, интерфейс v6, § 4.2): свободный параметр навеса p — корень F(p) = 0,
//    F — зазор G-4 между тором `with` и навесом, построенным при этом p.
// Обоснования — WP2_Roots_Notes.md. Кратко:
//  1) На d > 2 корней нет: тела лежат в полупространствах x·e <= h1(e) <= 1 и x·e >= d − h2(−e) >= d − 1,
//     зазор не меньше d − 2 > 0 (опорная функция рогатого тора не больше 1).
//  2) На [0, 2 + √½] — процедура WP-0 `root`: куски без корня (вилка g без 0) и монотонные куски (вилка ∂g/∂d без 0).
//  3) Вилка ∂g/∂d на ящике d × p: g = min_φ G(φ, d, p). Для d1 < d2 с точкой минимума φ2 при d2:
//     g(d2) − g(d1) >= G(φ2, d2) − G(φ2, d1) = (d2 − d1)·∂G/∂d(φ2, ξ), и симметрично сверху через φ1.
//     φ1, φ2 лежат в вилках точек минимума G-4 на всём ящике (WP-0, § 6), поэтому разностные отношения g
//     лежат в вилке ∂G/∂d по (вилки точек минимума) × ящик. Та же оценка даёт шаг интервального Ньютона.
//  4) Неявная производная d(p): из g(d(p), p) = 0 тем же доводом разностные отношения d лежат в вилке −G_p/G_d.
//  5) F(p) = min_φ G1(φ, d(p), p): разностные отношения F лежат в вилке ∂G1/∂d·K + ∂G1/∂p, K — вилка из (4).
const iv = require('./wp0_interval');
const vec = require('./wp1_vec');
const D = require('./wp1_dual');
const { torusGap, perpBasis } = require('./wp2_gap');
const { root } = require('./wp0_cert');

const HALF = iv.I(0.5);
const NV = 2; // слоты производных: 0 — по d, 1 — по свободному параметру p
// Нижняя достижимая ширина вилки зазора G-4 в точке — около 2·10⁻¹⁴ (WP-0: округление наружу в цепочке расстояния).
// Допуск точечных вычислений берётся чуть выше, иначе ветви и границы не сходятся.
const TOL_POINT = 3e-14;
// Правый конец отрезка поиска d. Корней при d > 2 нет (довод 1), поэтому отрезок берётся с запасом, а конец —
// не двоичный: точки деления в WP-0 root — b·k/2^j, и корень, совпавший с точкой деления (например, d = 2 у
// тождества), сделал бы знак на конце куска неопределённым.
const D_SEARCH = 2 + Math.SQRT1_2;
// Предел вычислений на один вызов G-4. Исчерпание не портит верность: вилка лишь шире (WP-0, § 6).
const MAX_EVAL = 5000;
// Допуск G-4 на ящике (d × p), когда нужны вилки точек минимума (доводы Д-2…Д-6). Он близок к «полу» — ширине
// вилки f(m) на ящике (зазор 1-липшицев по d и меняется не быстрее ~3·|Δp| по p). При большом допуске перебор
// останавливается рано, и в вилки точек минимума попадают крупные необработанные отрезки — вплоть до половины
// окружности. При допуске ниже пола перебор кончается сам: отрезки исчерпываются (WP-0, § 6).
const tolArg = (Dw, Pw) => TOL_POINT + Dw + 3 * Pw;

// Вилки частных производных G(φ, d, p) = dist(точка средней окружности тора `fixed` при φ, окружность подвижного тора) − 1
// по d и p — объединение по отрезкам φ из `phis`. geo(P) даёт дуальные e и TH (переменная 1 — p).
function gPartials(fixed, phis, Dint, geoDual) {
  const { e1, e2 } = perpBasis(fixed.T);
  const dd = D.X(Dint, 0, NV);
  const c = D.vadd(D.vlift(fixed.Ahost || fixed.A, NV), D.vscale(geoDual.e, dd));
  let gd = null, gp = null;
  for (const [l, r] of phis) {
    const P = [l, r], s = iv.sin(P), co = iv.cos(P);
    const p = vec.vadd(fixed.A, vec.vscale(vec.vadd(vec.vscale(e1, co), vec.vscale(e2, s)), HALF));
    const rv = D.vsub(D.vlift(p, NV), c);
    const z = D.dot(rv, geoDual.TH);
    const rp = D.vsub(rv, D.vscale(geoDual.TH, z));
    const rho = D.sqrt(D.dot(rp, rp));
    const t = D.sub(rho, D.C(HALF, NV));
    const dist = D.sqrt(D.add(D.sqr(t), D.sqr(z)));
    gd = gd ? iv.hull(gd, dist.g[0]) : dist.g[0];
    gp = gp ? iv.hull(gp, dist.g[1]) : dist.g[1];
  }
  const fin = a => (a && Number.isFinite(a[0]) && Number.isFinite(a[1]) ? a : [-Infinity, Infinity]);
  return { gd: fin(gd), gp: fin(gp) };
}

// Геометрия подвижного тора: спецификация звена.
//  host: { A, T } — хозяин (вилки);
//  geo(Pint) -> { e, TH } — вилки направления и оси при вилке параметра;
//  geoDual(Pint) -> { e, TH } — дуальные (производные по p в слоте 1);
//  если параметра нет, P = [0, 0] и производные по p — нули.
const moverAt = (host, g, Dint) => ({ A: vec.vadd(host.A, vec.vscale(g.e, Dint)), T: g.TH });

// Окно корня d для ящика параметра p: вне окна вилка зазора не содержит 0 ни при каком p из ящика.
// Строится делением отрезка start (по умолчанию [0, 2 + √½]; на d > 2 корней нет, довод 1). Если ящик p вложен
// в ящик, для которого окно уже построено, start — это окно: вне его корней нет и для вложенного ящика.
// Несколько областей — отказ. maxEval ограничивает G-4 на широких ящиках: вилки тогда шире, но верны.
function dWindow(host, spec, Pint, { start = [0, D_SEARCH], wmin = 1e-3, maxEval = MAX_EVAL } = {}) {
  const Pw = Pint[1] - Pint[0];
  const g = spec.geo(Pint);
  const und = [], stack = [start];
  let steps = 0;
  while (stack.length) {
    const [l, r] = stack.pop();
    if (++steps > 4000) return { ok: false, reason: 'G-3: окно корня d не выделено — исчерпан предел шагов' };
    const res = torusGap(host, moverAt(host, g, [l, r]), { tol: TOL_POINT + 4 * (r - l) + 8 * Pw, maxEval });
    if (res.gap[0] > 0 || res.gap[1] < 0) continue;
    if (r - l <= wmin) { und.push([l, r]); continue; }
    const m = l + (r - l) / 2;
    stack.push([m, r], [l, m]);
  }
  if (!und.length) return { ok: false, reason: 'G-3: корня d нет при этих параметрах' };
  und.sort((a, b) => a[0] - b[0]);
  const W = [und[0][0], und[0][1]];
  for (const x of und.slice(1)) { if (x[0] <= W[1]) W[1] = Math.max(W[1], x[1]); else return { ok: false, reason: 'G-3: больше одной области возможных корней d' }; }
  return { ok: true, W };
}

// G-3 незеркальное: корень d с доказательством единственности; затем сужение интервальным Ньютоном.
//  без opts — поиск на [0, 2 + √½] (довод 1 исключает d > 2);
//  opts.window — окно из dWindow для объемлющего ящика p: вне окна корней нет, единственность доказывается в окне;
//  opts.within — вилка, где единственность уже доказана для объемлющего ящика (довод наследуется).
function linkDistance(host, spec, Pint = [0, 0], opts = {}) {
  const Pw = Pint[1] - Pint[0];
  const g = spec.geo(Pint), gD = spec.geoDual(Pint);
  const memo = new Map();
  const gapBox = (l, r, tolPoint = TOL_POINT) => {
    const key = l + ',' + r;
    if (memo.has(key)) return memo.get(key);
    const tol = tolPoint - TOL_POINT + tolArg(r - l, Pw);
    const res = torusGap(host, moverAt(host, g, [l, r]), { tol, maxEval: MAX_EVAL });
    memo.set(key, res);
    return res;
  };
  let Dk, proof;
  if (opts.within) { Dk = opts.within; proof = opts.withinProof; }
  else if (opts.window && (() => {
    // Прямая проверка на всём окне: знаки на концах и вилка ∂g/∂d > 0 на (точки минимума) × окно × ящик p.
    // Тогда при каждом p из ящика g строго растёт на окне и меняет знак — корень в окне один; вне окна корней нет.
    const W = opts.window;
    const gl = gapBox(W[0], W[0]).gap, gr = gapBox(W[1], W[1]).gap;
    const gd = gPartials(host, gapBox(W[0], W[1]).argmin, W, gD).gd;
    if (gl[1] < 0 && gr[0] > 0 && gd[0] > 0) { Dk = W; return true; }
    return false;
  })()) {
    proof = 'корень g(d) = 0 единствен на [0, ∞) при каждом p ящика: при d > 2 зазор >= d − 2 > 0; вне окна d вилка g без 0; на окне g меняет знак и вилка ∂g/∂d > 0 (по вилкам точек минимума G-4)';
  } else {
    const F = (l, r) => gapBox(l, r).gap;
    const dF = (l, r) => gPartials(host, gapBox(l, r).argmin, [l, r], gD).gd;
    const [a, b] = opts.window || [0, D_SEARCH];
    const rr = root({ F, dF, a, b, tol: 1e-3, maxDepth: opts.window || Pw > 0 ? 10 : 24 });
    if (!rr.unique) return { ok: false, reason: `G-3: ${rr.reason || 'единственность не доказана'}` };
    Dk = rr.root;
    proof = opts.window
      ? 'корень g(d) = 0 единствен на [0, ∞): при d > 2 зазор >= d − 2 > 0; вне окна d вилка g без 0 на всём ящике p; в окне — WP-0 root: вилка ∂g/∂d без 0 (по вилкам точек минимума G-4)'
      : 'корень g(d) = 0 единствен на [0, ∞): при d > 2 зазор >= d − 2 > 0 (опорные полупространства); на [0, 2 + √½] — WP-0 root: вне куска вилка g без 0, на куске вилка ∂g/∂d без 0 (по вилкам точек минимума G-4)';
  }
  // Интервальный Ньютон: d* ∈ m − g(m)/[∂G/∂d на (вилки точек минимума) × Dk × P] (довод 3 в шапке).
  for (let k = 0; k < 60; k++) {
    const w0 = Dk[1] - Dk[0];
    if (w0 <= 1e-15 * 2) break;
    const m = iv.mid(Dk);
    const gm = torusGap(host, moverAt(host, g, [m, m]), { tol: TOL_POINT + 8 * Pw, maxEval: MAX_EVAL }).gap;
    const box = gapBox(Dk[0], Dk[1]);
    const gd = gPartials(host, box.argmin, Dk, gD).gd;
    if (!(gd[0] > 0)) break;
    const N = iv.sub(iv.I(m), iv.div(gm, gd));
    const Dn = iv.intersect(Dk, N);
    if (!Dn) return { ok: false, reason: 'G-3: шаг Ньютона пуст — противоречие доказательству (ошибка ядра)', kernelError: true };
    if (Dn[1] - Dn[0] >= 0.9 * w0) { Dk = Dn; break; }
    Dk = Dn;
  }
  return { ok: true, d: Dk, proof, method: 'Ньютон на вилке ∂G/∂d' };
}

// Неявная производная d(p) на ящике: вилка K, содержащая все разностные отношения d (довод 4).
function implicitK(host, spec, Pint, Dint) {
  const g = spec.geo(Pint), gD = spec.geoDual(Pint);
  const Pw = Pint[1] - Pint[0];
  const res = torusGap(host, moverAt(host, g, Dint), { tol: tolArg(Dint[1] - Dint[0], Pw), maxEval: MAX_EVAL });
  const { gd, gp } = gPartials(host, res.argmin, Dint, gD);
  if (!(gd[0] > 0)) return [-Infinity, Infinity];
  return iv.neg(iv.div(gp, gd));
}

// Уравнение касания: F(p) = зазор(with, навес(p)). spec — как выше; kind: 'identity' | 'mirror' | 'general'.
// Возвращает вилку корня p (радианы), d на ней и основание.
// Ширина ящика p, начиная с которой считается и производная F (довод единственности). Шире — только вилка F
// для исключения кусков без корня: вилки на широких ящиках сильно раздуты и доказательству не помогают.
const P_FINE = 1e-3;
function solveContact({ host, withT, spec, kind, bracket, tol = 1e-13 }) {
  const windows = [];  // { P, W } — окна корня d (вне окна корней d нет при всех p ящика)
  const proven = [];   // { P, D, proof } — ящики, где единственность d доказана
  const inside = (x, P) => x.P[0] <= P[0] && P[1] <= x.P[1];
  function windowFor(P) {
    let best = null;
    for (const x of windows) if (inside(x, P) && (!best || x.W[1] - x.W[0] < best.W[1] - best.W[0])) best = x;
    const wide = P[1] - P[0] > P_FINE;
    const w = dWindow(host, spec, P, { start: best ? best.W : [0, D_SEARCH], maxEval: wide ? 400 : MAX_EVAL, wmin: wide ? 1e-2 : 1e-3 });
    if (w.ok) windows.push({ P, W: w.W });
    return w;
  }
  function dOn(P) {
    if (kind === 'identity') return { ok: true, d: iv.I(2), K: iv.I(0), proof: 'тождество П-5: d = 2' };
    if (kind === 'mirror') {
      const gD = spec.geoDual(P);
      const c = D.dot(gD.e, D.vlift(host.T, NV));
      const dd = D.add(D.sqrt(D.sub(D.C(iv.I(1), NV), D.sqr(c))), D.C(iv.I(1), NV));
      return { ok: true, d: dd.v, K: dd.g[1], proof: 'закрытая форма зеркального звена' };
    }
    const cover = proven.find(x => inside(x, P));
    if (cover) {
      const r = linkDistance(host, spec, P, { within: cover.D, withinProof: cover.proof });
      if (!r.ok) return r;
      return { ok: true, d: r.d, K: implicitK(host, spec, P, r.d), proof: r.proof };
    }
    const w = windowFor(P);
    if (!w.ok) return w;
    if (P[1] - P[0] > P_FINE) return { ok: true, d: w.W, K: [-Infinity, Infinity], coarse: true };
    const r = linkDistance(host, spec, P, { window: w.W });
    if (!r.ok) return r;
    proven.push({ P, D: r.d, proof: r.proof });
    return { ok: true, d: r.d, K: implicitK(host, spec, P, r.d), proof: r.proof };
  }
  const memo = new Map();
  const T0 = Date.now();
  function evalF(l, r) {
    const key = l + ',' + r;
    if (memo.has(key)) return memo.get(key);
    const P = [l, r];
    const dr = dOn(P);
    let out;
    if (!dr.ok) out = { F: [-Infinity, Infinity], dF: [-Infinity, Infinity], fail: dr.reason };
    else {
      const g = spec.geo(P), gD = spec.geoDual(P);
      const hang = moverAt(host, g, dr.d);   // при грубом ящике d — окно: вилка F покрывает все корни d
      const res = torusGap(withT, hang, { tol: dr.coarse ? TOL_POINT + 4 * (dr.d[1] - dr.d[0]) + 8 * (r - l) : tolArg(dr.d[1] - dr.d[0], r - l), maxEval: dr.coarse ? 400 : MAX_EVAL });
      let dF = [-Infinity, Infinity];
      if (!dr.coarse) {
        // ∂G1/∂d и ∂G1/∂p при неподвижном торе `with`; подвижный — навес (центр host.A + d·e(p), ось TH(p)).
        const pt = gPartials({ A: withT.A, T: withT.T, Ahost: host.A }, res.argmin, dr.d, gD);
        const v = iv.add(iv.mul(pt.gd, dr.K), pt.gp);
        if (Number.isFinite(v[0]) && Number.isFinite(v[1])) dF = v;
      }
      out = { F: res.gap, dF, d: dr.d };
    }
    memo.set(key, out);
    return out;
  }
  const rr = root({ F: (l, r) => evalF(l, r).F, dF: (l, r) => evalF(l, r).dF, a: bracket[0], b: bracket[1], tol, maxDepth: 30 });
  if (!rr.exists || !rr.unique) return { ok: false, reason: `уравнение касания: ${rr.reason}` };
  const fin = dOn(rr.root);
  if (!fin.ok || fin.coarse) return { ok: false, reason: fin.reason || 'уравнение касания: d на вилке корня не доказан' };
  // Форма среднего значения (довод Д-5): d(p) ∈ d(m) + K·(p − m) при p из вилки корня. Вилка d тогда наследует
  // не ширину корня, умноженную на раздутие вилочного вычисления, а лишь |K|·полуширину корня.
  let dFin = fin.d;
  if (kind !== 'identity' && Number.isFinite(fin.K[0]) && Number.isFinite(fin.K[1])) {
    const m = iv.mid(rr.root), fm = dOn([m, m]);
    if (fm.ok && !fm.coarse) {
      const mv = iv.add(fm.d, iv.mul(fin.K, iv.sub(rr.root, iv.I(m))));
      const x = iv.intersect(dFin, mv);
      if (x) dFin = x;
    }
  }
  return { ok: true, p: rr.root, d: dFin, dProof: fin.proof,
    uniqueness: 'существование — смена знака F на концах куска; единственность — WP-0 root: вне куска вилка F без 0; на куске вилка F\' без 0 — F\' = ∂G1/∂d·K + ∂G1/∂p по вилкам точек минимума G-4, K — вилка неявной производной d(p)' };
}

module.exports = { linkDistance, dWindow, solveContact, gPartials, implicitK, moverAt };
