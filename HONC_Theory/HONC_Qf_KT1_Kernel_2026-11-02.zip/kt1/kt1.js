#!/usr/bin/env node
'use strict';
// HONC / Qf / R1 / КТ-1 — консольный вход и библиотечные точки (интерфейс v6, §§ 4–8).
//   node kt1.js случай.json > протокол.json
// Коды выхода: 0 — протокол выдан; 2 — input_error; 3 — kernel_error. Прогон детерминирован.
// Обоснования сборки протокола — WP4_Contacts_Notes.md, § 6.
const fs = require('fs');
const iv = require('./wp0_interval');
const vec = require('./wp1_vec');
const C = require('./wp0_cert');
const L = require('./wp0_labels');
const B = require('./wp1_build');
const { torusGap } = require('./wp2_gap');
const RT = require('./wp2_ringtorus');
const RR = require('./wp3_rings');
const KC = require('./wp4_contacts');

const INTERFACE = 6;
const KERNEL_VERSION = 'kt1-2026-11-02-wp4';
// Правило совместимости объявленного касания утверждено к следующей версии интерфейса; в версии 6 не действует.
const DECLARE_COMPAT = INTERFACE >= 7;
const DECLARED = {
  kappa_min: RT.KAPPA_MIN, theta_min_deg: RR.THETA_MIN_DEG, n_max_candidates: KC.N_MAX_CANDIDATES,
  bnb_max_evaluations: { 'G-4': 400000, 'G-5а': 100000, 'G-5г': 100000, 'G-3 / fix': 5000 },
  root_max_iterations: { root_max_depth: 40, ring_length_bisection: 600 },
  k2_display_thresholds: KC.K2_DISPLAY,
};

class InputError extends Error {}
const isNum = x => typeof x === 'number' && Number.isFinite(x);
const vecIn = (v, ctx) => { if (!Array.isArray(v) || v.length !== 3 || !v.every(isNum)) throw new InputError(`${ctx}: нужен вектор из трёх чисел`); return v.map(iv.fromInput); };
const allInt = (...xs) => xs.flat(2).every(x => Number.isInteger(x) && Math.abs(x) < 2 ** 53);

// ---------------- § 4.3: синтетический случай ----------------
function parseSynthetic(cs) {
  if (!Array.isArray(cs.tori) || !cs.tori.length) throw new InputError('tori: нужен непустой массив');
  const names = new Set();
  const raw = new Map();
  for (const t of cs.tori) {
    if (!t || typeof t.name !== 'string' || !t.name) throw new InputError('тор: нет имени');
    if (names.has(t.name)) throw new InputError(`тор ${t.name}: имя повторяется`);
    names.add(t.name); raw.set(t.name, t);
  }
  // оси: числа (нормировка — вилка) или ссылки sameAs / oppositeOf (явное тождество, П-6)
  const axis = new Map(), cls = new Map(), basisOf = new Map();
  const resolve = (nm, stack = []) => {
    if (axis.has(nm)) return axis.get(nm);
    if (stack.includes(nm)) throw new InputError(`тор ${nm}: циклическая ссылка оси`);
    const T = raw.get(nm).T;
    let v;
    if (Array.isArray(T)) {
      const w = vecIn(T, `тор ${nm}: T`);
      if (vec.norm2(w)[1] <= 0) throw new InputError(`тор ${nm}: нулевая ось`);
      v = vec.normalize(w); cls.set(nm, nm); basisOf.set(nm, []);
    } else if (T && (typeof T.sameAs === 'string' || typeof T.oppositeOf === 'string')) {
      const ref = T.sameAs || T.oppositeOf;
      if (!raw.has(ref)) throw new InputError(`тор ${nm}: ссылка на неизвестный тор ${ref}`);
      const base = resolve(ref, [...stack, nm]);
      v = T.sameAs ? base : vec.vneg(base);
      cls.set(nm, cls.get(ref)); basisOf.set(nm, [...basisOf.get(ref), `${nm}: ${T.sameAs ? 'sameAs' : 'oppositeOf'} ${ref}`]);
    } else throw new InputError(`тор ${nm}: T — три числа или { sameAs | oppositeOf }`);
    axis.set(nm, v); return v;
  };
  const tori = cs.tori.map(t => ({ name: t.name, A: vecIn(t.A, `тор ${t.name}: A`), T: resolve(t.name), synthetic: true }));
  const rings = (cs.rings || []).map(r => {
    if (!r || typeof r.name !== 'string' || !r.name) throw new InputError('кольцо: нет имени');
    for (const k of ['s1', 's2']) if (!isNum(r[k]) || !(r[k] > 0)) throw new InputError(`кольцо ${r.name}: ${k} — положительное число`);
    const rec = { name: r.name, source: 'synthetic', owner: null, threads: Array.isArray(r.threads) ? [...r.threads] : [], free: null,
      C: vecIn(r.C, `кольцо ${r.name}: C`), E1: vecIn(r.E1, `кольцо ${r.name}: E1`), E2: vecIn(r.E2, `кольцо ${r.name}: E2`),
      s1: iv.fromInput(r.s1), s2: iv.fromInput(r.s2), annulus: false, length: null, residual: null, plane_class: null,
      completeness: allInt(r.C, r.E1, r.E2, r.s1, r.s2) ? 'EXACT' : 'CERTIFIED', basis: 'вход (§ 4.3)' };
    // ортонормированность — совместимость вилок (как и threads, § 4.3)
    const res = [iv.sub(vec.norm2(rec.E1), I1), iv.sub(vec.norm2(rec.E2), I1), vec.dot(rec.E1, rec.E2)];
    if (res.some(x => !iv.containsZero(x))) throw new InputError(`кольцо ${r.name}: E1, E2 не ортонормированы (вилка невязки отделена от 0)`);
    for (const tn of rec.threads) if (!names.has(tn)) throw new InputError(`кольцо ${r.name}: threads — нет тора ${tn}`);
    return { ...rec, ...B.ringWidths(rec) };
  });
  const declares = (cs.declare || []).map((d, k) => {
    const ctx = `declare[${k}]`;
    if (!d || !Array.isArray(d.pair) || d.pair.length !== 2 || !d.pair.every(n => names.has(n)) || d.pair[0] === d.pair[1]) throw new InputError(`${ctx}: pair — два разных известных тора`);
    if (typeof d.basis !== 'string' || !d.basis) throw new InputError(`${ctx}: нужно основание basis (текст)`);
    if (d.kind === 'symmetry') { if (d.contact !== 'IMPOSED') throw new InputError(`${ctx}: symmetry — только contact: "IMPOSED"`); }
    else if (d.kind === 'type') { if (d.type !== 'SIDE' && d.type !== 'AXIAL') throw new InputError(`${ctx}: type — SIDE или AXIAL`); }
    else throw new InputError(`${ctx}: недопустимый вид объявления ${JSON.stringify(d.kind)}`);
    return d;
  });
  const linked = (a, b) => rings.some(r => r.threads.includes(a) && r.threads.includes(b));
  const contacts = declares.filter(d => d.kind === 'symmetry').map(d => ({ pair: [...d.pair], cls: linked(...d.pair) ? 'LINK' : 'CONTACT-ONLY', existence: 'IMPOSED',
    basis: { rule: 'П-8в', declared: true, basis: d.basis } }));
  const evidence = [
    ...[...basisOf].filter(([, b]) => b.length).map(([nm, b]) => ({ rule: 'П-6', fact: `ось ${nm} по ссылке`, objects: [nm], premises: b, declared: true })),
    ...declares.map(d => ({ rule: d.kind === 'symmetry' ? 'П-8в' : 'тип по объявлению', fact: d.kind === 'symmetry' ? `касание ${d.pair.join('–')} IMPOSED` : `тип ${d.pair.join('–')} ${d.type}`, objects: d.pair, premises: [d.basis], declared: true })),
  ];
  return { tori, rings, contacts, evidence, conventions: [], declares,
    parallelEstablished: (a, b) => cls.get(a.name) === cls.get(b.name),
    parallelBasis: (a, b) => ({ rule: 'П-6', premises: ['явное тождество входа (sameAs / oppositeOf)', ...basisOf.get(a.name), ...basisOf.get(b.name)] }),
    sideByConstruction: null, synthetic: true };
}
const I1 = iv.I(1);

// ---------------- § 4.1–4.2: построение ----------------
function parseThread(cs) {
  const c = B.build(cs);
  c.parallelBasis = (a, b) => ({ rule: 'П-6', premises: [`оси ${a.name} и ${b.name} равны по цепочке тождеств П-3 / П-5 (один класс оси)`] });
  c.declares = [];
  return c;
}

// ---------------- проверки конфигурации ----------------
function constructionChecks(conf) {
  const out = [];
  for (const r of conf.rings) if (r.source === 'construction') {
    out.push(L.makeCheck({ id: `G2:${r.name}`, req: 'G-2', objects: [r.name], quantity: 'length_residual', value: r.residual, completeness: r.completeness,
      verdict: iv.containsZero(r.residual) ? 'PASSED' : 'FORBIDDEN', level: 'L2', basis: r.basis,
      reason: iv.containsZero(r.residual) ? null : `G-2: длина кольца ${r.name} не равна 2π` }));
  }
  for (const c of conf.contacts) if (c.cls === 'LINK' && c.d) {
    const exact = c.basis && /тождество/.test(c.basis.form || '');
    out.push(L.makeCheck({ id: `G3:${c.pair.join(':')}`, req: 'G-3', objects: [...c.pair], quantity: 'link_distance', value: c.d, completeness: exact ? 'EXACT' : 'CERTIFIED',
      verdict: 'PASSED', level: 'L2', basis: c.basis }));
  }
  return out;
}
// G-8 (факультативно): abs(det(T, n₁, n₂)) для колец в отверстии тора из разных плоскостей. Не проверка: в вердикт не входит.
function triples(conf) {
  const out = [];
  for (const t of conf.tori) {
    const rs = conf.rings.filter(r => (r.threads || []).includes(t.name));
    for (let i = 0; i < rs.length; i++) for (let j = i + 1; j < rs.length; j++) {
      const a = rs[i], b = rs[j];
      if (a.plane_class != null && a.plane_class === b.plane_class) continue;
      try {
        const na = vec.normalize(vec.cross(a.E1, a.E2)), nb = vec.normalize(vec.cross(b.E1, b.E2));
        out.push({ req: 'G-8', torus: t.name, rings: [a.name, b.name], quantity: 'abs_det_T_n1_n2', value: iv.abs(vec.dot(t.T, vec.cross(na, nb))), optional: true });
      } catch (e) { /* нормаль не определена — пропуск */ }
    }
  }
  return out;
}

function evaluate(conf) {
  const checks = [...constructionChecks(conf)];
  const tp = KC.torusPairs(conf, { declareCompat: DECLARE_COMPAT });
  checks.push(...tp.checks);
  for (const r of conf.rings) for (const t of conf.tori) checks.push(RT.ringTorus(r, t, (r.threads || []).includes(t.name)));
  const rr = RR.ringChecks(conf, conf.synthetic ? null : t => B.frame(t));
  checks.push(...rr.pairs, ...rr.degenerate, ...rr.threadingChecks);
  const j5 = KC.j5FromContacts(conf.tori, tp.contacts);
  return { checks, contacts: tp.contacts, j5, threading: rr.threading };
}

// ---------------- протокол ----------------
// JSON: ±∞ — конечные границы наружу (±наибольшее число): вилка остаётся верной. NaN в ядре не возникает (check).
const replacer = (k, v) => (v === Infinity ? Number.MAX_VALUE : v === -Infinity ? -Number.MAX_VALUE : v);
const serialize = p => JSON.stringify(p, replacer);
const torusOut = t => ({ name: t.name, A: t.A, T: t.T, ...(t.host ? { host: t.host } : {}), ...(t.fix ? { fix: t.fix } : {}) });
function ringOut(r) {
  const keep = ['name', 'source', 'owner', 'threads', 'free', 'C', 'E1', 'E2', 's1', 's2', 'annulus', 'length', 'residual', 'completeness', 'basis', 'widths', 'width_max', 'plane_class', 'plane_basis'];
  return Object.fromEntries(keep.filter(k => r[k] !== undefined).map(k => [k, r[k]]));
}
function protocolOf(cs, conf, res) {
  const verdict = L.configVerdict(res.checks);
  return {
    protocol: 'honc-qf-r1-kt1', interface: INTERFACE, kernel: { version: KERNEL_VERSION }, case: cs, declared: DECLARED,
    configuration: { tori: conf.tori.map(torusOut), rings: conf.rings.map(ringOut), evidence: conf.evidence, conventions: conf.conventions,
      threading: res.threading, triples: triples(conf) },
    checks: res.checks, contacts: res.contacts, j5: res.j5,
    verdict: { geometry: verdict, rule: 'spec §1' },
    unresolved: res.checks.filter(c => c.verdict === 'UNRESOLVED').map(c => ({ id: c.id, reason: c.reason })),
    registry: 'registry_S3.json',
  };
}
function errorProtocol(cs, kind, message) {
  return { protocol: 'honc-qf-r1-kt1', interface: INTERFACE, kernel: { version: KERNEL_VERSION }, case: cs, [kind]: message };
}
// Построение не удостоверено (Unresolved из WP-1): конфигурация не строится, итог UNRESOLVED с причиной (интерфейс § 4.2).
function unresolvedProtocol(cs, message) {
  const ch = L.makeCheck({ id: 'build', req: 'G-7', objects: [], quantity: 'construction', value: [0, 0], completeness: 'UNRESOLVED', verdict: 'UNRESOLVED', level: 'L1', reason: message });
  return { protocol: 'honc-qf-r1-kt1', interface: INTERFACE, kernel: { version: KERNEL_VERSION }, case: cs, declared: DECLARED,
    configuration: null, checks: [ch], contacts: [], j5: null, verdict: { geometry: 'UNRESOLVED', rule: 'spec §1' },
    unresolved: [{ id: 'build', reason: message }], registry: 'registry_S3.json' };
}

// K.run(case): протокол как объект, побитно совпадающий с выводом консоли (интерфейс § 7).
function runRaw(cs) {
  try {
    if (!cs || typeof cs !== 'object') throw new InputError('случай: не объект');
    if (cs.thread && cs.tori) throw new InputError('случай: thread (§ 4.1) и tori (§ 4.3) одновременно');
    let conf;
    if (cs.thread) conf = parseThread(cs);
    else if (cs.tori) conf = parseSynthetic(cs);
    else throw new InputError('случай: нет thread (§ 4.1) или tori (§ 4.3)');
    const res = evaluate(conf);
    const p = protocolOf(cs, conf, res);
    const v = L.validate(JSON.parse(serialize(p)));
    if (v.length) return { code: 3, p: errorProtocol(cs, 'kernel_error', `самопроверка схемы: ${v.join('; ')}`) };
    return { code: 0, p };
  } catch (e) {
    if (e instanceof InputError || e instanceof B.InputError || e instanceof RT.ThreadError || e instanceof KC.DeclareError) return { code: 2, p: errorProtocol(cs, 'input_error', e.message) };
    if (e instanceof B.Unresolved) return { code: 0, p: unresolvedProtocol(cs, e.message) };
    return { code: 3, p: errorProtocol(cs, 'kernel_error', String(e && e.message || e)) };
  }
}
const run = cs => JSON.parse(serialize(runRaw(cs).p));

// ---------------- библиотечные точки (интерфейс § 7) ----------------
const isIv = x => Array.isArray(x) && x.length === 2 && x.every(isNum);
const toIv = (x, ctx) => (isIv(x) ? x : isNum(x) ? iv.fromInput(x) : (() => { throw new InputError(`${ctx}: число или вилка`); })());
const toVec = (v, ctx) => { if (!Array.isArray(v) || v.length !== 3) throw new InputError(`${ctx}: вектор`); return v.map((x, k) => toIv(x, `${ctx}[${k}]`)); };
function torusIn(t, ctx = 'тор') {
  const T = toVec(t.T, `${ctx}.T`);
  return { name: t.name || ctx, A: toVec(t.A, `${ctx}.A`), T: T.every(x => x[0] === x[1]) ? vec.normalize(T) : T };
}
function ringIn(r, ctx = 'кольцо') {
  if (r.widths) return r;                                      // запись § 6.5
  const rec = { name: r.name || ctx, source: 'synthetic', owner: null, threads: r.threads || [], C: toVec(r.C, `${ctx}.C`), E1: toVec(r.E1, `${ctx}.E1`), E2: toVec(r.E2, `${ctx}.E2`),
    s1: toIv(r.s1, `${ctx}.s1`), s2: toIv(r.s2, `${ctx}.s2`), annulus: false, length: null, residual: null, plane_class: null,
    completeness: allInt(r.C, r.E1, r.E2, r.s1, r.s2) ? 'EXACT' : 'CERTIFIED' };
  return { ...rec, ...B.ringWidths(rec) };
}
const lib = fn => (...a) => { try { return fn(...a); } catch (e) { if (e instanceof InputError || e instanceof RT.ThreadError) return { input_error: e.message }; throw e; } };

module.exports = {
  perimeter: (s1, s2) => C.perimeter(s1, s2),
  minimize: C.minimize,
  root: C.root,
  run,
  build: cs => parseThread(cs),
  torusGap: lib((t1, t2) => torusGap(torusIn(t1, 't1'), torusIn(t2, 't2'))),
  ringTorus: lib((ring, torus, threaded) => RT.ringTorus(ringIn(ring), torusIn(torus), !!threaded)),
  ringRing: lib((r1, r2, sharedCusp) => RR.ringRing(ringIn(r1, 'r1'), ringIn(r2, 'r2'), sharedCusp ? { A: toVec(sharedCusp.A, 'sharedCusp.A'), T: toVec(sharedCusp.T, 'sharedCusp.T'), name: sharedCusp.name || null } : null)),
  j5Reading: KC.j5Reading,
  j5Graph: KC.j5Graph,
  validate: L.validate,
  INTERFACE, KERNEL_VERSION, DECLARED, serialize,
};

if (require.main === module) {
  const file = process.argv[2];
  let cs = null, code;
  try { cs = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) {
    process.stdout.write(serialize(errorProtocol(null, 'input_error', `файл случая: ${e.message}`)) + '\n'); process.exit(2);
  }
  const r = runRaw(cs);
  process.stdout.write(serialize(r.p) + '\n');
  code = r.code;
  process.exitCode = code;
}
