'use strict';
// Векторы из вилок: v = [x, y, z], каждая координата — вилка [lo, hi].
const iv = require('./wp0_interval');
const V = (x, y, z) => [iv.I(x), iv.I(y), iv.I(z)];
const vadd = (a, b) => [iv.add(a[0], b[0]), iv.add(a[1], b[1]), iv.add(a[2], b[2])];
const vsub = (a, b) => [iv.sub(a[0], b[0]), iv.sub(a[1], b[1]), iv.sub(a[2], b[2])];
const vneg = a => [iv.neg(a[0]), iv.neg(a[1]), iv.neg(a[2])];
const vscale = (a, s) => [iv.mul(a[0], s), iv.mul(a[1], s), iv.mul(a[2], s)];
const dot = (a, b) => iv.add(iv.add(iv.mul(a[0], b[0]), iv.mul(a[1], b[1])), iv.mul(a[2], b[2]));
const cross = (a, b) => [
  iv.sub(iv.mul(a[1], b[2]), iv.mul(a[2], b[1])),
  iv.sub(iv.mul(a[2], b[0]), iv.mul(a[0], b[2])),
  iv.sub(iv.mul(a[0], b[1]), iv.mul(a[1], b[0])),
];
function norm2(a) { const s = dot(a, a); return [Math.max(0, s[0]), s[1]]; }
const norm = a => iv.sqrt(norm2(a));
function normalize(a) {
  const n = norm(a);
  if (n[0] <= 0) throw new Error('normalize: вектор может быть нулевым');
  return vscale(a, iv.div(iv.I(1), n));
}
const vmid = a => a.map(iv.mid);
const vwidth = a => Math.max(...a.map(c => c[1] - c[0]));
module.exports = { V, vadd, vsub, vneg, vscale, dot, cross, norm2, norm, normalize, vmid, vwidth };
