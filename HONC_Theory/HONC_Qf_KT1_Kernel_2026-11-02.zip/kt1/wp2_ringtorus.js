'use strict';
// HONC / Qf / R1 / КТ-1 — WP-2: кольцо против тора (спецификация G-5а–г; интерфейс v6, § 6.5, § 7).
//  G-5а — кольцо и чужой тор (кольцо его не продевает): f(t) = dist(E(t), средняя окружность) − ½,
//          минимум ветвями и границами; L = наибольшая полуось (|E'(t)| <= max(s1, s2), расстояние 1-липшицево).
//  G-5б — кольцо и продетый им тор: плоскость кольца содержит ось тора, и сечение тела этой плоскостью — ровно
//          два круга радиуса ½ с центрами A ± ½·ν, касающиеся оси в каспе A. Проверка — эллипс против двух кругов.
//  G-5в — касп: кривизна кольца в A против кривизны круга 2. κ_r < 2 — снаружи; = 2 — UNRESOLVED; > 2 — FORBIDDEN.
//  G-5г — окрестность исключения r₀ и поиск вне неё. Обоснования — WP2_RingTorus_Notes.md.
const iv = require('./wp0_interval');
const vec = require('./wp1_vec');
const { minimize } = require('./wp0_cert');
const { distToMid } = require('./wp2_gap');
const L = require('./wp0_labels');

const I = iv.I, HALF = I(0.5), TWO = I(2);
// Объявленный нижний предел запаса кривизны κ = 2 − κ_r (G-5г, TB-2). Обоснование — WP2_RingTorus_Notes.md, § 4.
const KAPPA_MIN = 0.05;
const MAX_EVAL = 100000;

// Точка кольца и её производные на вилке параметра T: E(t) = C + s1 cos t E1 + s2 sin t E2.
function ringAt(ring, T) {
  const s = iv.sin(T), c = iv.cos(T);
  const a = iv.mul(ring.s1, c), b = iv.mul(ring.s2, s);
  const P = vec.vadd(ring.C, vec.vadd(vec.vscale(ring.E1, a), vec.vscale(ring.E2, b)));
  const P1 = vec.vadd(vec.vscale(ring.E1, iv.neg(iv.mul(ring.s1, s))), vec.vscale(ring.E2, iv.mul(ring.s2, c)));
  const P2 = vec.vneg(vec.vadd(vec.vscale(ring.E1, a), vec.vscale(ring.E2, b)));
  return { P, P1, P2 };
}
// Кольцевая область (annulus): точки C + r(cos t E1 + sin t E2), r из вилки полуосей. Сопоставления по t нет.
function annulusAt(ring, T) {
  const s = iv.sin(T), c = iv.cos(T), r = iv.hull(ring.s1, ring.s2);
  const P = vec.vadd(ring.C, vec.vscale(vec.vadd(vec.vscale(ring.E1, c), vec.vscale(ring.E2, s)), r));
  const P1 = vec.vscale(vec.vadd(vec.vscale(ring.E1, iv.neg(s)), vec.vscale(ring.E2, c)), r);
  return { P, P1 };
}
const sMax = ring => Math.max(ring.s1[1], ring.s2[1]);
const ringWidth = ring => (ring.width_max !== undefined ? ring.width_max : 0);

// Вилка производной расстояния до окружности (центр A, ось T, радиус ½) вдоль кривой: ∇dist·P'.
function dDistMid(P, P1, A, T) {
  const r = vec.vsub(P, A), z = vec.dot(r, T);
  const rp = vec.vsub(r, vec.vscale(T, z));
  const rho = iv.sqrt(vec.norm2(rp));
  const dist = iv.sqrt(iv.add(iv.sqr(iv.sub(rho, HALF)), iv.sqr(z)));
  const k = iv.div(iv.sub(rho, HALF), rho);
  if (!Number.isFinite(k[0]) || !Number.isFinite(k[1])) return [-Infinity, Infinity];
  const g = vec.vscale(vec.vadd(vec.vscale(rp, k), vec.vscale(T, z)), iv.div(I(1), dist));
  const d = vec.dot(g, P1);
  return Number.isFinite(d[0]) && Number.isFinite(d[1]) ? d : [-Infinity, Infinity];
}
// Вилка производной расстояния до точки c вдоль кривой: (P − c)·P'/|P − c|.
function dDistPoint(P, P1, c) {
  const r = vec.vsub(P, c);
  const n = iv.sqrt(vec.norm2(r));
  const d = iv.div(vec.dot(r, P1), n);
  return Number.isFinite(d[0]) && Number.isFinite(d[1]) ? d : [-Infinity, Infinity];
}
const verdictOf = (m, canForbid = true) => (m[0] > 0 ? 'PASSED' : m[1] < 0 && canForbid ? 'FORBIDDEN' : 'UNRESOLVED');
const levelOf = v => (v === 'PASSED' ? 'L2' : 'L1');

// ---------------- G-5а ----------------
function ringForeign(ring, torus, ids = {}) {
  const at = ring.annulus ? T => annulusAt(ring, T) : T => ringAt(ring, T);
  const f = t => iv.sub(distToMid(at(I(t)).P, torus.A, torus.T), HALF);
  const dfBox = (l, r) => { const g = at([l, r]); return dDistMid(g.P, g.P1, torus.A, torus.T); };
  const tol = 1e-12 + 4 * ringWidth(ring);
  // Сначала малый бюджет: если проникновение уже доказано (верхняя граница минимума < 0) или вилка сошлась —
  // достаточно. Иначе полный бюджет. Вилка верна при любом числе шагов (WP-0, § 6).
  let res = minimize({ f, dfBox, a: 0, b: iv.TWO_PI[1], L: sMax(ring), tol, maxEval: 4000 });
  if (!res.converged && !(res.min[1] < 0)) res = minimize({ f, dfBox, a: 0, b: iv.TWO_PI[1], L: sMax(ring), tol, maxEval: MAX_EVAL });
  const m = res.min;
  // Кольцевая область даёт верную нижнюю границу, но не верхнюю: проникновение тогда не доказывается.
  const verdict = verdictOf(m, !ring.annulus);
  let reason = null;
  if (verdict === 'FORBIDDEN') reason = `G-5а: кольцо ${ring.name} входит в тело тора ${torus.name}; запас ${m[1]} < 0`;
  if (verdict === 'UNRESOLVED') reason = ring.annulus && m[1] < 0 ? `G-5а: ориентация осей кольца не установлена (annulus); проникновение не доказуемо`
    : `G-5а: вилка запаса содержит 0${ringWidth(ring) ? `; ring-enclosure ${ring.name}, width_max ${ringWidth(ring)}` : ''}`;
  return L.makeCheck({ id: ids.id || `G5a:${ring.name}:${torus.name}`, req: 'G-5а', objects: [ring.name, torus.name], quantity: 'margin', value: m,
    completeness: 'CERTIFIED', verdict, reason, where: { t: res.argmin }, level: levelOf(verdict), evals: res.evals, converged: res.converged });
}

// ---------------- G-5б–г ----------------
// Параметр t_A точки A на кольце.
function paramAt(ring, A) {
  const w = vec.vsub(A, ring.C);
  const u1 = iv.div(vec.dot(w, ring.E1), ring.s1), u2 = iv.div(vec.dot(w, ring.E2), ring.s2);
  let a = iv.atan2(u2, u1);
  if (!a.cut) return a.v;
  a = iv.atan2(iv.neg(u2), iv.neg(u1));            // поворот на π уводит от разреза
  return a.cut ? null : iv.add(a.v, iv.PI);
}
class ThreadError extends Error {}

function ringThreaded(ring, torus, ids = {}, opts = {}) {
  const kmin = opts.kappaMin !== undefined ? opts.kappaMin : KAPPA_MIN;
  const id = ids.id || `G5bg:${ring.name}:${torus.name}`;
  const base = { id, req: 'G-5б–г', objects: [ring.name, torus.name], quantity: 'kappa_margin' };
  const mk = (value, completeness, verdict, reason, extra = {}) => L.makeCheck({ ...base, value, completeness, verdict, reason, level: levelOf(verdict), ...extra });
  if (ring.annulus) return mk([-Infinity, Infinity], 'UNRESOLVED', 'UNRESOLVED', 'G-5б: ориентация осей кольца не установлена (annulus) — точка каспа на кольце не определена');
  const tA = paramAt(ring, torus.A);
  if (!tA) return mk([-Infinity, Infinity], 'UNRESOLVED', 'UNRESOLVED', 'G-5б: параметр точки каспа не определён');
  const g = ringAt(ring, tA);
  const q0 = vec.vsub(g.P, torus.A);
  // Посылка «продевает» (интерфейс § 4.3): кольцо через центр тора, касательная вдоль оси, ось в плоскости кольца.
  const nPl = vec.cross(ring.E1, ring.E2);
  const tang = vec.cross(g.P1, torus.T);
  const bad = [...q0, ...tang, vec.dot(torus.T, nPl)].some(x => !iv.containsZero(x));
  if (bad) throw new ThreadError(`G-5б: посылка «${ring.name} продевает ${torus.name}» несовместима с вилками (невязка отделена от 0)`);
  // Кривизна в каспе (G-5в): κ_r = |E' × E''| / |E'|³.
  const sp = iv.sqrt(vec.norm2(g.P1));
  const kr = iv.div(iv.sqrt(vec.norm2(vec.cross(g.P1, g.P2))), iv.mul(iv.sqr(sp), sp));
  const kap = iv.sub(TWO, kr);
  const exact = ring.completeness === 'EXACT';
  const cuspC = exact ? 'EXACT' : 'CERTIFIED';
  const extra = { kappa_r: kr, kappa_margin: kap, where: { t: tA } };
  const wtxt = ringWidth(ring) ? `; ring-enclosure ${ring.name}, width_max ${ringWidth(ring)}` : '';
  if (kap[1] < 0) return mk(kap, cuspC, 'FORBIDDEN', `G-5в: κ_r > 2 в каспе ${torus.name} — кольцо ${ring.name} входит в тело у каспа`, extra);
  // Касп: решён (κ > κ_min) или нет. Если не решён, вне каспа всё равно ищется проникновение: найденное
  // проникновение даёт FORBIDDEN по правилу § 1, а PASSED без решённого каспа невозможен.
  let cuspReason = null;
  if (kap[0] <= 0) cuspReason = `G-5в: вилка κ_r содержит 2 (касание третьего порядка не решается)${wtxt}`;
  else if (kap[0] < kmin) cuspReason = `G-5г: запас кривизны κ = 2 − κ_r меньше объявленного κ_min = ${kmin} (TB-2)`;
  // Окрестность исключения (G-5г). q(t) = E(t) − A; h±(t) = |q|² ∓ q·ν — квадрат расстояния до центра A ± ½ν минус ¼.
  // h±(t*) = 0 и h±'(t*) = 0 в истинной точке каспа t* (посылка продевания), поэтому h±(t) = ½h±''(ξ)(t − t*)².
  // Если вилка h±'' на Θ ∋ t* положительна, кольцо вне обоих кругов на Θ (кроме самой точки A).
  const w = vec.vsub(ring.C, torus.A);
  const tau = vec.normalize(g.P1);
  const nu = vec.normalize(vec.vsub(w, vec.vscale(tau, vec.dot(w, tau))));   // к центру эллипса — сторона изгиба
  const hpp = (T, sgn) => {
    const r = ringAt(ring, T), q = vec.vsub(r.P, torus.A);
    // h'' = 2(q'·q' + q·q'') ∓ q''·ν
    const base2 = iv.mul(TWO, iv.add(vec.dot(r.P1, r.P1), vec.dot(q, r.P2)));
    const lin = vec.dot(r.P2, nu);
    return sgn > 0 ? iv.sub(base2, lin) : iv.add(base2, lin);
  };
  let Theta = null;
  if (!cuspReason) {
    const okAt = hw => { const Th = [iv.sub(tA, I(hw))[0], iv.add(tA, I(hw))[1]]; return hpp(Th, 1)[0] > 0 && hpp(Th, -1)[0] > 0 ? Th : null; };
    let hw = 0.5, bad = null;
    for (let k = 0; k < 40; k++) { Theta = okAt(hw); if (Theta) break; bad = hw; hw /= 2; }
    // Подбор ширины ближе к наибольшей допустимой: деление пополам между годной hw и негодной 2hw.
    // Иначе ширина окна скачет двоичными ступенями, и запас у края окна зависит от κ ступенчато.
    if (Theta && bad) {
      let lo = hw, hi = bad;
      for (let k = 0; k < 8; k++) { const m = (lo + hi) / 2, T = okAt(m); if (T) { lo = m; Theta = T; } else hi = m; }
    }
    if (!Theta) cuspReason = 'G-5г: окрестность исключения r₀ не получена';
  }
  // Без окрестности исключения поиск вне каспа служит только поиску проникновения: окно берётся фиксированным.
  const win = Theta || [iv.sub(tA, I(0.05))[0], iv.add(tA, I(0.05))[1]];
  const r0arc = Theta ? iv.mul(I(Theta[1] - Theta[0]), I(sMax(ring) / 2))[1] : null;   // верхняя оценка длины дуги половины окрестности
  // Вне окрестности: расстояние до обоих центров минус ½ (G-5г), t ∈ [Θ.hi, Θ.lo + 2π].
  const c1 = vec.vadd(torus.A, vec.vscale(nu, HALF)), c2 = vec.vsub(torus.A, vec.vscale(nu, HALF));
  const a = win[1], b = iv.add(I(win[0]), iv.TWO_PI)[0];
  const outside = c => {
    const f = t => iv.sub(iv.sqrt(vec.norm2(vec.vsub(ringAt(ring, I(t)).P, c))), HALF);
    const dfBox = (l, r) => { const gg = ringAt(ring, [l, r]); return dDistPoint(gg.P, gg.P1, c); };
    const tol = 1e-12 + 4 * ringWidth(ring);
    let res = minimize({ f, dfBox, a, b, L: sMax(ring), tol, maxEval: 4000 });
    if (!res.converged && !(res.min[1] < 0)) res = minimize({ f, dfBox, a, b, L: sMax(ring), tol, maxEval: MAX_EVAL });
    return res;
  };
  const o1 = outside(c1), o2 = outside(c2);
  const mo = [Math.min(o1.min[0], o2.min[0]), Math.min(o1.min[1], o2.min[1])];
  const vo = verdictOf(mo);
  // Лежит ли минимум вне окрестности у её края: тогда это свойство окрестности, а не отдельный запас кольца.
  const om = o1.min[0] <= o2.min[0] ? o1 : o2;
  const edge = om.argmin.some(([l, r]) => l <= a + 1e-9 || r >= b - 1e-9);
  const ext = { ...extra, r0: Theta ? { t_window: Theta, arc_half_width_bound: r0arc } : null, outside_margin: mo, outside_min_at_window_edge: edge,
    cusp: { verdict: cuspReason ? 'UNRESOLVED' : 'PASSED', completeness: cuspC }, outside: { verdict: vo, completeness: 'CERTIFIED', window: win, window_certified: !!Theta }, kappa_min: kmin,
    where: { t: tA, outside_t: vo === 'PASSED' ? null : om.argmin } };
  if (vo === 'FORBIDDEN') return mk(kap, 'CERTIFIED', 'FORBIDDEN', `G-5г: кольцо ${ring.name} входит в тело продетого тора ${torus.name} вне каспа; запас ${mo[1]} < 0`, ext);
  if (cuspReason) return mk(kap, cuspC, 'UNRESOLVED', cuspReason, ext);
  if (vo === 'PASSED') return mk(kap, 'CERTIFIED', 'PASSED', null, ext);
  return mk(kap, 'CERTIFIED', 'UNRESOLVED', `G-5г: вилка запаса вне r₀ содержит 0${wtxt}`, ext);
}

// Библиотечная точка (интерфейс § 7): K.ringTorus(ring, torus, threaded).
function ringTorus(ring, torus, threaded, ids, opts) {
  return threaded ? ringThreaded(ring, torus, ids, opts) : ringForeign(ring, torus, ids);
}

module.exports = { ringTorus, ringForeign, ringThreaded, ringAt, paramAt, KAPPA_MIN, ThreadError };
