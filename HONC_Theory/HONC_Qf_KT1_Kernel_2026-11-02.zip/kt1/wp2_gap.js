'use strict';
// HONC / Qf / R1 / КТ-1 — WP-2a: примитив G-4, зазор тор–тор. Зависит только от G-1 (тор = центр A, единичная ось T).
// g = min_φ dist(C1(φ), C2) − 1, C1(φ) = A1 + ½(e1 cos φ + e2 sin φ) — средняя окружность первого тора,
// dist(X, C2) — расстояние от точки до средней окружности второго (закрытая форма).
// Константа Липшица по φ: |dC1/dφ| = ½ при ортонормированных e1, e2, а расстояние до множества 1-липшицево, значит L = ½.
const iv = require('./wp0_interval');
const vec = require('./wp1_vec');
const { minimize } = require('./wp0_cert');

// Расстояние от точки X до окружности радиуса ½ с центром A и осью T (T — единичная).
function distToMid(X, A, T) {
  const r = vec.vsub(X, A);
  const z = vec.dot(r, T);
  let rho2 = iv.sub(vec.norm2(r), iv.sqr(z));
  rho2 = [Math.max(0, rho2[0]), Math.max(0, rho2[1])];      // истинное значение >= 0
  const rho = iv.sqrt(rho2);
  return iv.sqrt(iv.add(iv.sqr(iv.sub(rho, iv.I(0.5))), iv.sqr(z)));
}
// Ортонормированный базис плоскости, перпендикулярной T: e1 = норм(T × a), e2 = T × e1, a — точный вектор, не параллельный T.
function perpBasis(T) {
  const m = vec.vmid(T);
  const a = Math.abs(m[0]) < 0.9 ? vec.V(1, 0, 0) : vec.V(0, 1, 0);
  const e1 = vec.normalize(vec.cross(T, a));
  const e2 = vec.cross(T, e1);
  return { e1, e2 };
}
function midPoint(A, e1, e2, phi) {
  const { s, c } = iv.sinCosPoint(phi);
  return vec.vadd(A, vec.vscale(vec.vadd(vec.vscale(e1, c), vec.vscale(e2, s)), iv.I(0.5)));
}
// Вилка производной g(φ) = dist(C1(φ), C2) по φ на отрезке Φ: g' = ∇dist(X) · C1'(φ),
// ∇dist = ((ρ − ½)/ρ · r⊥ + z·T2) / dist. Особенности (ρ = 0 или dist = 0) дают бесконечную вилку — откат к L = ½.
function dGapBox(t1, e1, e2, t2) {
  return (lo, hi) => {
    const P = [lo, hi], s = iv.sin(P), c = iv.cos(P);
    const X = vec.vadd(t1.A, vec.vscale(vec.vadd(vec.vscale(e1, c), vec.vscale(e2, s)), iv.I(0.5)));
    const dX = vec.vscale(vec.vadd(vec.vscale(e1, iv.neg(s)), vec.vscale(e2, c)), iv.I(0.5));
    const r = vec.vsub(X, t2.A), z = vec.dot(r, t2.T);
    const rp = vec.vsub(r, vec.vscale(t2.T, z));
    let rho2 = vec.norm2(rp); const rho = iv.sqrt(rho2);
    const dist = iv.sqrt(iv.add(iv.sqr(iv.sub(rho, iv.I(0.5))), iv.sqr(z)));
    const k = iv.div(iv.sub(rho, iv.I(0.5)), rho);
    if (!Number.isFinite(k[0]) || !Number.isFinite(k[1])) return [-Infinity, Infinity];
    const grad = vec.vscale(vec.vadd(vec.vscale(rp, k), vec.vscale(t2.T, z)), iv.div(iv.I(1), dist));
    const g = vec.dot(grad, dX);
    return Number.isFinite(g[0]) && Number.isFinite(g[1]) ? g : [-Infinity, Infinity];
  };
}
// G-4. Возвращает вилку зазора, вилки точек минимума по φ (на первом торе) и полноту.
function torusGap(t1, t2, opts = {}) {
  const { e1, e2 } = perpBasis(t1.T);
  const f = phi => distToMid(midPoint(t1.A, e1, e2, phi), t2.A, t2.T);
  const r = minimize({ f, dfBox: dGapBox(t1, e1, e2, t2), a: 0, b: iv.TWO_PI[1], L: 0.5, tol: opts.tol || 1e-13, maxEval: opts.maxEval || 400000 });
  const gap = iv.sub(r.min, iv.I(1));
  return { gap, argmin: r.argmin, converged: r.converged, evals: r.evals, completeness: 'CERTIFIED', L: 0.5 };
}
module.exports = { torusGap, distToMid, perpBasis, midPoint };
