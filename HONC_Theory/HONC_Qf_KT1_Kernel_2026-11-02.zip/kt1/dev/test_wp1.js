'use strict';
// Рабочие проверки исполнителя по WP-1 (зеркальные звенья) и WP-2a (G-4). Не приёмочный набор.
const iv = require('../wp0_interval');
const vec = require('../wp1_vec');
const { build, NotYet } = require('../wp1_build');
const { torusGap, distToMid } = require('../wp2_gap');
const R = require('./ref_bigint');

let pass = 0, fail = 0; const fails = [];
const ok = (c, m) => { if (c) pass++; else { fail++; fails.push(m); } };
const has = (v, x, slack = 0) => v[0] - slack <= x && x <= v[1] + slack;
const insideRef = (v, ref) => R.fromDouble(v[0]) <= ref + 1n && ref - 1n <= R.fromDouble(v[1]) + 1n;
const mirrorLinks = n => Array.from({ length: n }, () => ({ theta: 0, phi: 0, delta: 0 }));
const point = x => [iv.I(x[0]), iv.I(x[1]), iv.I(x[2])];

// 1. К1 — прямая нить
const k1 = build({ thread: { n: 5, links: mirrorLinks(5) }, hangs: [] });
for (let k = 0; k < 5; k++) {
  const t = k1.tori[k];
  ok(has(t.A[2], 2 * k) && has(t.A[0], 0) && has(t.A[1], 0), `К1: центр T${k}`);
  ok(t.tClass === 0 && t.planeClass === 0, `К1: класс оси и плоскости T${k}`);
}
for (const r of k1.rings) ok(r.completeness === 'EXACT' && r.s1[0] === 1 && r.s2[1] === 1, `К1: ${r.name} — окружность радиуса 1 по тождеству`);
// Кольцо по тождеству: G-2 с поправкой требует ≤ 1e-12. Ширина центра не нулевая — это расширение наружу на единицу
// последнего разряда при сложении A + u, а не погрешность построения.
for (const r of k1.rings) ok(r.source === 'construction' && r.width_max <= 1e-12 && r.widths.residual === 0 && r.widths.s1 === 0
  && r.widths.length > 0 && r.widths.length < 1e-14, `К1: ${r.name} — ширины ≤ 1e-12 (G-2): ${JSON.stringify(r.widths)}`);
for (const c of k1.contacts) ok(c.d[0] === 2 && c.d[1] === 2 && c.existence === 'IMPOSED', `К1: d = 2, IMPOSED ${c.pair}`);
ok(k1.evidence.some(e => e.rule === 'П-1') && k1.evidence.filter(e => e.rule === 'П-3').length === 4, 'К1: свидетельства П-1, П-3');
ok(k1.parallelEstablished(k1.tori[0], k1.tori[4]) && k1.sideByConstruction(k1.tori[1], k1.tori[2]), 'К1: П-6, П-7');
ok(k1.conventions.length === 5, 'К1: пять зеркальных звеньев помечены конвенцией [Г]');
{
  const g01 = torusGap(k1.tori[0], k1.tori[1]).gap, g02 = torusGap(k1.tori[0], k1.tori[2]).gap;
  ok(has(g01, 0), `К1: зазор соседей содержит 0: ${g01}`);
  ok(has(g02, 2), `К1: зазор T0–T2 содержит 2: ${g02}`);
  console.log(`К1: зазор T0–T1 = [${g01[0].toExponential(2)}, ${g01[1].toExponential(2)}]; T0–T2 = [${g02[0]}, ${g02[1]}]`);
}

// 2. Кλ1 — d(θ) = cos θ + 1 при φ = 90°; кольцо общего вида
for (const th of [30, 60, 75, 85]) {
  const c = build({ thread: { n: 2, links: [{ theta: th, phi: 90, delta: 0 }, { theta: 0, phi: 0, delta: 0 }] }, hangs: [] });
  const d = c.contacts[0].d;
  const refCos = R.sinCosF((BigInt(th) * R.PI) / 180n).c + R.ONE;
  ok(insideRef(d, refCos), `Кλ1 θ=${th}: d содержит cos θ + 1`);
  const r = c.rings[0];
  ok(has(r.residual, 0), `Кλ1 θ=${th}: невязка длины содержит 0`);
  // Поправка G-2 (02.11): у кольца общего вида верхней границы ширины нет, ширина печатается (интерфейс v6, § 6.5).
  // Здесь проверяется, что ширины напечатаны и покрывают поля. Граница 1e-8 — только страж регрессии точности
  // в рабочих проверках исполнителя, а не критерий приёмки.
  const W = r.widths, wr = r.residual[1] - r.residual[0];
  ok(r.source === 'construction' && W && W.residual >= wr && W.s1 >= r.s1[1] - r.s1[0] && W.s2 >= r.s2[1] - r.s2[0]
    && r.width_max >= Math.max(W.C, W.E1, W.E2, W.s1, W.s2), `Кλ1 θ=${th}: ширины напечатаны и покрывают поля`);
  ok(wr <= 1e-8, `Кλ1 θ=${th}: страж регрессии, ширина невязки ${wr}`);
  ok(vec.vwidth(r.E1) < 1e-10 && !r.annulus, `Кλ1 θ=${th}: ориентация осей определена`);
  // эллипс проходит через A и B и касается T_A в A
  const A = c.tori[0].A, B = c.tori[1].A;
  const onE = P => { const w = vec.vsub(P, r.C); const x = iv.div(vec.dot(w, r.E1), r.s1), y = iv.div(vec.dot(w, r.E2), r.s2); return iv.add(iv.sqr(x), iv.sqr(y)); };
  ok(has(onE(A), 1, 1e-9) && has(onE(B), 1, 1e-9), `Кλ1 θ=${th}: A и B на эллипсе`);
  const w = vec.vsub(A, r.C);
  const grad = vec.vadd(vec.vscale(r.E1, iv.div(vec.dot(w, r.E1), iv.sqr(r.s1))), vec.vscale(r.E2, iv.div(vec.dot(w, r.E2), iv.sqr(r.s2))));
  ok(has(vec.dot(grad, c.tori[0].T), 0, 1e-9), `Кλ1 θ=${th}: касательная в A вдоль T_A`);
  // независимая длина по ряду Гаусса — Куммера на серединах полуосей
  const s1 = iv.mid(r.s1), s2 = iv.mid(r.s2);
  const Pref = R.toNum(R.perimeterF(R.fromDouble(Math.max(s1, s2)), R.fromDouble(Math.min(s1, s2))));
  ok(Math.abs(Pref - 2 * Math.PI) < 1e-11, `Кλ1 θ=${th}: длина по ряду Гаусса — Куммера ${Pref}`);
  console.log(`Кλ1 θ=${th}: d = [${d[0]}, ${d[1]}], ширина невязки длины ${W.residual.toExponential(2)}, width_max ${r.width_max.toExponential(2)}`);
}

// 3. G-4 — соплоскостные параллельные торы: зазор = D − 2 (закрытая форма)
for (const D of [1.998, 1.9999, 2, 2.5, 4]) {
  const g = torusGap({ A: point([0, 0, 0]), T: point([0, 1, 0]) }, { A: point([D, 0, 0]), T: point([0, 1, 0]) }).gap;
  ok(has(g, D - 2, 1e-15), `G-4: D=${D}, зазор ${g} против ${D - 2}`);
}
// G-4 против плотной выборки (опровергающая проверка)
let seed = 7; const rnd = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; };
for (let i = 0; i < 40; i++) {
  const nrm = v => { const l = Math.hypot(...v); return v.map(x => x / l); };
  const T1 = nrm([rnd() - .5, rnd() - .5, rnd() - .5]), T2 = nrm([rnd() - .5, rnd() - .5, rnd() - .5]);
  const A2 = [(rnd() - .5) * 4, (rnd() - .5) * 4, (rnd() - .5) * 4];
  const t1 = { A: point([0, 0, 0]), T: point(T1) }, t2 = { A: point(A2), T: point(T2) };
  const res = torusGap(t1, t2);
  // выборка в обычной арифметике
  const a = Math.abs(T1[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0];
  const cr = (p, q) => [p[1] * q[2] - p[2] * q[1], p[2] * q[0] - p[0] * q[2], p[0] * q[1] - p[1] * q[0]];
  const e1 = nrm(cr(T1, a)), e2 = cr(T1, e1);
  let sm = Infinity;
  for (let k = 0; k < 20000; k++) {
    const f = 2 * Math.PI * k / 20000, X = [0, 1, 2].map(j => 0.5 * (e1[j] * Math.cos(f) + e2[j] * Math.sin(f)));
    const r = X.map((x, j) => x - A2[j]), z = r[0] * T2[0] + r[1] * T2[1] + r[2] * T2[2];
    const rho = Math.sqrt(Math.max(0, r[0] ** 2 + r[1] ** 2 + r[2] ** 2 - z * z));
    sm = Math.min(sm, Math.hypot(rho - 0.5, z) - 1);
  }
  ok(res.gap[0] <= sm + 1e-12, `G-4 случайная пара ${i}: нижняя граница не выше выборки`);
  ok(res.gap[1] >= sm - 1e-4, `G-4 случайная пара ${i}: верхняя граница согласована с выборкой`);
}

// 4. Навесы, зеркальные
const thread5 = mirrorLinks(5);
{ // А-2 (i): поперечный навес
  const c = build({ thread: { n: 5, links: thread5 }, hangs: [{ host: 2, side: 1, coords: 'rho-psi', rho: 0, psi: 0, delta: 0 }] });
  const H = c.tori[5];
  ok(has(H.A[0], 2) && has(H.A[2], 4) && H.tClass === 0, 'А-2 (i): навес в (2, 0, 4), ось хозяина (П-5)');
  ok(c.evidence.some(e => e.rule === 'П-5'), 'А-2 (i): свидетельство П-5');
  const g = torusGap(H, c.tori[1]).gap;
  ok(has(g, 2 * Math.SQRT2 - 2, 1e-12), `А-2 (i): зазор навес–T1 = 2√2 − 2: ${g}`);
}
{ // А-2 (iv): ρ = 31°, ψ = 0 — проникновение в T1
  const c = build({ thread: { n: 5, links: thread5 }, hangs: [{ host: 2, side: 1, coords: 'rho-psi', rho: 31, psi: 0, delta: 0 }] });
  const g = torusGap(c.tori[5], c.tori[1]).gap;
  ok(g[1] < 0, `А-2 (iv): проникновение, вилка зазора ниже 0: ${g}`);
}
{ // Б-8: ρ = 30° числом — зазор содержит 0
  const c = build({ thread: { n: 5, links: thread5 }, hangs: [{ host: 2, side: 1, coords: 'rho-psi', rho: 30, psi: 0, delta: 0 }] });
  const g = torusGap(c.tori[5], c.tori[1]).gap;
  ok(has(g, 0), `Б-8: зазор навес–T1 содержит 0: ${g}`);
  console.log(`Б-8: зазор навес–T1 = [${g[0].toExponential(2)}, ${g[1].toExponential(2)}]`);
}
{ // зеркальный навес вне плоскости (α–λ): кольцо общего вида
  const c = build({ thread: { n: 5, links: thread5 }, hangs: [{ host: 2, side: 1, coords: 'alpha-lambda', alpha: 52, lambda: 25, delta: 0 }] });
  const r = c.rings.find(x => x.name === 'RH1');
  ok(c.tori[5].tClass !== 0 && has(r.residual, 0) && r.completeness === 'CERTIFIED', 'навес α=52°, λ=25°: ось не параллельна, невязка длины содержит 0');
}
// 5. G-3 незеркальное и уравнение касания (wp2_linkroot.js, WP2_Roots_Notes.md)
const D = require('../wp1_dual');
const { makeSpec, Unresolved, InputError } = require('../wp1_build');
const { linkDistance } = require('../wp2_linkroot');
const uAt = th => { const r = iv.deg2rad(iv.fromInput(th)); return [iv.I(0), iv.sin(r), iv.cos(r)]; };   // φ = 90°
const host0 = { A: vec.V(0, 0, 0), T: vec.V(0, 1, 0) };
// (а) путь корня на зеркальном звене совпадает с закрытой формой d = cos θ + 1
for (const th of [0, 30, 60, 75]) {
  const r = linkDistance(host0, makeSpec(host0.T, () => D.vlift(uAt(th), 2), 0));
  const ref = R.sinCosF((BigInt(th) * R.PI) / 180n).c + R.ONE;
  ok(r.ok && insideRef(r.d, ref) && r.d[1] - r.d[0] <= 1e-12, `G-3 корнем, зеркальное θ=${th}: вилка содержит cos θ + 1, ширина ${r.ok && r.d[1] - r.d[0]}`);
}
// выборочная оценка зазора в обычной арифметике — опровергающая проверка (верхняя оценка минимума)
const nrm = v => { const l = Math.hypot(...v); return v.map(x => x / l); };
const mids = t => t.map(iv.mid);
function sampledGap(A1, T1, A2, T2, N = 20000) {
  const a = Math.abs(T1[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0];
  const cr = (p, q) => [p[1] * q[2] - p[2] * q[1], p[2] * q[0] - p[0] * q[2], p[0] * q[1] - p[1] * q[0]];
  const e1 = nrm(cr(T1, a)), e2 = cr(T1, e1);
  let m = Infinity;
  for (let k = 0; k < N; k++) {
    const f = 2 * Math.PI * k / N, X = [0, 1, 2].map(j => A1[j] + 0.5 * (e1[j] * Math.cos(f) + e2[j] * Math.sin(f)));
    const r = X.map((x, j) => x - A2[j]), z = r[0] * T2[0] + r[1] * T2[1] + r[2] * T2[2];
    const rho = Math.sqrt(Math.max(0, r[0] ** 2 + r[1] ** 2 + r[2] ** 2 - z * z));
    m = Math.min(m, Math.hypot(rho - 0.5, z) - 1);
  }
  return m;
}
// (б) незеркальные звенья нити
for (const [th, de] of [[0, 10], [30, 10], [60, -20], [85, 10]]) {
  const c = build({ thread: { n: 2, links: [{ theta: th, phi: 90, delta: de }, { theta: 0, phi: 0, delta: 0 }] }, hangs: [] });
  const ct = c.contacts[0], d = ct.d, t1 = c.tori[1];
  ok(ct.basis.form === 'корень G-4 (незеркальное звено)' && d[1] - d[0] <= 1e-12, `незеркальное θ=${th}, δ=${de}: d — корень G-4, ширина ${d[1] - d[0]} <= 1e-12`);
  const u = mids(uAt(th)), T2 = nrm(mids(t1.T));
  const at = x => sampledGap([0, 0, 0], [0, 1, 0], u.map(v => v * x), T2);
  ok(at(d[0] - 1e-6) < 0, `незеркальное θ=${th}, δ=${de}: выборка — проникновение левее вилки d`);
  ok(at(d[1] + 1e-6) > -1e-9, `незеркальное θ=${th}, δ=${de}: выборка согласна правее вилки d`);
  ok(has(c.rings[0].residual, 0) && c.rings[0].completeness === 'CERTIFIED', `незеркальное θ=${th}, δ=${de}: кольцо общего вида, невязка длины содержит 0`);
  ok(c.conventions.length === 1, `незеркальное θ=${th}, δ=${de}: конвенцией [Г] помечено только зеркальное последнее звено`);
}
// (в) уравнение касания
const fixCase = hang => build({ thread: { n: 5, links: thread5 }, hangs: [hang] });
{ // К2 (ii) и (iii): корень ровно 30°, тождество П-5
  for (const [psi, wth] of [[0, 'T1'], [180, 'T3']]) {
    const c = fixCase({ host: 2, side: 1, coords: 'rho-psi', rho: null, psi, delta: 0, fix: { kind: 'contact', free: 'rho', with: wth, bracket: [29.5, 30.5] } });
    const H = c.tori[5], rt = H.fix.root_deg;
    ok(has(rt, 30) && rt[1] - rt[0] < 1e-9, `К2 ψ=${psi}: корень ρ содержит 30°, ширина ${rt[1] - rt[0]}`);
    const ctc = c.contacts.find(x => x.basis.rule === 'П-8б');
    ok(ctc && ctc.pair[0] === wth && ctc.existence === 'IMPOSED' && /единств/i.test(ctc.basis.uniqueness), `К2 ψ=${psi}: касание с ${wth} IMPOSED по П-8б с доводом единственности`);
    ok(H.tClass === c.tori[2].tClass && c.rings.find(x => x.name === 'RH1').completeness === 'EXACT', `К2 ψ=${psi}: П-5, кольцо навеса — окружность по тождеству`);
  }
}
{ // Б-3: α = 52°, λ свободный, зеркальное — сверка с независимым поиском корня по выборке
  const c = fixCase({ host: 2, side: 1, coords: 'alpha-lambda', alpha: 52, lambda: null, delta: 0, fix: { kind: 'contact', free: 'lambda', with: 'T1', bracket: [20, 35] } });
  const rt = c.tori[5].fix.root_deg;
  const g = lam => { const a = 52 * Math.PI / 180, l = lam * Math.PI / 180;
    const e = [Math.cos(l) * Math.cos(a), Math.cos(l) * Math.sin(a), -Math.sin(l)];
    const Tp = [-2 * e[1] * e[0], 1 - 2 * e[1] * e[1], -2 * e[1] * e[2]], dd = Math.sqrt(1 - e[1] * e[1]) + 1;
    return sampledGap([0, 0, 2], [0, 1, 0], [dd * e[0], dd * e[1], 4 + dd * e[2]], nrm(Tp), 40000); };
  let lo = 20, hi = 35; for (let k = 0; k < 40; k++) { const m = (lo + hi) / 2; if (g(m) > 0) lo = m; else hi = m; }
  ok(Math.abs(iv.mid(rt) - (lo + hi) / 2) < 1e-4, `Б-3: корень λ ${iv.mid(rt)}° против выборки ${(lo + hi) / 2}°`);
}
{ // нет корня в вилке — честный отказ, а не приближение
  let un = false; try { fixCase({ host: 2, side: 1, coords: 'rho-psi', rho: null, psi: 0, delta: 0, fix: { kind: 'contact', free: 'rho', with: 'T1', bracket: [40, 50] } }); } catch (e) { un = e instanceof Unresolved; }
  ok(un, 'fix без корня в вилке: Unresolved');
  let ie = false; try { fixCase({ host: 2, side: 1, coords: 'rho-psi', rho: 30, psi: 0, delta: 0, fix: { kind: 'contact', free: 'rho', with: 'T1', bracket: [29.5, 30.5] } }); } catch (e) { ie = e instanceof InputError; }
  ok(ie, 'fix: свободный параметр не null — input_error');
}
if (!process.env.KT1_QUICK) { // К4 — долгий случай
  const t0 = Date.now();
  const c = fixCase({ host: 2, side: 1, coords: 'rho-psi', rho: null, psi: 54, delta: 10, fix: { kind: 'contact', free: 'rho', with: 'T1', bracket: [56.0, 58.5] } });
  const rt = c.tori[5].fix.root_deg, link = c.contacts.find(x => x.pair[1] === 'H1' && x.cls === 'LINK');
  ok(Math.abs(iv.mid(rt) - 57.261) < 0.001, `К4: ρ = ${iv.mid(rt)}° (спецификация, Э-П: 57,261° ± 0,001°)`);
  ok(rt[1] - rt[0] < 1e-6 && link.d[1] - link.d[0] < 1e-9, `К4: вилки ρ (${rt[1] - rt[0]}) и d (${link.d[1] - link.d[0]}) узкие`);
  ok(has(c.rings.find(x => x.name === 'RH1').residual, 0), 'К4: кольцо навеса — невязка длины содержит 0');
  console.log(`К4: ρ = [${rt[0]}, ${rt[1]}]°, d = [${link.d[0]}, ${link.d[1]}], ${Date.now() - t0} мс`);
}

console.log(`\nИтого: ${pass} прошло, ${fail} не прошло`);
if (fail) { console.log(fails.slice(0, 20).join('\n')); process.exit(1); }
