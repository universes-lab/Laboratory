# Независимая выборочная проверка (обычная арифметика, вне ядра): касание навеса с T1 при ψ = 54° и 56°, δ = 10°.
import numpy as np
def basis(T):
    a=np.array([1.,0,0]) if abs(T[0])<0.9 else np.array([0,1.,0])
    e1=np.cross(T,a); e1/=np.linalg.norm(e1); e2=np.cross(T,e1); return e1,e2
def gap(A1,T1,A2,T2,N=6000):
    e1,e2=basis(T1); ph=np.linspace(0,2*np.pi,N,endpoint=False)
    X=A1[None,:]+0.5*(np.cos(ph)[:,None]*e1+np.sin(ph)[:,None]*e2)
    r=X-A2; z=r@T2; rho=np.sqrt(np.maximum(0,(r*r).sum(1)-z*z)); d=np.sqrt((rho-0.5)**2+z*z)
    i=d.argmin()
    # local refine
    lo,hi=ph[i]-2*np.pi/N, ph[i]+2*np.pi/N
    ph2=np.linspace(lo,hi,2001); X=A1[None,:]+0.5*(np.cos(ph2)[:,None]*e1+np.sin(ph2)[:,None]*e2)
    r=X-A2; z=r@T2; rho=np.sqrt(np.maximum(0,(r*r).sum(1)-z*z)); d=np.sqrt((rho-0.5)**2+z*z)
    return d.min()-1
T=np.array([0,1.,0]); ex=np.array([1.,0,0]); ey=T; ez=np.array([0,0,1.])
Ah=np.array([0,0,4.]); A1=np.array([0,0,2.])
def hang(rho,psi,delta):
    r=np.radians(rho); p=np.radians(psi); dl=np.radians(delta)
    e=ex*np.cos(r)+(-ez*np.cos(p)+ey*np.sin(p))*np.sin(r)
    Tp=T-2*(T@e)*e; n=np.cross(e,T); n/=np.linalg.norm(n)
    TH=Tp*np.cos(dl)+np.cross(n,Tp)*np.sin(dl)
    lo,hi=0.5,2.0
    for _ in range(50):
        m=(lo+hi)/2
        if gap(Ah,T,Ah+m*e,TH)<0: lo=m
        else: hi=m
    return Ah+lo*e, TH, lo
for psi in [54,56]:
    for rho in [52,54,55,56,57,57.261,58,59,60,62]:
        A,TH,d=hang(rho,psi,10)
        print(psi,rho,round(d,6),round(gap(A1,T,A,TH),6))
