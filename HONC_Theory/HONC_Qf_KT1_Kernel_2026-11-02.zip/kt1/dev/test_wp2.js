'use strict';
// Рабочие проверки исполнителя по WP-2: кольцо–тор (G-5а–г). Не приёмочный набор.
const iv = require('../wp0_interval');
const vec = require('../wp1_vec');
const { build } = require('../wp1_build');
const { ringTorus, KAPPA_MIN } = require('../wp2_ringtorus');

let pass = 0, fail = 0; const fails = [];
const ok = (c, m) => { if (c) pass++; else { fail++; fails.push(m); } };
const has = (v, x, slack = 0) => v[0] - slack <= x && x <= v[1] + slack;
const F = x => iv.fromInput(x), V3 = a => a.map(F);
const syn = (name, o) => ({ name, C: V3(o.C), E1: V3(o.E1), E2: V3(o.E2), s1: F(o.s1), s2: F(o.s2), completeness: 'CERTIFIED', annulus: false, width_max: 0 });
const T0 = { name: 'T0', A: vec.V(0, 0, 0), T: vec.V(0, 1, 0) };

// 1. G-5а — синтетика с закрытой формой запаса
{
  const c = ringTorus(syn('Q', { C: [0, 0.3, 0], E1: [1, 0, 0], E2: [0, 0, 1], s1: 0.5, s2: 0.5 }), T0, false);
  ok(c.req === 'G-5а' && c.verdict === 'FORBIDDEN' && has(c.value, -0.2, 1e-15), `G-5а: окружность в сечении y = 0,3 — запас −0,2: ${c.value}`);
  const m = ringTorus(syn('Q0', { C: [0, 0, 0], E1: [1, 0, 0], E2: [0, 0, 1], s1: 0.999999, s2: 0.999999 }), T0, false);
  ok(m.verdict === 'FORBIDDEN' && has(m.value, -1e-6, 1e-15), `G-5а: проникновение 10⁻⁶ найдено: ${m.value}`);
  const s = ringTorus(syn('Q1', { C: [0, 0, 3], E1: [1, 0, 0], E2: [0, 1, 0], s1: 1, s2: 1 }), T0, false);
  ok(s.verdict === 'PASSED' && s.value[0] > 0, `G-5а: далёкое кольцо — PASSED: ${s.value}`);
}
// 2. G-5в — касп
{
  const a = ringTorus(syn('Q', { C: [0, 0, -0.2], E1: [0, 0, 1], E2: [0, 1, 0], s1: 0.2, s2: 0.1 }), T0, true);
  ok(a.verdict === 'FORBIDDEN' && has(a.kappa_r, 20, 1e-12), `G-5в: κ_r = 20 — FORBIDDEN: ${a.kappa_r}`);
  const b = ringTorus(syn('Q', { C: [-0.180000009, 0, 0], E1: [1, 0, 0], E2: [0, 1, 0], s1: 0.180000009, s2: 0.3 }), T0, true);
  ok(b.verdict === 'FORBIDDEN' && b.kappa_margin[1] < 0, `G-5в: κ_r = 2 + 10⁻⁷ — FORBIDDEN в каспе: ${b.kappa_margin}`);
  // κ_r = 2 точно, малый эллипс: касп не решается, но кольцо входит в тело вдали от каспа — FORBIDDEN по G-5г
  const c = ringTorus(syn('Q', { C: [-0.18, 0, 0], E1: [1, 0, 0], E2: [0, 1, 0], s1: 0.18, s2: 0.3 }), T0, true);
  ok(c.verdict === 'FORBIDDEN' && c.cusp.verdict === 'UNRESOLVED' && c.outside.verdict === 'FORBIDDEN', 'κ_r = 2, малый эллипс: касп UNRESOLVED, вне каспа FORBIDDEN, итог FORBIDDEN');
  // κ_r = 2 точно, большой эллипс вне кругов вдали от каспа — только касп: UNRESOLVED
  const d = ringTorus(syn('Q', { C: [-0.98, 0, 0], E1: [1, 0, 0], E2: [0, 1, 0], s1: 0.98, s2: 0.7 }), T0, true);
  ok(d.verdict === 'UNRESOLVED' && d.outside.verdict !== 'FORBIDDEN' && /κ_r содержит 2/.test(d.reason), `κ_r = 2, большой эллипс: UNRESOLVED по каспу: ${d.reason}`);
  // запас меньше κ_min — UNRESOLVED; больше — PASSED
  const k = kap => ringTorus(syn('Q', { C: [-(2 - kap) * 0.49, 0, 0], E1: [1, 0, 0], E2: [0, 1, 0], s1: (2 - kap) * 0.49, s2: 0.7 }), T0, true);
  const lo = k(KAPPA_MIN / 2), hi = k(KAPPA_MIN * 2);
  ok(lo.verdict === 'UNRESOLVED' && /κ_min/.test(lo.reason), `κ = κ_min/2: UNRESOLVED по κ_min: ${lo.reason}`);
  ok(lo.completeness === 'UNRESOLVED' && lo.cusp.completeness === 'UNRESOLVED', 'нерешённый касп — полнота UNRESOLVED, а не формальный EXACT');
  ok(a.completeness === 'EXACT', 'κ_r > 2 в каспе (синтетика из нецелых чисел) — FORBIDDEN, EXACT по методу');
  ok(hi.verdict === 'PASSED' && hi.r0 && hi.outside_margin[0] > 0, `κ = 2κ_min: PASSED, r₀ ${hi.r0 && hi.r0.arc_half_width_bound}`);
  let te = false; try { ringTorus(syn('Q', { C: [-0.9, 0, 0], E1: [1, 0, 0], E2: [0, 1, 0], s1: 1, s2: 1 }), T0, true); } catch (e) { te = /несовместима/.test(e.message); }
  ok(te, 'посылка «продевает» несовместима (кольцо не проходит через центр) — отказ');
}
// 3. Случайные продетые эллипсы против плотной выборки (опровергающая проверка)
{
  let seed = 11; const rnd = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; };
  let nP = 0, nF = 0, nU = 0;
  for (let i = 0; i < 60; i++) {
    const s2 = 0.3 + 1.2 * rnd(), kr = 0.4 + 2 * rnd(), s1 = kr * s2 * s2;
    const c = ringTorus(syn('Q', { C: [-s1, 0, 0], E1: [1, 0, 0], E2: [0, 1, 0], s1, s2 }), T0, true);
    // выборка: минимум по t вне |t| < 1e-3 расстояния до центров (∓0,5; 0) минус ½
    let m = Infinity;
    for (let k = 0; k < 20000; k++) {
      const t = 1e-3 + (2 * Math.PI - 2e-3) * k / 19999, x = -s1 + s1 * Math.cos(t), y = s2 * Math.sin(t);
      m = Math.min(m, Math.hypot(x + 0.5, y) - 0.5, Math.hypot(x - 0.5, y) - 0.5);
    }
    if (c.verdict === 'PASSED') { nP++; ok(m > -1e-9 && kr < 2, `случайный ${i}: PASSED, а выборка даёт ${m} (κ_r ${kr})`); }
    else if (c.verdict === 'FORBIDDEN') { nF++; ok(m < 1e-9 || kr > 2, `случайный ${i}: FORBIDDEN без подтверждения выборкой (κ_r ${kr}, выборка ${m})`); }
    else nU++;
  }
  ok(nP > 5 && nF > 5, `случайные: PASSED ${nP}, FORBIDDEN ${nF}, UNRESOLVED ${nU}`);
  console.log(`Случайные продетые эллипсы: PASSED ${nP}, FORBIDDEN ${nF}, UNRESOLVED ${nU}`);
}
// 4. Построенные конфигурации
const mirror5 = Array.from({ length: 5 }, () => ({ theta: 0, phi: 0, delta: 0 }));
function allPairs(c) {
  const out = [];
  for (const r of c.rings) for (const t of c.tori) out.push({ r, t, ch: ringTorus(r, t, r.threads.includes(t.name)) });
  return out;
}
{
  const c = build({ thread: { n: 5, links: mirror5 }, hangs: [] });
  const P = allPairs(c);
  ok(P.every(x => x.ch.verdict === 'PASSED'), 'К1: все пары кольцо–тор PASSED');
  ok(P.filter(x => x.ch.req === 'G-5б–г').every(x => has(x.ch.kappa_r, 1, 1e-12) && x.ch.cusp.completeness === 'EXACT'), 'К1: κ_r = 1 в каждом каспе, касп EXACT');
  const r0t2 = P.find(x => x.r.name === 'R0' && x.t.name === 'T2').ch;
  ok(has(r0t2.value, 1, 1e-12), `К1: запас R0–T2 = 1: ${r0t2.value}`);
}
for (const [nm, h] of [['К2 (i)', { host: 2, side: 1, coords: 'rho-psi', rho: 0, psi: 0, delta: 0 }],
  ['К3', { host: 2, side: 1, coords: 'rho-psi', rho: null, psi: 0, delta: 0, fix: { kind: 'contact', free: 'rho', with: 'T1', bracket: [29.5, 30.5] } }]]) {
  const c = build({ thread: { n: 5, links: mirror5 }, hangs: [h] });
  ok(allPairs(c).every(x => x.ch.verdict === 'PASSED'), `${nm}: все пары кольцо–тор PASSED`);
}
if (!process.env.KT1_QUICK) {
  const t0 = Date.now();
  const c = build({ thread: { n: 5, links: mirror5 }, hangs: [{ host: 2, side: 1, coords: 'rho-psi', rho: null, psi: 54, delta: 10, fix: { kind: 'contact', free: 'rho', with: 'T1', bracket: [56.0, 58.5] } }] });
  const P = allPairs(c);
  ok(P.every(x => x.ch.verdict === 'PASSED'), 'К4: все пары кольцо–тор PASSED');
  const hc = P.find(x => x.r.name === 'RH1' && x.t.name === 'T2').ch;
  ok(Math.abs(iv.mid(hc.kappa_r) - 1.366) < 0.001 && hc.kappa_margin[0] >= KAPPA_MIN, `К4: κ_r в каспе хозяина ${iv.mid(hc.kappa_r)} (Э-П 1,366)`);
  ok(hc.cusp.completeness === 'EXACT' && hc.outside.completeness === 'CERTIFIED' && hc.completeness === 'CERTIFIED', 'К4: касп кольца общего вида — EXACT (по методу, 03.11); вне каспа и итог — CERTIFIED');
  const rb = P.find(x => x.r.name === 'R1' && x.t.name === 'H1').ch;
  ok(Math.abs(iv.mid(rb.value) - 0.078) < 0.0005 && rb.value[1] - rb.value[0] < 0.005, `К4: запас кольцо R1 — тело навеса ${iv.mid(rb.value)} (Э-П 0,078)`);
  console.log(`К4: κ_r(RH1, T2) = ${iv.mid(hc.kappa_r)}; запас R1–H1 = ${iv.mid(rb.value)}; вне r₀ у каспа T2 ${hc.outside_margin[0]} (у края окна: ${hc.outside_min_at_window_edge}); ${Date.now() - t0} мс`);
}

console.log(`\nИтого: ${pass} прошло, ${fail} не прошло`);
if (fail) { console.log(fails.slice(0, 20).join('\n')); process.exit(1); }
