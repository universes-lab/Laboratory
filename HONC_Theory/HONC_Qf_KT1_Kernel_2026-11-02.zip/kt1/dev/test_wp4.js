'use strict';
// Рабочие проверки исполнителя по WP-4 (K-1…K-6, J5) и консольному входу kt1.js. Не приёмочный набор.
const { execFileSync } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');
const K = require('../kt1');
const KC = require('../wp4_contacts');
const iv = require('../wp0_interval');

let pass = 0, fail = 0; const fails = [];
const ok = (c, m) => { if (c) pass++; else { fail++; fails.push(m); } };
const has = (v, x, slack = 0) => v[0] - slack <= x && x <= v[1] + slack;
const m5 = Array.from({ length: 5 }, () => ({ theta: 0, phi: 0, delta: 0 }));
const fix = (o, free, wth, br) => ({ host: 2, side: 1, delta: 0, ...o, fix: { kind: 'contact', free, with: wth, bracket: br } });
const thread = hangs => ({ thread: { n: 5, links: m5 }, hangs });
const ct = (p, a, b) => p.contacts.find(c => (c.pair[0] === a && c.pair[1] === b) || (c.pair[0] === b && c.pair[1] === a));

// 1. K-3 / K-4 / K-5 — чтение по одной паре (K.j5Reading)
{
  const P = ['PARALLEL-ESTABLISHED', 'PARALLEL-UNCERTAIN', 'NON-PARALLEL'], T = ['SIDE', 'AXIAL', 'MIXED', 'UNDETERMINED'];
  const want = (p, t) => (p === 'PARALLEL-ESTABLISHED' && (t === 'SIDE' || t === 'AXIAL') ? 'J5-CANON' : p === 'NON-PARALLEL' || t === 'MIXED' ? 'J5-EXT' : 'J5-CLASS-UNRESOLVED');
  for (const p of P) for (const t of T) {
    const r = K.j5Reading({ parallel: p, type: t, cos: [[-1, -0.99]] });
    ok(r.reading === want(p, t) && r.sign === -1, `j5Reading ${p} / ${t}: ${r.reading}`);
  }
  const d = K.j5Reading({ parallel: 'PARALLEL-ESTABLISHED', type: 'SIDE', cos: [[-0.01, 0.02]] });
  ok(d.reading === 'J5-DEGENERATE' && d.sign === null && d.reading_class === 'J5-CANON', 'K-4: вилка косинуса содержит 0 — J5-DEGENERATE, знака нет');
  const b5 = K.j5Reading({ parallel: 'NON-PARALLEL', type: 'UNDETERMINED', cos: [[-0.8, -0.6], [0.6, 0.8]] });
  ok(b5.reading === 'J5-EXT' && b5.sign === null && b5.contact_class === 'UNRESOLVED CONTACT' && b5.epsilon >= 0.1 && b5.epsilon < 0.1 + 1e-15, `Б-5: K-5 — UNRESOLVED CONTACT, ε ${b5.epsilon}`);
  ok(K.j5Reading({ parallel: 'NON-PARALLEL', type: 'MIXED', cos: [[0.1, 0.2], [0.3, 0.4]] }).sign === 1, 'одинаковые знаки в двух точках — знак есть');
  let thrown = false; try { K.j5Reading({ parallel: 'PARALLEL', type: 'SIDE', cos: [[1, 1]] }); } catch (e) { thrown = true; }
  ok(thrown, 'j5Reading: недопустимое значение parallel — отказ');
}

// 2. K-6 на абстрактных графах против независимого перебора раскрасок
{
  let seed = 3; const rnd = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; };
  const labels = [['J5-CANON', 1], ['J5-CANON', -1], ['J5-EXT', 1], ['J5-EXT', -1], ['J5-CLASS-UNRESOLVED', 1], ['J5-CLASS-UNRESOLVED', -1], ['J5-DEGENERATE', null]];
  // эталон: перебор всех 2^n раскрасок; мост — ребро, удаление которого увеличивает число компонент
  const colorable = (V, E) => { for (let m = 0; m < 1 << V.length; m++) { const y = v => ((m >> V.indexOf(v)) & 1 ? -1 : 1); if (E.every(e => y(e.a) * y(e.b) === e.sign)) return true; } return false; };
  const comps = (V, E) => { const p = new Map(V.map(v => [v, v])); const f = x => (p.get(x) === x ? x : f(p.get(x))); for (const e of E) p.set(f(e.a), f(e.b)); return new Set(V.map(f)).size; };
  let n = 0, nF = 0, nP = 0, nU = 0;
  for (let g = 0; g < 1500; g++) {
    const nv = 1 + Math.floor(rnd() * 6), V = Array.from({ length: nv }, (_, i) => `v${i}`);
    const E = [];
    const ne = Math.floor(rnd() * (nv * (nv - 1) / 2 + 2));
    for (let k = 0; k < ne && nv > 1; k++) {
      const a = Math.floor(rnd() * nv); let b = Math.floor(rnd() * (nv - 1)); if (b >= a) b++;
      const [reading, sign] = labels[Math.floor(rnd() * (rnd() < 0.5 ? 2 : labels.length))];
      E.push({ a: V[a], b: V[b], cls: 'LINK', existence: 'IMPOSED', reading, sign });
    }
    const r = K.j5Graph({ vertices: V, edges: E });
    const canonE = E.filter(e => e.reading === 'J5-CANON'), signed = E.filter(e => e.sign !== null);
    const allCanon = E.every(e => e.reading === 'J5-CANON');
    const wCanon = !colorable(V, canonE) ? 'FORBIDDEN' : allCanon ? 'PASSED' : 'UNRESOLVED';
    const wExt = !colorable(V, signed) ? 'FORBIDDEN-EXT' : signed.length === E.length ? 'PASSED-EXT' : 'UNRESOLVED';
    const c0 = comps(V, E), wBr = E.map((_, k) => comps(V, E.filter((__, j) => j !== k)) > c0);
    n++; if (wCanon === 'FORBIDDEN') nF++; else if (wCanon === 'PASSED') nP++; else nU++;
    ok(r.canon.verdict === wCanon && r.ext.verdict === wExt && r.edges.every((e, k) => e.bridge === wBr[k] && e.on_cycle === !wBr[k]), `граф ${g}: ${r.canon.verdict}/${wCanon}, ${r.ext.verdict}/${wExt}`);
    if (r.canon.verdict === 'FORBIDDEN') {
      const cyc = r.canon.inconsistent_canon_cycle;
      ok(Array.isArray(cyc) && cyc.length >= 2, `граф ${g}: цикл указан`);
    }
    // знаки Y согласованы с каноническими рёбрами, если итог не FORBIDDEN
    if (r.canon.verdict !== 'FORBIDDEN') {
      const ys = new Map(r.ysigns.map(y => [y.torus, y]));
      ok(canonE.every(e => ys.get(e.a).seed !== ys.get(e.b).seed || ys.get(e.a).label !== 'CANON' || ys.get(e.b).label !== 'CANON' || ys.get(e.a).sign * ys.get(e.b).sign === e.sign), `граф ${g}: знаки Y CANON согласованы`);
    }
    // перенумерация вершин не меняет итогов (Э-М)
    const perm = [...V].sort(() => rnd() - 0.5);
    const r2 = K.j5Graph({ vertices: perm, edges: E });
    ok(r2.canon.verdict === r.canon.verdict && r2.ext.verdict === r.ext.verdict, `граф ${g}: перенумерация не меняет итогов`);
  }
  console.log(`K-6 на ${n} случайных графах: J5-CANON PASSED ${nP}, FORBIDDEN ${nF}, UNRESOLVED ${nU}`);
  ok(nP > 50 && nF > 50 && nU > 50, 'K-6: все три итога представлены');
  // Б-9 / м4: мост J5-EXT
  const b9 = K.j5Graph({ vertices: ['T1', 'T2', 'T3', 'T4'], edges: [
    { a: 'T1', b: 'T2', cls: 'LINK', existence: 'IMPOSED', reading: 'J5-CANON', sign: 1 }, { a: 'T2', b: 'T3', cls: 'LINK', existence: 'IMPOSED', reading: 'J5-CANON', sign: 1 },
    { a: 'T3', b: 'T1', cls: 'LINK', existence: 'IMPOSED', reading: 'J5-CANON', sign: 1 }, { a: 'T3', b: 'T4', cls: 'CONTACT-ONLY', existence: 'IMPOSED', reading: 'J5-EXT', sign: 1 }] });
  ok(b9.canon.verdict === 'UNRESOLVED' && b9.ext.verdict === 'PASSED-EXT' && b9.canon.uncovered_bridges.includes('T3–T4') && b9.ysigns.find(y => y.torus === 'T4').label === '[Г, мост]', 'Б-9: мост J5-EXT — CANON UNRESOLVED, PASSED-EXT, знак Y за мостом [Г, мост]');
  // кандидаты: ветви совпадают и расходятся; предел n_max
  const tri = (s3, ex) => K.j5Graph({ vertices: ['a', 'b', 'c'], edges: [
    { a: 'a', b: 'b', cls: 'LINK', existence: 'IMPOSED', reading: 'J5-CANON', sign: -1 }, { a: 'b', b: 'c', cls: 'LINK', existence: 'IMPOSED', reading: 'J5-CANON', sign: -1 },
    { a: 'a', b: 'c', cls: 'CONTACT-ONLY', existence: ex, reading: 'J5-CANON', sign: s3 }] });
  const div = tri(-1, 'CANDIDATE'), same = tri(1, 'CANDIDATE');
  ok(div.canon.verdict === 'UNRESOLVED' && div.branches.length === 2 && /расходятся/.test(div.canon.reason), 'K-1: ветви расходятся — UNRESOLVED');
  ok(same.canon.verdict === 'PASSED' && /совпали/.test(same.canon.reason), 'K-1: ветви совпали — вердикт с пометкой');
  const many = K.j5Graph({ vertices: ['a', 'b'], edges: Array.from({ length: 9 }, () => ({ a: 'a', b: 'b', cls: 'CONTACT-ONLY', existence: 'CANDIDATE', reading: 'J5-CANON', sign: 1 })) });
  ok(many.canon.verdict === 'UNRESOLVED' && /n_max/.test(many.canon.reason), 'K-1: кандидатов больше n_max — UNRESOLVED');
}

// 3. Базовые случаи через K.run
const runs = {};
const R = (nm, cs) => (runs[nm] = runs[nm] || K.run({ id: nm, ...cs }));
{
  const k1 = R('К1', thread([]));
  ok(k1.verdict.geometry === 'PASSED' && k1.j5.canon.verdict === 'PASSED' && k1.j5.ext.verdict === 'PASSED-EXT', 'К1: геометрия PASSED, J5-CANON PASSED, PASSED-EXT');
  ok(k1.contacts.length === 4 && k1.contacts.every(c => c.existence === 'IMPOSED' && c.parallel === 'PARALLEL-ESTABLISHED' && c.type === 'SIDE' && c.reading === 'J5-CANON' && c.sign === -1 && has(c.points[0].cos, -1, 1e-12) && c.contact_class === 'STRUCTURAL'), 'К1: четыре касания LINK — П-6, П-7, J5-CANON, cos = −1');
  ok(k1.checks.filter(c => c.req === 'G-3').every(c => c.value[0] === 2 && c.value[1] === 2 && c.completeness === 'EXACT'), 'К1: d = 2 точно (G-3)');
  ok(k1.checks.filter(c => c.req === 'G-4' && c.existence === 'SEPARATED').length === 6, 'К1: несоседние пары SEPARATED');
  const k2 = R('К2 (i)', thread([{ host: 2, side: 1, coords: 'rho-psi', rho: 0, psi: 0, delta: 0 }]));
  ok(k2.verdict.geometry === 'PASSED' && k2.j5.canon.verdict === 'PASSED', 'К2 (i): геометрия PASSED, J5-CANON PASSED');
  ok(k2.configuration.triples.length === 2 && k2.configuration.triples.every(t => has(t.value, 1, 1e-9)), 'А-2: тройка = 1 (G-8, факультативно)');
  const k3 = R('К3', thread([fix({ coords: 'rho-psi', rho: null, psi: 0 }, 'rho', 'T1', [29.5, 30.5])]));
  const tri = [ct(k3, 'T1', 'T2'), ct(k3, 'T2', 'H1'), ct(k3, 'T1', 'H1')];
  ok(k3.verdict.geometry === 'PASSED' && k3.j5.canon.verdict === 'FORBIDDEN' && tri.every(c => c.reading === 'J5-CANON' && has(c.points[0].cos, -1, 1e-5)), 'Б-1: К3 — cos = −1 на трёх рёбрах, J5-CANON FORBIDDEN, геометрия PASSED');
  ok(ct(k3, 'T1', 'H1').cls === 'CONTACT-ONLY' && ct(k3, 'T1', 'H1').contact_class === 'ALLOWED CONTACT' && ct(k3, 'T1', 'H1').basis.rule === 'П-8б', 'К3: касание предыдущий–навес — CONTACT-ONLY, ALLOWED CONTACT, П-8б');
  const b8 = R('Б-8', thread([{ host: 2, side: 1, coords: 'rho-psi', rho: 30, psi: 0, delta: 0 }]));
  ok(ct(b8, 'T1', 'H1').existence === 'CANDIDATE' && b8.j5.canon.verdict === 'UNRESOLVED' && b8.j5.branches.length === 2
    && b8.j5.branches.some(b => b.canon === 'FORBIDDEN') && b8.j5.branches.some(b => b.canon === 'PASSED'), 'Б-8: кандидат — ветви FORBIDDEN / PASSED, итог UNRESOLVED');
  ok(b8.verdict.geometry === 'UNRESOLVED' && b8.checks.find(c => c.id === 'G4:T1:H1').verdict === 'UNRESOLVED', 'Б-8: геометрия UNRESOLVED — проникновение у кандидата не исключено');
  const b3 = R('Б-3', thread([fix({ coords: 'alpha-lambda', alpha: 52, lambda: null }, 'lambda', 'T1', [20, 35])]));
  const pb = ct(b3, 'T1', 'H1');
  ok(pb.reading === 'J5-EXT' && pb.sign === 1 && Math.abs(iv.mid(pb.points[0].cos) - 0.051) < 0.001 && pb.epsilon < 0.051, `Б-3: cos ${iv.mid(pb.points[0].cos)} (Э-П +0,051), ε ${pb.epsilon} < 0,051 — знак есть`);
  ok(ct(b3, 'T2', 'H1').parallel === 'NON-PARALLEL' && b3.j5.canon.verdict === 'UNRESOLVED' && b3.j5.ext.verdict === 'PASSED-EXT', 'Б-3: хозяин–навес NON-PARALLEL; CANON UNRESOLVED; PASSED-EXT');
  if (!process.env.KT1_QUICK) {
    const k4 = R('К4', thread([fix({ coords: 'rho-psi', rho: null, psi: 54, delta: 10 }, 'rho', 'T1', [56.0, 58.5])]));
    const ph = ct(k4, 'T1', 'H1'), hh = ct(k4, 'T2', 'H1'), hp = ct(k4, 'T1', 'T2');
    ok(k4.verdict.geometry === 'PASSED' && k4.j5.canon.verdict === 'UNRESOLVED' && k4.j5.ext.verdict === 'PASSED-EXT', 'Б-2: К4 — геометрия PASSED, CANON UNRESOLVED, PASSED-EXT');
    ok(ph.reading === 'J5-EXT' && ph.parallel === 'NON-PARALLEL' && ph.sign === 1 && Math.abs(iv.mid(ph.points[0].cos) - 0.1247) < 1e-4, `Б-2: cos предыдущий–навес ${iv.mid(ph.points[0].cos)} (Э-П +0,1247)`);
    ok(hh.reading === 'J5-EXT' && hh.sign === -1 && has(hh.points[0].cos, -1, 1e-4) && hp.reading === 'J5-CANON' && hp.sign === -1, 'Б-2: хозяин–навес J5-EXT, −1; хозяин–предыдущий J5-CANON, −1');
    // Э-М: зеркальная пара К4 даёт тот же косинус
    const k4m = R('К4 зерк.', thread([fix({ coords: 'rho-psi', rho: null, psi: 306, delta: -10 }, 'rho', 'T1', [56.0, 58.5])]));
    const pm = ct(k4m, 'T1', 'H1');
    ok(pm && Math.abs(iv.mid(pm.points[0].cos) - iv.mid(ph.points[0].cos)) < 1e-9 && k4m.j5.ext.verdict === 'PASSED-EXT', `Э-М: ψ = 306°, δ = −10° — тот же косинус (${pm && iv.mid(pm.points[0].cos)})`);
  }
}

// 4. Синтетические входы (§ 4.3)
{
  const pair = (T2, extra = {}) => ({ tori: [{ name: 'S1', A: [0, 0, 0], T: [0, 1, 0] }, { name: 'S2', A: [2, 0, 0], T: T2 }],
    declare: [{ kind: 'symmetry', pair: ['S1', 'S2'], contact: 'IMPOSED', basis: 'synthetic' }], ...extra });
  const ring = { rings: [{ name: 'Q1', C: [1, 0, 0], E1: [1, 0, 0], E2: [0, 1, 0], s1: 1, s2: 1, threads: ['S1', 'S2'] }] };
  const b10 = R('Б-10', pair([0, 2, 0], ring));
  const c10 = b10.contacts[0];
  ok(c10.existence === 'IMPOSED' && c10.parallel === 'PARALLEL-UNCERTAIN' && c10.reading === 'J5-CLASS-UNRESOLVED' && b10.j5.ext.verdict === 'PASSED-EXT' && b10.j5.canon.verdict === 'UNRESOLVED', 'Б-10 / м5 (i): PARALLEL-UNCERTAIN, J5-CLASS-UNRESOLVED, PASSED-EXT, CANON UNRESOLVED');
  const m5ii = R('м5 (ii)', pair([0, 1, 0.1]));
  ok(m5ii.contacts[0].parallel === 'NON-PARALLEL' && m5ii.contacts[0].type === 'UNDETERMINED' && m5ii.contacts[0].reading === 'J5-EXT' && m5ii.contacts[0].sign === -1, 'м5 (ii): NON-PARALLEL, UNDETERMINED, J5-EXT, −1');
  const own3 = R('Own 3', pair({ sameAs: 'S1' }, ring));
  ok(own3.contacts[0].parallel === 'PARALLEL-ESTABLISHED' && own3.contacts[0].type === 'UNDETERMINED' && own3.contacts[0].reading === 'J5-CLASS-UNRESOLVED' && own3.j5.canon.verdict !== 'PASSED', 'Own 3: П-6 по sameAs, тип не объявлен — J5-CLASS-UNRESOLVED');
  const typed = R('тип объявлен', { ...pair({ sameAs: 'S1' }, ring), declare: [{ kind: 'symmetry', pair: ['S1', 'S2'], contact: 'IMPOSED', basis: 'synthetic' }, { kind: 'type', pair: ['S1', 'S2'], type: 'SIDE', basis: 'synthetic' }] });
  ok(typed.contacts[0].reading === 'J5-CANON' && typed.j5.canon.verdict === 'PASSED', 'sameAs + объявленный SIDE — J5-CANON, PASSED');
  const opp = R('oppositeOf', { ...pair({ oppositeOf: 'S1' }, { rings: [{ ...ring.rings[0], threads: ['S1'] }] }), declare: [{ kind: 'symmetry', pair: ['S1', 'S2'], contact: 'IMPOSED', basis: 'synthetic' }, { kind: 'type', pair: ['S1', 'S2'], type: 'SIDE', basis: 'synthetic' }] });
  ok(opp.contacts[0].parallel === 'PARALLEL-ESTABLISHED' && opp.contacts[0].sign === 1, 'oppositeOf: ось обращена — знак ребра +1 (ориентация осей, интерфейс § 2)');
  ok(opp.contacts[0].cls === 'CONTACT-ONLY' && opp.contacts[0].contact_class === 'ALLOWED CONTACT', 'без общего кольца — CONTACT-ONLY, ALLOWED CONTACT');
  // input_error
  const bad = [
    ['вид объявления', { ...pair([0, 1, 0]), declare: [{ kind: 'force', pair: ['S1', 'S2'], basis: 'x' }] }],
    ['ортонормированность', { ...pair([0, 1, 0]), rings: [{ name: 'Q', C: [1, 0, 0], E1: [1, 0.1, 0], E2: [0, 1, 0], s1: 1, s2: 1, threads: [] }] }],
    ['threads с наклонной осью', { ...pair([0, 1, 0.1]), rings: [{ name: 'Q', C: [1, 0, 0], E1: [1, 0, 0], E2: [0, 1, 0], s1: 1, s2: 1, threads: ['S1', 'S2'] }] }],
    ['цикл ссылок', { tori: [{ name: 'a', A: [0, 0, 0], T: { sameAs: 'b' } }, { name: 'b', A: [2, 0, 0], T: { sameAs: 'a' } }] }],
    ['нет параметра', thread([{ host: 2, side: 1, coords: 'rho-psi', rho: 0, delta: 0 }])],
    ['thread и tori', { ...thread([]), tori: [] }],
  ];
  for (const [nm, cs] of bad) { const p = K.run(cs); ok(p.input_error && !p.verdict, `input_error: ${nm} — ${p.input_error || JSON.stringify(p.verdict)}`); }
  const un = K.run(thread([fix({ coords: 'rho-psi', rho: null, psi: 0 }, 'rho', 'T1', [40, 50])]));
  ok(un.verdict && un.verdict.geometry === 'UNRESOLVED' && un.checks[0].id === 'build' && K.validate(un).length === 0, `корня нет в вилке — UNRESOLVED с причиной: ${un.checks && un.checks[0].reason}`);
}

// 5. Протокол: схема, детерминированность, консоль
{
  for (const [nm, p] of Object.entries(runs)) {
    const v = K.validate(p);
    ok(v.length === 0, `${nm}: validate — ${v.join('; ')}`);
    ok(p.interface === 6 && p.declared.kappa_min === 0.05 && p.declared.theta_min_deg === 1 && p.declared.n_max_candidates === 8, `${nm}: declared`);
    ok(p.checks.every(c => !(c.verdict === 'PASSED' && !['EXACT', 'CERTIFIED'].includes(c.completeness))), `${nm}: PASSED только при EXACT / CERTIFIED`);
    ok(!JSON.stringify(p).includes('null,null]') && p.checks.every(c => Number.isFinite(c.value[0]) && Number.isFinite(c.value[1])), `${nm}: вилки конечны (±∞ заменены)`);
  }
  const cs = { id: 'K1', ...thread([]) };
  ok(K.serialize(K.run(cs)) === K.serialize(K.run(cs)), 'прогон детерминирован');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kt1-'));
  const f = path.join(dir, 'k1.json'); fs.writeFileSync(f, JSON.stringify(cs));
  const out = execFileSync(process.execPath, [path.join(__dirname, '..', 'kt1.js'), f], { encoding: 'utf8' });
  ok(out.trim() === K.serialize(K.run(cs)), 'консоль и K.run — побитно один протокол');
  fs.writeFileSync(f, JSON.stringify(thread([{ host: 9, side: 1, coords: 'rho-psi', rho: 0, psi: 0, delta: 0 }])));
  let code = 0; try { execFileSync(process.execPath, [path.join(__dirname, '..', 'kt1.js'), f], { encoding: 'utf8' }); } catch (e) { code = e.status; }
  ok(code === 2, `консоль: неправильный вход — код 2 (${code})`);
  fs.writeFileSync(f, '{ не json');
  code = 0; try { execFileSync(process.execPath, [path.join(__dirname, '..', 'kt1.js'), f], { encoding: 'utf8' }); } catch (e) { code = e.status; }
  ok(code === 2, `консоль: файл не JSON — код 2 (${code})`);
  fs.rmSync(dir, { recursive: true, force: true });
  // библиотечные точки на числовом входе § 4.3
  const g = K.torusGap({ A: [0, 0, 0], T: [0, 1, 0] }, { A: [3, 0, 0], T: [0, 1, 0] });
  ok(has(g.gap, 1, 1e-12), `K.torusGap: зазор 1 у торов на расстоянии 3: ${g.gap}`);
  const rr = K.ringRing({ C: [0, 0, -1], E1: [0, 0, 1], E2: [0, 1, 0], s1: 1, s2: 1 }, { C: [0, 0, -0.01], E1: [0, 0, 1], E2: [0, 1, 0], s1: 0.01, s2: 1.5 }, { A: [0, 0, 0], T: [0, 1, 0] });
  ok(rr.contact_class === 'UNRESOLVED CONTACT', 'K.ringRing (м2а) на числовом входе — UNRESOLVED CONTACT');
  const rt = K.ringTorus({ C: [0, 0, -0.2], E1: [0, 0, 1], E2: [0, 1, 0], s1: 0.2, s2: 0.1 }, { A: [0, 0, 0], T: [0, 1, 0] }, true);
  ok(rt.verdict === 'FORBIDDEN', 'K.ringTorus (м2б) на числовом входе — FORBIDDEN');
}

console.log(`WP-4: ${pass} прошло, ${fail} не прошло`);
if (fail) { console.log(fails.slice(0, 30).join('\n')); process.exit(1); }
