'use strict';
// Рабочие проверки исполнителя по WP-3: кольца 1D–1D (R-1, R-2, R-4, R-5, R-6) и G-6. Не приёмочный набор.
const iv = require('../wp0_interval');
const vec = require('../wp1_vec');
const { build, frame } = require('../wp1_build');
const { ThreadError } = require('../wp2_ringtorus');
const W = require('../wp3_rings');

let pass = 0, fail = 0; const fails = [];
const ok = (c, m) => { if (c) pass++; else { fail++; fails.push(m); } };
const has = (v, x, slack = 0) => v[0] - slack <= x && x <= v[1] + slack;
const F = x => iv.fromInput(x), V3 = a => a.map(F);
const syn = (name, o) => ({ name, C: V3(o.C), E1: V3(o.E1), E2: V3(o.E2), s1: F(o.s1), s2: F(o.s2), completeness: 'CERTIFIED', annulus: false, width_max: 0, ...(o.extra || {}) });
const circ = (name, C, E1, E2, r) => syn(name, { C, E1, E2, s1: r, s2: r });
const cusp = (A, T, name = 'T') => ({ A: V3(A), T: V3(T), name });

// Интеграл Гаусса по выборке — независимая проверка Lk (R-7 — только перекрёстная проверка, не критерий).
function gaussLk(r1, r2, N = 300) {
  const m = r => ({ C: vec.vmid(r.C), E1: vec.vmid(r.E1), E2: vec.vmid(r.E2), a: iv.mid(r.s1), b: iv.mid(r.s2) });
  const A = m(r1), B = m(r2), h = 2 * Math.PI / N;
  const P = (q, t) => [0, 1, 2].map(k => q.C[k] + q.a * Math.cos(t) * q.E1[k] + q.b * Math.sin(t) * q.E2[k]);
  const D = (q, t) => [0, 1, 2].map(k => -q.a * Math.sin(t) * q.E1[k] + q.b * Math.cos(t) * q.E2[k]);
  let s = 0;
  for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) {
    const ti = (i + 0.5) * h, tj = (j + 0.5) * h, a = P(A, ti), b = P(B, tj), da = D(A, ti), db = D(B, tj);
    const r = [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
    const c = [da[1] * db[2] - da[2] * db[1], da[2] * db[0] - da[0] * db[2], da[0] * db[1] - da[1] * db[0]];
    s += (r[0] * c[0] + r[1] * c[1] + r[2] * c[2]) / Math.hypot(...r) ** 3;
  }
  return s * h * h / (4 * Math.PI);
}
// Наименьшее расстояние между кольцами по выборке
function sampledDist(r1, r2, N = 1500) {
  const m = r => ({ C: vec.vmid(r.C), E1: vec.vmid(r.E1), E2: vec.vmid(r.E2), a: iv.mid(r.s1), b: iv.mid(r.s2) });
  const A = m(r1), B = m(r2), P = (q, t) => [0, 1, 2].map(k => q.C[k] + q.a * Math.cos(t) * q.E1[k] + q.b * Math.sin(t) * q.E2[k]);
  const pa = Array.from({ length: N }, (_, i) => P(A, 2 * Math.PI * i / N)), pb = Array.from({ length: N }, (_, i) => P(B, 2 * Math.PI * i / N));
  let d = Infinity; for (const a of pa) for (const b of pb) d = Math.min(d, Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]));
  return d;
}

// 1. Построенные базовые случаи
const mirror5 = Array.from({ length: 5 }, () => ({ theta: 0, phi: 0, delta: 0 }));
const fix = (psi, delta, br) => ({ host: 2, side: 1, coords: 'rho-psi', rho: null, psi, delta, fix: { kind: 'contact', free: 'rho', with: 'T1', bracket: br } });
const cases = [['К1', []], ['К2 (i)', [{ host: 2, side: 1, coords: 'rho-psi', rho: 0, psi: 0, delta: 0 }]], ['К3', [fix(0, 0, [29.5, 30.5])]]];
if (!process.env.KT1_QUICK) cases.push(['К4', [fix(54, 10, [56.0, 58.5])]]);
for (const [nm, hangs] of cases) {
  const c = build({ thread: { n: 5, links: mirror5 }, hangs });
  const r = W.ringChecks(c, frame);
  const n = c.rings.length;
  ok(r.pairs.length === n * (n - 1) / 2, `${nm}: каждая пара колец разобрана ровно один раз`);
  const exactOf = p => p.objects.every(o => c.rings.find(x => x.name === o).completeness === 'EXACT') ? 'EXACT' : 'CERTIFIED';
  ok(r.pairs.every(p => p.verdict === 'PASSED' && p.completeness === exactOf(p)), `${nm}: все пары колец PASSED; EXACT только при точных кольцах, иначе CERTIFIED`);
  ok(r.pairs.filter(p => p.req === 'R-4').every(p => p.plane_basis && p.plane_basis.evidence && Object.values(p.plane_basis.rings).every(Boolean)), `${nm}: у R-4 — основание одной плоскости`);
  ok(r.degenerate.length === 0, `${nm}: R-6 нет`);
  const adj = r.pairs.filter(p => /^R\d$/.test(p.objects[0]) && /^R\d$/.test(p.objects[1]) && Math.abs(+p.objects[0].slice(1) - +p.objects[1].slice(1)) === 1);
  ok(adj.every(p => p.req === 'R-1' && p.contact_class === 'STRUCTURAL' && has(p.value, 180, 1e-9)), `${nm}: смежные кольца нити — R-1, 180°, STRUCTURAL`);
  const nonadj = r.pairs.filter(p => /^R\d$/.test(p.objects[0]) && /^R\d$/.test(p.objects[1]) && Math.abs(+p.objects[0].slice(1) - +p.objects[1].slice(1)) > 1);
  ok(nonadj.every(p => p.req === 'R-4' && p.value[0] > 0 && p.separating_direction), `${nm}: несмежные кольца нити — R-4, разделяющее направление найдено`);
  ok(r.threadingChecks.every(p => p.verdict === 'PASSED'), `${nm}: G-6 — A-15 и Lk с осевыми окружностями PASSED`);
  ok(r.threadingChecks.filter(p => p.id.startsWith('G6:')).every(p => Math.abs(p.lk) === 1), `${nm}: |Lk| = 1 с осевой окружностью каждого продетого тора`);
  if (nm === 'К1') {
    ok(r.threadingChecks.filter(p => p.id.startsWith('A15:')).every(p => p.value[0] <= 2), 'К1: в отверстиях не больше двух колец');
    ok(r.pairs.filter(p => p.req === 'R-4').every(p => has(p.value, 2 * (Math.abs(+p.objects[0].slice(1) - +p.objects[1].slice(1)) - 1), 1e-12)), 'К1: запас разделения R-4 = 2(k − 1) (закрытая форма)');
  }
  if (nm !== 'К1') {
    const a15 = r.threadingChecks.find(p => p.id === 'A15:T2');
    ok(a15.value[0] === 3 && a15.verdict === 'PASSED', `${nm}: в отверстии хозяина три кольца — A-15 PASSED`);
    const hp = r.pairs.filter(p => p.objects.includes('RH1') && p.req === 'R-1');
    ok(hp.length === 2 && hp.every(p => p.cusp === 'T2'), `${nm}: кольцо навеса — общий касп с R1 и R2`);
    const r2 = r.pairs.filter(p => p.objects.includes('RH1') && p.req === 'R-2');
    ok(r2.length === 3 && r2.every(p => p.lk === 0), `${nm}: кольцо навеса с несмежными — R-2 EXACT, Lk = 0`);
    const ang = Object.fromEntries(hp.map(p => [p.objects[0], p.halfplane_angles]));
    if (nm === 'К2 (i)') {
      // А-2: полуплоскости −90° / 0° / +90°, допуск 10⁻⁶ °
      ok(has(ang.R1[0], -90, 1e-6) && has(ang.R1[1], 0, 1e-6) && has(ang.R2[0], 90, 1e-6), `А-2: полуплоскости R1 / RH1 / R2 = −90° / 0° / +90°: ${JSON.stringify(ang)}`);
      ok(hp.every(p => has(p.value, 90, 1e-9)), 'К2 (i): R-1 90°');
    }
    if (nm === 'К3') ok(has(ang.R1[1], -30, 1e-6), `К3: полуплоскость навеса −30°: ${ang.R1[1]}`);
    if (nm === 'К4') {
      const mn = Math.min(...hp.map(p => iv.mid(p.value)));
      ok(Math.abs(mn - 47.6) < 0.05, `К4: наименьший угол R-1 ${mn}° (спецификация § 2.10: 47,6°)`);
      console.log(`К4: углы R-1 у навеса ${hp.map(p => `${p.objects[0]} ${iv.mid(p.value).toFixed(6)}°`).join(', ')}`);
      ok([...hp, ...r2].every(p => p.completeness === 'CERTIFIED'), 'К4: пары с кольцом навеса общего вида — CERTIFIED');
    }
  }
}

// 2. м2а — общий касп, одна полуплоскость (кольца пересекаются вне каспа): не PASSED
{
  const r1 = syn('r1', { C: [0, 0, -1], E1: [0, 0, 1], E2: [0, 1, 0], s1: 1, s2: 1 });
  const r2 = syn('r2', { C: [0, 0, -0.01], E1: [0, 0, 1], E2: [0, 1, 0], s1: 0.01, s2: 1.5 });
  const c = W.ringRing(r1, r2, cusp([0, 0, 0], [0, 1, 0]));
  ok(c.req === 'R-1' && c.verdict === 'UNRESOLVED' && c.contact_class === 'UNRESOLVED CONTACT', `м2а: одна полуплоскость — UNRESOLVED CONTACT: ${c.verdict} ${c.contact_class}`);
  // те же кольца, но второе в другой полуплоскости — STRUCTURAL
  const r3 = syn('r3', { C: [0, 0, 0.01], E1: [0, 0, 1], E2: [0, 1, 0], s1: 0.01, s2: 1.5 });
  const d = W.ringRing(r1, r3, cusp([0, 0, 0], [0, 1, 0]));
  ok(d.verdict === 'PASSED' && d.contact_class === 'STRUCTURAL' && has(d.value, 180, 1e-9), 'R-1: противоположные полуплоскости — STRUCTURAL, 180°');
  let te = false; try { W.ringRing(r1, syn('bad', { C: [0, 0, 0.5], E1: [0, 0, 1], E2: [0, 1, 0], s1: 1, s2: 1 }), cusp([0, 0, 0], [0, 1, 0])); } catch (e) { te = e instanceof ThreadError; }
  ok(te, 'R-1: кольцо не проходит через касп — отказ (несовместимая посылка)');
}

// 3. R-2: сцепление и его знак против интеграла Гаусса
{
  const a = circ('A', [0, 0, 0], [1, 0, 0], [0, 1, 0], 1);
  const b = circ('B', [1, 0, 0], [1, 0, 0], [0, 0, 1], 1);        // зацепление Хопфа
  const c = W.ringRing(a, b, null);
  const g = gaussLk(a, b);
  ok(c.req === 'R-2' && c.verdict === 'PASSED' && Math.abs(c.lk) === 1 && Math.abs(g - c.lk) < 1e-3, `Хопф: Lk ${c.lk}, Гаусс ${g.toFixed(6)}`);
  const c2 = W.ringRing(b, a, null);
  ok(c2.lk === c.lk, `Хопф: Lk симметричен (${c2.lk})`);
  const bf = { ...b, E2: V3([0, 0, -1]) };                         // обратная ориентация второго кольца
  ok(W.ringRing(a, bf, null).lk === -c.lk, 'Хопф: обращение ориентации меняет знак Lk');
  const far = circ('C', [3, 0, 0], [1, 0, 0], [0, 0, 1], 1);
  const cf = W.ringRing(a, far, null);
  ok(cf.verdict === 'PASSED' && cf.lk === 0 && Math.abs(gaussLk(a, far)) < 1e-3, `несцепленные: Lk 0 (${cf.lk_basis})`);
  const both = circ('D', [0, 0, 0], [1, 0, 0], [0, 0, 1], 0.5);   // хорда внутри хорды: два прокола, Lk 0
  const cb = W.ringRing(a, both, null);
  ok(cb.verdict === 'PASSED' && cb.lk === 0 && cb.indicators.rho.every(x => x === true), `две точки кольца внутри диска — Lk 0: ${JSON.stringify(cb.indicators)}`);
}

// 3а. Кольцевая область (annulus, § 6.5): ориентация осей не установлена, радиусы в вилке
{
  const a = circ('A', [0, 0, 0], [1, 0, 0], [0, 1, 0], 1);
  const ann = { ...circ('Bann', [1, 0, 0], [1, 0, 0], [0, 0, 1], 1), s1: [0.98, 1.02], s2: [0.98, 1.02], annulus: true, width_max: 0.04 };
  const c = W.ringRing(a, ann, null);
  ok(c.req === 'R-2' && c.verdict === 'PASSED' && Math.abs(c.lk) === 1, `annulus: Хопф — R-2 PASSED, Lk ${c.lk}`);
  const touch = { ...circ('Bt', [2, 0, 0], [1, 0, 0], [0, 0, 1], 1), s1: [0.98, 1.02], s2: [0.98, 1.02], annulus: true, width_max: 0.04 };
  const ct = W.ringRing(a, touch, null);
  ok(ct.verdict === 'UNRESOLVED' && ct.contact_class === 'UNRESOLVED CONTACT', 'annulus у точки встречи — UNRESOLVED CONTACT (правило полной вилки)');
  const cu = { ...circ('Bc', [0, 0, 1], [0, 0, 1], [0, 1, 0], 1), s1: [0.999, 1.001], s2: [0.999, 1.001], annulus: true, width_max: 0.002 };
  const r1 = syn('r1', { C: [0, 0, -1], E1: [0, 0, 1], E2: [0, 1, 0], s1: 1, s2: 1 });
  const d = W.ringRing(r1, cu, cusp([0, 0, 0], [0, 1, 0]));
  ok(d.req === 'R-1' && d.verdict === 'PASSED' && has(d.value, 180, 1e-9), 'annulus: R-1 по центру области — STRUCTURAL, 180°');
}

// 4. R-2: статические встречи и R-6
{
  const a = circ('a', [0, 0, 0], [1, 0, 0], [0, 1, 0], 1);         // z = 0
  const b = circ('b', [2, 0, 0], [1, 0, 0], [0, 0, 1], 1);         // y = 0, встреча с a в (1, 0, 0), поперечная
  const c = circ('c', [1, 1, 0], [0, 1, 0], [0, 0, 1], 1);         // x = 1, касается прямой y-оси a·c в (1, 0, 0)
  const ab = W.ringRing(a, b, null), ac = W.ringRing(a, c, null), bc = W.ringRing(b, c, null);
  ok(ab.verdict === 'UNRESOLVED' && ab.contact_class === 'UNRESOLVED CONTACT' && ab.meeting.local_type.length === 1 && ab.meeting.local_type[0] === 'поперечная', `встреча a–b поперечная: ${JSON.stringify(ab.meeting && ab.meeting.local_type)}`);
  ok(has(ab.meeting.at[0].point[0], 1) && has(ab.meeting.at[0].point[1], 0) && has(ab.meeting.at[0].point[2], 0), 'встреча a–b: вилка точки содержит (1, 0, 0)');
  ok(ac.contact_class === 'UNRESOLVED CONTACT' && ac.meeting.local_type.includes('полукасательная'), `встреча a–c: полукасательная не исключена: ${JSON.stringify(ac.meeting && ac.meeting.local_type)}`);
  ok(bc.contact_class === 'UNRESOLVED CONTACT' && bc.meeting.local_type.includes('двукасательная'), `встреча b–c: двукасательная не исключена: ${JSON.stringify(bc.meeting && bc.meeting.local_type)}`);
  ok(typeof ab.meeting.at[0].epsilon_l === 'number' && ab.meeting.at[0].epsilon_l < 1e-12, `ε_ℓ печатается: ${ab.meeting.at[0].epsilon_l}`);
  const dm = W.degenerateMeetings([ab, ac, bc]);
  ok(dm.length === 1 && dm[0].contact_class === 'DEGENERATE MEETING' && dm[0].verdict === 'UNRESOLVED', 'R-6: три кольца в одной точке — DEGENERATE MEETING');
  const d = circ('d', [2, 0, 0.001], [1, 0, 0], [0, 0, 1], 1);    // b, сдвинутое на 10⁻³: встречи нет
  const ad = W.ringRing(a, d, null);
  ok(ad.verdict === 'PASSED' && ad.value[0] > 0, `сдвиг на 10⁻³ — встречи нет, запас ${ad.value}`);
}

// 5. R-5: почти параллельные плоскости и θ_min
{
  const tilt = (deg, C) => { const t = deg * Math.PI / 180; return syn('b', { C, E1: [1, 0, 0], E2: [0, Math.cos(t), Math.sin(t)], s1: 1, s2: 1 }); };
  const a = circ('a', [0, 0, 0], [1, 0, 0], [0, 1, 0], 1);
  const p = W.ringRing(a, tilt(W.THETA_MIN_DEG / 2, [0.3, 0.2, 0.5]), null);
  ok(p.req === 'R-5' && p.case === 'near-parallel' && p.verdict === 'UNRESOLVED', `угол θ_min/2 — R-5 near-parallel: ${p.case}`);
  const q = W.ringRing(a, tilt(2 * W.THETA_MIN_DEG, [0.3, 0.2, 0.5]), null);
  ok(q.req === 'R-2' && q.verdict === 'PASSED', `угол 2θ_min — R-2 ${q.verdict}`);
  const cop = W.ringRing(a, circ('e', [5, 0, 0], [1, 0, 0], [0, 1, 0], 1), null);
  ok(cop.req === 'R-5' && cop.verdict === 'UNRESOLVED', 'одна плоскость без тождества построения — R-5 UNRESOLVED');
}

// 6. R-4: одна плоскость по построению (plane_class)
{
  const pc = { extra: { plane_class: 7 } };
  const a = syn('a', { C: [0, 0, 0], E1: [1, 0, 0], E2: [0, 1, 0], s1: 2, s2: 1, ...pc });
  const b = syn('b', { C: [3.5, 0.2, 0], E1: [0.6, 0.8, 0], E2: [-0.8, 0.6, 0], s1: 1.2, s2: 0.4, ...pc });
  const r = W.ringRing(a, b, null);
  ok(r.req === 'R-4' && r.verdict === 'PASSED' && r.case === 'coplanar', `R-4: разнесённые эллипсы — PASSED, запас ${r.value}`);
  const nest = syn('n', { C: [0.1, 0, 0], E1: [1, 0, 0], E2: [0, 1, 0], s1: 0.5, s2: 0.3, ...pc });
  const rn = W.ringRing(a, nest, null);
  ok(rn.req === 'R-4' && rn.verdict === 'UNRESOLVED' && /TB-4/.test(rn.reason), 'R-4: вложенные эллипсы — UNRESOLVED (TB-4)');
}

// 7. G-6: A-15 и Lk с осевой окружностью
{
  const T = { name: 'T', A: V3([0, 0, 0]), T: V3([0, 1, 0]) };
  const ring = (nm, ph) => syn(nm, { C: [Math.cos(ph), 0, Math.sin(ph)], E1: [Math.cos(ph), 0, Math.sin(ph)], E2: [0, 1, 0], s1: 1, s2: 1, extra: { threads: ['T'] } });
  const rs = [0, 1, 2, 3].map(k => ring(`q${k}`, k * Math.PI / 2 + 0.1));
  const g3 = W.threadingGraph(rs.slice(0, 3), [T]), g4 = W.threadingGraph(rs, [T]);
  ok(g3.checks.find(c => c.id === 'A15:T').verdict === 'PASSED', 'A-15: три кольца в отверстии — PASSED');
  ok(g4.checks.find(c => c.id === 'A15:T').verdict === 'FORBIDDEN', 'A-15: четыре кольца в отверстии — FORBIDDEN');
  ok(g4.checks.filter(c => c.id.startsWith('G6:')).every(c => c.verdict === 'PASSED' && Math.abs(c.lk) === 1), 'G-6: Lk = ±1 у колец радиуса 1');
  const small = syn('s', { C: [0.2, 0, 0], E1: [1, 0, 0], E2: [0, 1, 0], s1: 0.2, s2: 0.6, extra: { threads: ['T'] } });
  const gs = W.ringAxialLk(small, T);
  ok(gs.verdict === 'UNRESOLVED' && gs.lk === 0, 'G-6: вторая точка внутри диска осевой окружности — Lk = 0, UNRESOLVED');
  // Lk с осевой окружностью против интеграла Гаусса
  const axial = circ('ax', [0, 0, 0], [0, 0, 1], [1, 0, 0], 0.5);  // ориентация против часовой стрелки вокруг +y: e_z → e_x
  const g = gaussLk(rs[0], axial), l = W.ringAxialLk(rs[0], T).lk;
  ok(Math.abs(g - l) < 1e-3, `G-6: Lk ${l} против интеграла Гаусса ${g.toFixed(6)}`);
}

// 8. Опровергающая проверка на случайных парах: PASSED R-2 — выборка не находит встречи, Lk совпадает с Гауссом
{
  let seed = 5; const rnd = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; };
  const unit = v => { const n = Math.hypot(...v); return v.map(x => x / n); };
  const cr = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const rr = nm => { const n = unit([rnd() - .5, rnd() - .5, rnd() - .5]), e1 = unit(cr(n, [rnd() - .5, rnd() - .5, rnd() - .5])), e2 = cr(n, e1);
    return syn(nm, { C: [2 * rnd() - 1, 2 * rnd() - 1, 2 * rnd() - 1], E1: e1, E2: e2, s1: 0.4 + rnd(), s2: 0.4 + rnd() }); };
  let nP = 0, nL = 0, nU = 0, nM = 0;
  for (let i = 0; i < 120; i++) {
    const a = rr('a'), b = rr('b'), c = W.ringRing(a, b, null);
    if (c.req !== 'R-2') { nU++; continue; }
    if (c.verdict === 'PASSED') {
      nP++; if (c.lk !== 0) nL++;
      // при близком подходе колец (≈ 10⁻²) выборка 200 × 200 груба — тогда 1500 × 1500
      let g = gaussLk(a, b, 200);
      if (Math.abs(g - c.lk) >= 0.02) g = gaussLk(a, b, 1500);
      ok(Math.abs(g - c.lk) < 0.02, `случайная пара ${i}: Lk ${c.lk}, Гаусс ${g.toFixed(4)}`);
    } else if (c.meeting) nM++;
    else nU++;
  }
  ok(nP > 100 && nL > 10, `случайные пары: PASSED ${nP} (сцеплены ${nL}), встреч ${nM}, прочие ${nU}`);
  console.log(`Случайные пары R-2: PASSED ${nP} (Lk ≠ 0: ${nL}), встреч ${nM}, прочие ${nU}`);
  // пары со встречей по построению: кольцо b проходит через точку кольца a
  let mOK = 0;
  for (let i = 0; i < 40; i++) {
    const a = rr('a'), t = 2 * Math.PI * rnd();
    const P = [0, 1, 2].map(k => a.C[k][0] + a.s1[0] * Math.cos(t) * a.E1[k][0] + a.s2[0] * Math.sin(t) * a.E2[k][0]);
    const b0 = rr('b'), u = 2 * Math.PI * rnd();
    const Q = [0, 1, 2].map(k => b0.s1[0] * Math.cos(u) * b0.E1[k][0] + b0.s2[0] * Math.sin(u) * b0.E2[k][0]);
    const b = { ...b0, C: P.map((x, k) => [iv.nextDown(x - Q[k]), iv.nextUp(x - Q[k])]), width_max: 1e-15 };
    const c = W.ringRing(a, b, null);
    if (c.req === 'R-2' && c.verdict === 'UNRESOLVED' && c.contact_class === 'UNRESOLVED CONTACT') mOK++;
    else ok(c.req !== 'R-2' || c.verdict !== 'PASSED', `встреча по построению ${i}: R-2 дал ${c.verdict}`);
  }
  ok(mOK >= 35, `встречи по построению: UNRESOLVED CONTACT ${mOK} из 40`);
}

console.log(`WP-3: ${pass} прошло, ${fail} не прошло`);
if (fail) { console.log(fails.join('\n')); process.exit(1); }
