'use strict';
// HONC / Qf / R1 / КТ-1 — вилочные дуальные числа: значение и частные производные, все — вилки.
// Прямой режим автоматического дифференцирования на вилках: если переменные заданы вилками,
// результат — вилка значения функции и вилки её частных производных на всём ящике переменных.
// Это стандартное свойство: каждая операция переносит производную по правилу цепочки, а вилочная
// арифметика заключает значения правила цепочки на всём ящике. Используется в доводах единственности
// корней (G-3 незеркальное, уравнение касания): знак производной на ящике.
const iv = require('./wp0_interval');

// Дуальное число: { v: вилка, g: [вилки частных производных] }.
const C = (v, n) => ({ v, g: Array.from({ length: n }, () => iv.I(0)) });          // константа
const X = (v, i, n) => ({ v, g: Array.from({ length: n }, (_, k) => iv.I(k === i ? 1 : 0)) }); // переменная i
const lift = (a, n) => (Array.isArray(a) ? C(a, n) : a);
const map2 = (a, b, f) => a.g.map((_, k) => f(k));

function add(a, b) { return { v: iv.add(a.v, b.v), g: map2(a, b, k => iv.add(a.g[k], b.g[k])) }; }
function sub(a, b) { return { v: iv.sub(a.v, b.v), g: map2(a, b, k => iv.sub(a.g[k], b.g[k])) }; }
function neg(a) { return { v: iv.neg(a.v), g: a.g.map(iv.neg) }; }
function mul(a, b) { return { v: iv.mul(a.v, b.v), g: map2(a, b, k => iv.add(iv.mul(a.g[k], b.v), iv.mul(a.v, b.g[k]))) }; }
function scale(a, s) { return { v: iv.mul(a.v, s), g: a.g.map(x => iv.mul(x, s)) }; }   // s — вилка-константа
function div(a, b) {
  const q = iv.div(a.v, b.v);
  // (a/b)' = (a' − q·b')/b
  return { v: q, g: map2(a, b, k => iv.div(iv.sub(a.g[k], iv.mul(q, b.g[k])), b.v)) };
}
function sqr(a) { return { v: iv.sqr(a.v), g: a.g.map(x => iv.mul(iv.mul(iv.I(2), a.v), x)) }; }
function sqrt(a) {
  const s = iv.sqrt([Math.max(0, a.v[0]), a.v[1]]);
  // (√a)' = a'/(2√a); при вилке √a, содержащей 0, производная бесконечна — довод тогда не проходит, и это честно
  const den = iv.mul(iv.I(2), s);
  return { v: s, g: a.g.map(x => iv.div(x, den)) };
}
function sin(a) { const s = iv.sin(a.v), c = iv.cos(a.v); return { v: s, g: a.g.map(x => iv.mul(c, x)) }; }
function cos(a) { const s = iv.sin(a.v), c = iv.cos(a.v); return { v: c, g: a.g.map(x => iv.neg(iv.mul(s, x))) }; }

// Векторы из дуальных чисел.
const vlift = (v, n) => v.map(c => lift(c, n));
const vadd = (a, b) => [add(a[0], b[0]), add(a[1], b[1]), add(a[2], b[2])];
const vsub = (a, b) => [sub(a[0], b[0]), sub(a[1], b[1]), sub(a[2], b[2])];
const vscale = (a, s) => [mul(a[0], s), mul(a[1], s), mul(a[2], s)];        // s — дуальное
const vscaleI = (a, s) => [scale(a[0], s), scale(a[1], s), scale(a[2], s)]; // s — вилка
const dot = (a, b) => add(add(mul(a[0], b[0]), mul(a[1], b[1])), mul(a[2], b[2]));
const cross = (a, b) => [
  sub(mul(a[1], b[2]), mul(a[2], b[1])),
  sub(mul(a[2], b[0]), mul(a[0], b[2])),
  sub(mul(a[0], b[1]), mul(a[1], b[0])),
];
function normalize(a) {
  const n = sqrt(dot(a, a));
  if (n.v[0] <= 0) throw new Error('dual normalize: вектор может быть нулевым');
  return [div(a[0], n), div(a[1], n), div(a[2], n)];
}
const val = a => a.map(c => c.v);           // вектор значений
const grad = (a, k) => a.map(c => c.g[k]);  // вектор k-й производной

module.exports = { C, X, lift, add, sub, neg, mul, scale, div, sqr, sqrt, sin, cos,
  vlift, vadd, vsub, vscale, vscaleI, dot, cross, normalize, val, grad };
