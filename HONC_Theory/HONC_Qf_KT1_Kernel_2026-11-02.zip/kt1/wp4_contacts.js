'use strict';
// HONC / Qf / R1 / КТ-1 — WP-4: касания 2D–2D и J5 (спецификация K-1…K-6; интерфейс v6, §§ 6.2, 6.3, 7).
// Обоснования — WP4_Contacts_Notes.md.
//  K-1 существование касания каждой пары: IMPOSED (построение П-8а/б, объявление П-8в) или по вилке зазора G-4.
//  K-2 тип: установленный (П-7 или объявление), сертифицированно смешанный или не установленный; показ по порогам.
//  K-3 параллельность и чтение; знак g = sign(v_A·v_B), v = T × (c − A).
//  K-4 вырождение: вилка косинуса содержит 0 ⇒ J5-DEGENERATE(ε), знака нет. ε — полуширина вилки косинуса.
//  K-5 разные знаки в разных точках ⇒ UNRESOLVED CONTACT, знака нет.
//  K-6 граф касаний, два итога, мосты, знаки Y с метками, ветвление по кандидатам.
const iv = require('./wp0_interval');
const vec = require('./wp1_vec');
const L = require('./wp0_labels');
const { torusGap, perpBasis } = require('./wp2_gap');

const I = iv.I, HALF = I(0.5);
const N_MAX_CANDIDATES = 8;                  // интерфейс § 8
const K2_DISPLAY = [0.05, 0.95];             // пороги показа K-2 (на чтение не влияют)
const ARC_PIECE = Math.PI / 64;              // длинные вилки точек минимума (кривая касания) режутся на куски не длиннее
const tWidth = t => Math.max(vec.vwidth(t.A), vec.vwidth(t.T));

// ---------------- точки касания ----------------
// Точка множества минимума G-4 на вилке Φ параметра средней окружности тора 1: p = C1(Φ), q — ближайшая точка средней
// окружности тора 2, n = норм(q − p) (от тора 1 к тору 2), c = p + ½n — точка касания тел (при зазоре 0 — середина pq).
function contactPoint(t1, t2, phi) {
  const { e1, e2 } = perpBasis(t1.T);         // тот же базис, что в torusGap
  const s = iv.sin(phi), co = iv.cos(phi);
  const p = vec.vadd(t1.A, vec.vscale(vec.vadd(vec.vscale(e1, co), vec.vscale(e2, s)), HALF));
  const r = vec.vsub(p, t2.A), z = vec.dot(r, t2.T);
  const rp = vec.vsub(r, vec.vscale(t2.T, z));
  try {
    const q = vec.vadd(t2.A, vec.vscale(vec.normalize(rp), HALF));
    const n = vec.normalize(vec.vsub(q, p));
    const c = vec.vadd(p, vec.vscale(n, HALF));
    const v1 = vec.cross(t1.T, vec.vsub(c, t1.A)), v2 = vec.cross(t2.T, vec.vsub(c, t2.A));
    let cos = iv.div(vec.dot(v1, v2), iv.mul(vec.norm(v1), vec.norm(v2)));
    cos = [Math.max(-1, cos[0]), Math.min(1, cos[1])];          // истинный косинус в [−1, 1]
    return { phi, c, n, nT: [iv.abs(vec.dot(n, t1.T)), iv.abs(vec.dot(n, t2.T))], cos };
  } catch (e) {
    // точка на оси второго тора или совпадение точек: направление не определено
    return { phi, c: null, n: null, nT: [[0, 1], [0, 1]], cos: [-1, 1], undetermined: true };
  }
}
function contactPoints(t1, t2, argmin) {
  const pts = [];
  for (const [l, r] of argmin) {
    const k = Math.max(1, Math.ceil((r - l) / ARC_PIECE));
    for (let j = 0; j < k; j++) {
      const a = j === 0 ? l : l + (r - l) * j / k, b = j === k - 1 ? r : l + (r - l) * (j + 1) / k;
      pts.push(contactPoint(t1, t2, [a, b]));
    }
  }
  return pts;
}

// ---------------- K-3, K-4, K-5: чтение по одной паре ----------------
// Класс чтения по K-3: J5-CANON ⇔ параллельность установлена и тип установлен (SIDE / AXIAL);
// J5-EXT ⇔ непараллельность сертифицирована или тип сертифицированно смешанный (тогда чтение не каноническое при любом
// разрешении остального); иначе J5-CLASS-UNRESOLVED.
function readingClass(parallel, type) {
  if (parallel === 'PARALLEL-ESTABLISHED' && (type === 'SIDE' || type === 'AXIAL')) return 'J5-CANON';
  if (parallel === 'NON-PARALLEL' || type === 'MIXED') return 'J5-EXT';
  return 'J5-CLASS-UNRESOLVED';
}
// Библиотечная точка (интерфейс § 7): K.j5Reading({ parallel, type, cos }).
function j5Reading({ parallel, type, cos }) {
  if (!L.PARALLEL.includes(parallel)) throw new Error(`j5Reading: parallel ${parallel}`);
  if (!L.TYPE.includes(type)) throw new Error(`j5Reading: type ${type}`);
  if (!Array.isArray(cos) || !cos.length) throw new Error('j5Reading: cos — непустой список вилок');
  const cls = readingClass(parallel, type);
  const epsilon = Math.max(...cos.map(c => (c[0] === c[1] ? 0 : iv.nextUp((c[1] - c[0]) / 2))));   // верхняя оценка полуширины
  const degenerate = cos.some(c => c[0] <= 0 && c[1] >= 0);
  const signs = cos.map(c => (c[0] > 0 ? 1 : c[1] < 0 ? -1 : 0));
  const mixed = !degenerate && signs.some(s => s !== signs[0]);
  const out = { reading: degenerate ? 'J5-DEGENERATE' : cls, reading_class: cls, sign: degenerate || mixed ? null : signs[0], epsilon };
  if (degenerate) out.degenerate_basis = 'K-4: вилка косинуса содержит 0 хотя бы в одной точке';
  if (mixed) { out.contact_class = 'UNRESOLVED CONTACT'; out.k5 = 'K-5: в разных точках касания разные знаки'; }
  return out;
}

// ---------------- K-1, K-2, K-3 по конфигурации ----------------
// conf: { tori, rings, contacts (из построения), parallelEstablished(a, b), sideByConstruction(a, b),
//         declared: [{kind, pair, ...}] (синтетика), tClassBasis(a, b) }
function typeOf(conf, a, b, pts) {
  const dec = (conf.declares || []).find(d => d.kind === 'type' && samePair(d.pair, [a.name, b.name]));
  if (dec) return { type: dec.type, type_basis: { rule: 'объявление входа', basis: dec.basis } };
  if (conf.sideByConstruction && conf.sideByConstruction(a, b)) return { type: 'SIDE', type_basis: { rule: 'П-7', premises: ['параллельность по П-6', 'разность центров ⊥ оси по цепочке тождеств П-2/П-5 (один класс плоскости)'] } };
  // сертифицированно смешанный: abs(n·T) у обоих торов отделена от 0 и от 1 во всех точках
  const mixed = pts.length && pts.every(p => p.nT.every(x => x[0] > 0 && x[1] < 1));
  return mixed ? { type: 'MIXED', type_basis: { rule: 'сертифицированно: abs(n·T) отделена от 0 и 1 у обоих торов во всех точках' } } : { type: 'UNDETERMINED', type_basis: null };
}
const samePair = (p, q) => (p[0] === q[0] && p[1] === q[1]) || (p[0] === q[1] && p[1] === q[0]);
function parallelOf(conf, a, b) {
  if (conf.parallelEstablished && conf.parallelEstablished(a, b)) {
    return { parallel: 'PARALLEL-ESTABLISHED', parallel_basis: conf.parallelBasis ? conf.parallelBasis(a, b) : { rule: 'П-6' } };
  }
  const x = iv.sqrt(vec.norm2(vec.cross(a.T, b.T)));
  return x[0] > 0 ? { parallel: 'NON-PARALLEL', cross_abs: x } : { parallel: 'PARALLEL-UNCERTAIN', cross_abs: x };
}
function typeDisplay(pts) {
  if (!pts.length || pts.some(p => p.undetermined)) return null;
  const m = pts.map(p => p.nT.map(iv.mid));
  if (m.every(([x, y]) => x < K2_DISPLAY[0] && y < K2_DISPLAY[0])) return 'SIDE';
  if (m.every(([x, y]) => x > K2_DISPLAY[1] && y > K2_DISPLAY[1])) return 'AXIAL';
  return 'MIXED';
}

// Все пары торов: проверка G-4 (с существованием K-1) и записи касаний для IMPOSED и CANDIDATE.
// Правило совместимости объявленного касания (утверждено к следующей версии интерфейса) в версии 6 не действует:
// opts.declareCompat = true включает его (input_error через исключение DeclareError).
class DeclareError extends Error {}
function torusPairs(conf, opts = {}) {
  const { tori } = conf;
  const imposed = new Map();
  for (const c of conf.contacts || []) imposed.set([...c.pair].sort().join('|'), c);
  const checks = [], contacts = [];
  for (let i = 0; i < tori.length; i++) for (let j = i + 1; j < tori.length; j++) {
    const a = tori[i], b = tori[j], key = [a.name, b.name].sort().join('|');
    const w = Math.max(tWidth(a), tWidth(b));
    const g = torusGap(a, b, { tol: 1e-13 + 4 * w });
    const imp = imposed.get(key);
    let existence;
    if (imp) existence = 'IMPOSED';
    else existence = g.gap[0] > 0 ? 'SEPARATED' : g.gap[1] < 0 ? 'PENETRATION' : 'CANDIDATE';
    const compatible = !imp || iv.containsZero(g.gap);
    if (imp && !compatible && opts.declareCompat && imp.basis && imp.basis.rule === 'П-8в')
      throw new DeclareError(`declare: касание ${a.name}–${b.name} объявлено IMPOSED, а вилка зазора [${g.gap[0]}, ${g.gap[1]}] не содержит 0`);
    if (imp && !compatible && imp.basis && imp.basis.rule !== 'П-8в')
      throw new Error(`ядро: касание ${a.name}–${b.name} по построению (${imp.basis.rule}), а вилка зазора не содержит 0`);
    const id = `G4:${a.name}:${b.name}`;
    const base = { id, req: 'G-4', objects: [a.name, b.name], quantity: 'gap', value: g.gap, completeness: 'CERTIFIED', existence, where: { phi_argmin: g.argmin } };
    let verdict, reason = null;
    if (existence === 'PENETRATION' || (existence === 'IMPOSED' && g.gap[1] < 0)) { verdict = 'FORBIDDEN'; reason = `G-4: тела ${a.name} и ${b.name} проникают друг в друга; зазор ${g.gap[1]} < 0`; }
    else if (existence === 'CANDIDATE') { verdict = 'UNRESOLVED'; reason = `K-1: 0 в вилке зазора ${a.name}–${b.name} — касание или проникновение не различены${g.converged ? '' : '; поиск не сошёлся'}`; }
    else verdict = 'PASSED';
    checks.push(L.makeCheck({ ...base, verdict, level: verdict === 'PASSED' ? 'L2' : 'L1', reason,
      ...(imp && !compatible ? { declare_gap_compatible: false } : {}) }));
    if (existence !== 'IMPOSED' && existence !== 'CANDIDATE') continue;
    // запись касания (интерфейс § 6.2)
    const pts = contactPoints(a, b, g.argmin);
    const par = parallelOf(conf, a, b), ty = typeOf(conf, a, b, pts);
    const rd = j5Reading({ parallel: par.parallel, type: ty.type, cos: pts.map(p => p.cos) });
    const linked = (conf.rings || []).some(r => (r.threads || []).includes(a.name) && (r.threads || []).includes(b.name));
    const cls = imp ? imp.cls || (linked ? 'LINK' : 'CONTACT-ONLY') : (linked ? 'LINK' : 'CONTACT-ONLY');
    let contact_class = existence === 'CANDIDATE' || rd.contact_class === 'UNRESOLVED CONTACT' ? 'UNRESOLVED CONTACT' : linked ? 'STRUCTURAL' : 'ALLOWED CONTACT';
    contacts.push({ pair: [a.name, b.name], cls, existence, basis: imp ? imp.basis : null, ...(imp && imp.d ? { d: imp.d } : {}), gap: g.gap,
      gap_compatible: compatible,
      points: pts.map(p => ({ phi: p.phi, c: p.c, n: p.n, abs_nT: p.nT, cos: p.cos })),
      ...par, ...ty, type_display: typeDisplay(pts), reading: rd.reading, reading_class: rd.reading_class, sign: rd.sign, epsilon: rd.epsilon, contact_class,
      ...(rd.k5 ? { k5: rd.k5 } : {}), ...(rd.degenerate_basis ? { degenerate_basis: rd.degenerate_basis } : {}) });
  }
  return { checks, contacts };
}

// ---------------- K-6 ----------------
// Мосты графа (рёбра вне циклов) — обход в глубину с low-link; рёбра различаются по номеру (кратные рёбра — не мосты).
function bridges(V, E) {
  const adj = new Map(V.map(v => [v, []]));
  E.forEach((e, k) => { adj.get(e.a).push([e.b, k]); adj.get(e.b).push([e.a, k]); });
  const tin = new Map(), low = new Map(), out = new Set();
  let t = 0;
  const dfs = (v, pe) => {
    tin.set(v, t); low.set(v, t); t++;
    for (const [u, k] of adj.get(v)) {
      if (k === pe) continue;
      if (tin.has(u)) low.set(v, Math.min(low.get(v), tin.get(u)));
      else { dfs(u, k); low.set(v, Math.min(low.get(v), low.get(u))); if (low.get(u) > tin.get(v)) out.add(k); }
    }
  };
  for (const v of V) if (!tin.has(v)) dfs(v, -1);
  return out;
}
// Согласованность разметки: y_a·y_b = sign по каждому ребру. Остов обходом в ширину; несогласованное ребро вне остова
// даёт цикл (путь по остову + ребро) с произведением знаков −1.
function consistency(V, E) {
  const adj = new Map(V.map(v => [v, []]));
  E.forEach((e, k) => { adj.get(e.a).push([e.b, k]); adj.get(e.b).push([e.a, k]); });
  const col = new Map(), par = new Map();
  for (const s of V) {
    if (col.has(s)) continue;
    col.set(s, 1); par.set(s, null);
    const q = [s];
    while (q.length) {
      const v = q.shift();
      for (const [u, k] of adj.get(v)) {
        const want = col.get(v) * E[k].sign;
        if (!col.has(u)) { col.set(u, want); par.set(u, [v, k]); q.push(u); }
        else if (col.get(u) !== want) {
          const path = x => { const p = [x]; while (par.get(x)) { x = par.get(x)[0]; p.push(x); } return p; };
          const pa = path(v), pb = path(u), common = pa.find(x => pb.includes(x));
          const cyc = [...pa.slice(0, pa.indexOf(common) + 1), ...pb.slice(0, pb.indexOf(common)).reverse()];
          return { consistent: false, cycle: cyc };
        }
      }
    }
  }
  return { consistent: true, cycle: null };
}
// Знаки Y: затравка — первый (в порядке вершин) ещё не размеченный тор, +1; это условность (интерфейс § 6.3).
// Сначала обход от затравки только по каноническим рёбрам со знаком — метка CANON. Затем по любым рёбрам со знаком —
// метка [Г, мост]: знак, выведенный через ребро расширения, наследует его метку, и дальше она не снимается.
// Тор, не связанный с затравкой рёбрами со знаком, получает собственную затравку (поле seed).
function ysigns(V, E) {
  const signed = E.filter(e => e.sign === 1 || e.sign === -1);
  const adj = new Map(V.map(v => [v, []]));
  for (const e of signed) { adj.get(e.a).push([e.b, e.sign, e.reading === 'J5-CANON']); adj.get(e.b).push([e.a, e.sign, e.reading === 'J5-CANON']); }
  const out = new Map();
  for (const s of V) {
    if (out.has(s)) continue;
    out.set(s, { torus: s, sign: 1, label: 'CANON', seed: s });
    const canonQ = [s], extQ = [];
    while (canonQ.length) {
      const v = canonQ.shift();
      for (const [u, sg, isCanon] of adj.get(v)) {
        if (out.has(u)) continue;
        if (isCanon) { out.set(u, { torus: u, sign: out.get(v).sign * sg, label: 'CANON', seed: s }); canonQ.push(u); }
      }
    }
    for (const v of out.keys()) if (out.get(v).seed === s) extQ.push(v);
    while (extQ.length) {
      const v = extQ.shift();
      for (const [u, sg] of adj.get(v)) {
        if (out.has(u)) continue;
        out.set(u, { torus: u, sign: out.get(v).sign * sg, label: '[Г, мост]', seed: s }); extQ.push(u);
      }
    }
  }
  return V.map(v => out.get(v));
}
const edgeName = e => `${e.a}–${e.b}`;
// Итоги по набору существенных рёбер (без кандидатов).
function evaluate(V, E) {
  const br = bridges(V, E);
  const edges = E.map((e, k) => ({ pair: [e.a, e.b], cls: e.cls, reading: e.reading, sign: e.sign, on_cycle: !br.has(k), bridge: br.has(k) }));
  const signedCanon = E.filter(e => e.reading === 'J5-CANON' && (e.sign === 1 || e.sign === -1));
  const cc = consistency(V, signedCanon);
  const nonCanon = E.filter(e => !(e.reading === 'J5-CANON' && (e.sign === 1 || e.sign === -1)));
  const uncovered = E.map((e, k) => [e, k]).filter(([e, k]) => br.has(k) && nonCanon.includes(e)).map(([e]) => edgeName(e));
  let canon;
  if (!cc.consistent) canon = { verdict: 'FORBIDDEN', reason: 'K-6: несогласован цикл только из канонических рёбер', inconsistent_canon_cycle: cc.cycle };
  else if (!nonCanon.length) canon = { verdict: 'PASSED', level: 'L3', reason: null, inconsistent_canon_cycle: null };
  else canon = { verdict: 'UNRESOLVED', reason: `K-6: не все существенные рёбра канонические (${nonCanon.map(edgeName).join(', ')})${uncovered.length ? `; мосты вне канонической проверки: ${uncovered.join(', ')}` : ''}`, inconsistent_canon_cycle: null };
  canon.non_canon_edges = nonCanon.map(edgeName);
  canon.uncovered_bridges = uncovered;
  const signedAll = E.filter(e => e.sign === 1 || e.sign === -1);
  const ce = consistency(V, signedAll);
  const unsigned = E.filter(e => !(e.sign === 1 || e.sign === -1));
  let ext;
  if (!ce.consistent) ext = { verdict: 'FORBIDDEN-EXT', reason: 'K-6: несогласованный цикл при знаках расширения', inconsistent_cycle: ce.cycle };
  else if (!unsigned.length) ext = { verdict: 'PASSED-EXT', reason: 'согласовано при рабочем расширении [Г, мост] — не согласованность по J5' };
  else ext = { verdict: 'UNRESOLVED', reason: `K-6: у рёбер нет знака (вырождение или K-5): ${unsigned.map(edgeName).join(', ')}` };
  ext.label = '[Г, мост]';
  return { edges, canon, ext, ysigns: ysigns(V, E) };
}
// Библиотечная точка (интерфейс § 7): K.j5Graph({ vertices, edges }). Рёбра: {a, b, cls, existence, reading, sign}.
// IMPOSED — существенные; CANDIDATE — ветвление K-1 (есть / нет), не больше n_max.
function j5Graph({ vertices, edges, nMax = N_MAX_CANDIDATES }) {
  const V = [...vertices];
  for (const e of edges) {
    if (!V.includes(e.a) || !V.includes(e.b)) throw new Error(`j5Graph: ребро ${e.a}–${e.b} вне вершин`);
    if (!L.READING.includes(e.reading)) throw new Error(`j5Graph: reading ${e.reading}`);
  }
  const ess = edges.filter(e => e.existence === 'IMPOSED' || e.existence === undefined);
  const cand = edges.filter(e => e.existence === 'CANDIDATE');
  const base = evaluate(V, ess);
  if (!cand.length) return { ...base, branches: [] };
  const allEdges = evaluate(V, [...ess, ...cand]).edges.map((x, k) => ({ ...x, existence: k < ess.length ? 'IMPOSED' : 'CANDIDATE' }));
  if (cand.length > nMax) {
    const r = `K-1: кандидатов ${cand.length} больше n_max = ${nMax}`;
    return { edges: allEdges, canon: { ...base.canon, verdict: 'UNRESOLVED', reason: r, level: undefined }, ext: { ...base.ext, verdict: 'UNRESOLVED', reason: r }, ysigns: base.ysigns, branches: [] };
  }
  const branches = [];
  for (let mask = 0; mask < 1 << cand.length; mask++) {
    const on = cand.filter((_, k) => mask & (1 << k));
    const r = evaluate(V, [...ess, ...on]);
    branches.push({ assume: cand.map((e, k) => ({ pair: [e.a, e.b], contact: (mask & (1 << k)) ? 'есть' : 'нет' })), canon: r.canon.verdict, ext: r.ext.verdict });
  }
  const agree = key => branches.every(b => b[key] === branches[0][key]);
  const canon = agree('canon')
    ? { ...base.canon, verdict: branches[0].canon, reason: `ветви кандидатов совпали (${branches[0].canon})`, branch_note: 'вердикт по ветвям K-1' }
    : { verdict: 'UNRESOLVED', reason: 'K-1: ветви кандидатов расходятся', inconsistent_canon_cycle: null, non_canon_edges: base.canon.non_canon_edges, uncovered_bridges: base.canon.uncovered_bridges };
  if (canon.verdict !== 'PASSED') delete canon.level;
  const ext = agree('ext')
    ? { ...base.ext, verdict: branches[0].ext, reason: `ветви кандидатов совпали (${branches[0].ext})`, branch_note: 'вердикт по ветвям K-1' }
    : { verdict: 'UNRESOLVED', reason: 'K-1: ветви кандидатов расходятся', label: '[Г, мост]' };
  return { edges: allEdges, canon, ext, ysigns: base.ysigns, branches };
}
// Граф J5 конфигурации — из записей касаний (IMPOSED и CANDIDATE).
function j5FromContacts(tori, contacts) {
  return j5Graph({ vertices: tori.map(t => t.name), edges: contacts.map(c => ({ a: c.pair[0], b: c.pair[1], cls: c.cls, existence: c.existence, reading: c.reading, sign: c.sign })) });
}

module.exports = { torusPairs, contactPoint, contactPoints, j5Reading, readingClass, j5Graph, j5FromContacts, bridges, consistency, ysigns,
  N_MAX_CANDIDATES, K2_DISPLAY, DeclareError };
