'use strict';
// HONC / Qf / R1 / КТ-1 — WP-1: построение (G-1, G-2, G-3 зеркальное, G-7) и свидетельства П-1…П-8 (интерфейс v6, § 2–3).
// Запись кольца — интерфейс v6, § 6.5: вилки полей и обязательные ширины (поправка G-2 к спецификации, 02.11).
// В этой сборке: зеркальные звенья (δ = 0) нити и навесов. Незеркальные звенья (δ ≠ 0) и уравнение касания (fix)
// требуют корня по G-4 — следующий шаг; при таком входе выдаётся NotYet, а не приближение.
const iv = require('./wp0_interval');
const vec = require('./wp1_vec');
const { perimeter } = require('./wp0_cert');

const MIRROR_STATUS = '[Г] конвенция модели, Раунд 3а § 1';
class InputError extends Error {}
class NotYet extends Error {}
const I = iv.I;

function num(o, k, ctx) {
  if (typeof o[k] !== 'number' || !Number.isFinite(o[k])) throw new InputError(`${ctx}: нет числа «${k}»`);
  return o[k];
}
// sin/cos угла в градусах; кратные 90° — точно (это значения, а не приближения).
function trigDeg(deg) {
  if (Number.isInteger(deg)) {
    const m = ((deg % 360) + 360) % 360;
    if (m === 0) return { s: I(0), c: I(1) };
    if (m === 90) return { s: I(1), c: I(0) };
    if (m === 180) return { s: I(0), c: I(-1) };
    if (m === 270) return { s: I(-1), c: I(0) };
  }
  const r = iv.deg2rad(iv.fromInput(deg));
  return { s: iv.sin(r), c: iv.cos(r) };
}
const isAxisAngle = deg => Number.isInteger(deg) && deg % 180 === 0;   // sin = 0 точно

// Рамка узла (§ 2): e_y — нормированная часть T, перпендикулярная e_z; при установленном T ⊥ e_z — сама T.
function frame(t) {
  const ez = t.ezIn;
  const ey = t.perpEz ? t.T : vec.normalize(vec.vsub(t.T, vec.vscale(ez, vec.dot(t.T, ez))));
  return { ex: vec.cross(ey, ez), ey, ez };
}

// Кольцо-окружность по тождеству: зеркальное звено, u ⊥ T ⇒ d = 2, T_B = T_A, обе касательные ⊥ хорде ⇒
// окружность радиуса 1 с центром в середине хорды; её длина 2π точно.
function circleRing(A, u, T) {
  return { C: vec.vadd(A, u), E1: u, E2: T, s1: I(1), s2: I(1), length: iv.TWO_PI, residual: I(0),
    basis: 'тождество: зеркальное звено при u ⊥ T — окружность радиуса 1 (длина 2π точно)', completeness: 'EXACT' };
}

// Кольцо ЛМ1 общего вида (G-2): пучок коник L_A·L_B − μ·y² = 0 в плоскости (X = u, Y ⊥ u вдоль T_A).
// Внутренности эллипсов семейства вложены: Q_μ2 = Q_μ1 − (μ2 − μ1)·y² <= Q_μ1 при μ2 > μ1, поэтому длина
// строго растёт по μ на (−∞, μ*), и корень уравнения длины 2π единствен. Вилка корня — делением пополам по знаку.
function ringLM1(A, TA, u, d, TB) {
  const X = u;
  const Y = vec.normalize(vec.vsub(TA, vec.vscale(X, vec.dot(TA, X))));
  const tax = vec.dot(TA, X), tay = vec.dot(TA, Y);
  let tbx = vec.dot(TB, X), tby = vec.dot(TB, Y);
  if (tay[0] <= 0) throw new Error('кольцо: ось T_A неотделима от хорды');
  if (tby[1] < 0) { tbx = iv.neg(tbx); tby = iv.neg(tby); } else if (tby[0] <= 0) throw new Error('кольцо: ось T_B неотделима от хорды');
  const p1 = iv.neg(tay), q1 = tax, p2 = iv.neg(tby), q2 = tbx, r2 = iv.mul(d, tby);
  const cA = iv.mul(p1, p2), cB = iv.add(iv.mul(p1, q2), iv.mul(q1, p2)), cD = iv.mul(p1, r2), cE = iv.mul(q1, r2);
  const q1q2 = iv.mul(q1, q2);
  if (cA[0] <= 0) throw new Error('кольцо: вырожденный пучок');
  const muStar = iv.sub(q1q2, iv.div(iv.sqr(cB), iv.mul(I(4), cA)));
  function ell(mu) {
    const cC = iv.sub(q1q2, mu);
    const det = iv.sub(iv.mul(iv.mul(I(4), cA), cC), iv.sqr(cB));
    if (det[0] <= 0) return null;
    const xc = iv.div(iv.sub(iv.mul(cB, cE), iv.mul(iv.mul(I(2), cC), cD)), det);
    const yc = iv.div(iv.sub(iv.mul(cB, cD), iv.mul(iv.mul(I(2), cA), cE)), det);
    const Fc = iv.mul(I(0.5), iv.add(iv.mul(cD, xc), iv.mul(cE, yc)));
    if (Fc[1] >= 0) return null;
    const tr = iv.add(cA, cC);
    const dd = iv.sqrt(iv.add(iv.sqr(iv.sub(cA, cC)), iv.sqr(cB)));
    const l1 = iv.mul(I(0.5), iv.add(tr, dd)), l2 = iv.mul(I(0.5), iv.sub(tr, dd));
    if (l2[0] <= 0) return null;
    const mF = iv.neg(Fc);
    return { cC, xc, yc, s1: iv.sqrt(iv.div(mF, l1)), s2: iv.sqrt(iv.div(mF, l2)) };
  }
  const P = mu => { const e = ell(mu); return e ? perimeter(e.s1, e.s2).value : null; };
  const T2 = iv.TWO_PI, top = muStar[0], scale = Math.max(1, Math.abs(top));
  let hi = null, lo = null;
  for (let k = 1; k < 120 && hi === null; k++) { const m = top - scale * 2 ** -k; const p = P(I(m)); if (p && p[0] > T2[1]) hi = m; }
  for (let k = 0; k < 120 && lo === null; k++) { const m = top - scale * 2 ** k; const p = P(I(m)); if (p && p[1] < T2[0]) lo = m; }
  if (hi === null || lo === null) throw new Error('кольцо: не найдена вилка корня уравнения длины');
  // Сужение: lo — точка, где длина заведомо меньше 2π; hi — заведомо больше. Если в середине знак не определён,
  // поджимаем оба края пробами в четвертях, пока хоть один край сдвигается.
  const side = m => { const p = P(I(m)); return !p ? 0 : p[0] > T2[1] ? 1 : p[1] < T2[0] ? -1 : 0; };
  for (let k = 0; k < 600; k++) {
    const m = lo + (hi - lo) / 2;
    if (!(m > lo && m < hi)) break;
    const sm = side(m);
    if (sm === 1) { hi = m; continue; }
    if (sm === -1) { lo = m; continue; }
    const m1 = lo + (m - lo) / 2, m2 = m + (hi - m) / 2;
    let moved = false;
    if (m1 > lo && side(m1) === -1) { lo = m1; moved = true; }
    if (m2 < hi && side(m2) === 1) { hi = m2; moved = true; }
    if (!moved) break;
  }
  const muI = [lo, hi];
  const e = ell(muI);
  if (!e) throw new Error('кольцо: эллипс на вилке корня не построен');
  // Главные оси. Оба собственных вектора удовлетворяют tg 2θ = cB/(cA − cC). Угол берётся от того вектора,
  // для которого atan2 далёк от разреза: при cA − cC > 0 — вектор большего собственного значения l1
  // (вдоль него полуось s1), при cA − cC < 0 — вектор l2 (вдоль него s2). При cB ≈ 0 и cA ≈ cC (почти окружность)
  // ориентация не определена — кольцо заключается в кольцевую область: точка C + ρ(cos t·X + sin t·Y), ρ ∈ hull(s1, s2).
  const C = vec.vadd(A, vec.vadd(vec.vscale(X, e.xc), vec.vscale(Y, e.yc)));
  const amc = iv.sub(cA, e.cC);
  let E1, E2, s1 = e.s1, s2 = e.s2, annulus = false;
  if (amc[0] > 0 || amc[1] < 0) {
    const pos = amc[0] > 0;
    const th = iv.mul(I(0.5), (pos ? iv.atan2(cB, amc) : iv.atan2(iv.neg(cB), iv.neg(amc))).v);
    const ct = iv.cos(th), st = iv.sin(th);
    const Ea = vec.vadd(vec.vscale(X, ct), vec.vscale(Y, st));
    const Eb = vec.vadd(vec.vscale(X, iv.neg(st)), vec.vscale(Y, ct));
    if (pos) { E1 = Ea; E2 = Eb; } else { E2 = Ea; E1 = vec.vneg(Eb); }
  } else {
    annulus = true; E1 = X; E2 = Y; s1 = s2 = iv.hull(e.s1, e.s2);
  }
  const length = perimeter(e.s1, e.s2).value;
  return { C, E1, E2, s1, s2, X, Y, mu: muI, length, residual: iv.sub(length, T2), annulus,
    basis: 'корень уравнения длины (AGM); единственность — вложенность семейства', completeness: 'CERTIFIED' };
}

// Ширины вилок кольца (интерфейс v6, § 6.5). Ширина — hi − lo с округлением вверх: при округлении к ближайшему
// ошибка не больше половины единицы последнего разряда, и следующее вверх число её покрывает. Вилка из одного числа — 0.
const widthOf = a => (a == null ? null : a[0] === a[1] ? 0 : iv.nextUp(a[1] - a[0]));
const widthVec = v => Math.max(...v.map(widthOf));
function ringWidths(r) {
  const widths = { C: widthVec(r.C), E1: widthVec(r.E1), E2: widthVec(r.E2), s1: widthOf(r.s1), s2: widthOf(r.s2),
    length: widthOf(r.length), residual: widthOf(r.residual) };
  return { widths, width_max: Math.max(widths.C, widths.E1, widths.E2, widths.s1, widths.s2) };
}
const ringRecord = (head, ring) => ({ ...head, source: 'construction', ...ring, ...ringWidths(ring) });

// Звено из тора `from` в направлении u (вилка-вектор) с параметром δ.
function link(from, u, uPerpT, delta, ctx) {
  if (delta !== 0) throw new NotYet(`${ctx}: незеркальное звено (δ = ${delta}) — нужен корень G-4, следующий шаг`);
  const T = from.T;
  const Tn = uPerpT ? T : vec.vsub(T, vec.vscale(u, iv.mul(I(2), vec.dot(T, u))));
  let d;
  if (uPerpT) d = I(2);
  else { const c = vec.dot(T, u); let w = iv.sub(I(1), iv.sqr(c)); w = [Math.max(0, w[0]), Math.max(0, w[1])]; d = iv.add(iv.sqrt(w), I(1)); }
  const A2 = vec.vadd(from.A, vec.vscale(u, d));
  const ring = uPerpT ? circleRing(from.A, u, T) : ringLM1(from.A, T, u, d, Tn);
  return { u, d, A2, T2: Tn, ring, identity: uPerpT };
}

// Построение по описанию случая (интерфейс § 4.1).
function build(cs) {
  const ev = [], conv = [], tori = [], rings = [], contacts = [];
  let tClassN = 0, planeN = 0;
  const th = cs.thread;
  if (!th || !Number.isInteger(th.n) || th.n < 1) throw new InputError('thread.n: нужно целое >= 1');
  if (!Array.isArray(th.links) || th.links.length !== th.n) throw new InputError(`thread.links: нужно ровно ${th.n} записей`);
  tori.push({ name: 'T0', A: vec.V(0, 0, 0), T: vec.V(0, 1, 0), ezIn: vec.V(0, 0, 1), perpEz: true, tClass: tClassN++, planeClass: planeN++ });
  ev.push({ rule: 'П-1', fact: 'T0 ⊥ e_z', objects: ['T0'] });
  const frames = [];
  for (let k = 0; k < th.n; k++) {
    const L = th.links[k], ctx = `звено ${k}`;
    const tdeg = num(L, 'theta', ctx), pdeg = num(L, 'phi', ctx), ddeg = num(L, 'delta', ctx);
    const t = tori[k], fr = frame(t); frames.push(fr);
    const tt = trigDeg(tdeg), tp = trigDeg(pdeg);
    const u = tdeg === 0 ? fr.ez : vec.vadd(vec.vscale(fr.ez, tt.c), vec.vscale(vec.vadd(vec.vscale(fr.ex, tp.c), vec.vscale(fr.ey, tp.s)), tt.s));
    const uPerpT = t.perpEz && (tdeg === 0 || isAxisAngle(pdeg));
    if (uPerpT) ev.push({ rule: 'П-2', fact: `u ⊥ T (звено ${k})`, objects: [t.name], premises: [t.perpEz ? 'T ⊥ e_z' : null, tdeg === 0 ? 'θ = 0' : 'φ ∈ {0°, 180°}'] });
    const lk = link(t, u, uPerpT, ddeg, ctx);
    if (ddeg === 0) conv.push({ link: `R${k}`, mirror: true, status: MIRROR_STATUS });
    const last = k === th.n - 1;
    rings.push(ringRecord({ name: `R${k}`, owner: t.name, threads: last ? [t.name] : [t.name, `T${k + 1}`], free: last }, lk.ring));
    if (!last) {
      const same = lk.identity;     // П-3: T_{k+1} = T_k
      const nt = { name: `T${k + 1}`, A: lk.A2, T: lk.T2, ezIn: u, perpEz: same, tClass: same ? t.tClass : tClassN++, planeClass: same ? t.planeClass : planeN++ };
      tori.push(nt);
      if (same) { ev.push({ rule: 'П-3', fact: `T${k + 1} = T${k}`, objects: [t.name, nt.name] }); ev.push({ rule: 'П-4', fact: `T${k + 1} ⊥ e_z`, objects: [nt.name] }); }
      contacts.push({ pair: [t.name, nt.name], cls: 'LINK', existence: 'IMPOSED',
        basis: { rule: 'П-8а', kind: 'linked-pair', form: lk.identity ? 'тождество d = 2' : 'закрытая форма зеркального звена' }, d: lk.d });
    }
  }
  const nThread = tori.length;
  (cs.hangs || []).forEach((h, j) => {
    const ctx = `навес ${j + 1}`, name = `H${j + 1}`;
    if (!Number.isInteger(h.host) || h.host < 0 || h.host >= nThread) throw new InputError(`${ctx}: нет тора-хозяина ${h.host}`);
    if (h.side !== 1 && h.side !== -1) throw new InputError(`${ctx}: side должен быть 1 или −1`);
    if (h.fix) throw new NotYet(`${ctx}: уравнение касания (fix) — нужен корень G-4, следующий шаг`);
    const host = tori[h.host], fr = frames[h.host] || frame(host);
    const s = I(h.side);
    let e, ePerp;
    if (h.coords === 'rho-psi') {
      const r = num(h, 'rho', ctx), p = num(h, 'psi', ctx);
      const tr = trigDeg(r), tp = trigDeg(p);
      e = r === 0 ? vec.vscale(fr.ex, s)
        : vec.vadd(vec.vscale(fr.ex, iv.mul(s, tr.c)), vec.vscale(vec.vadd(vec.vscale(fr.ez, iv.neg(tp.c)), vec.vscale(fr.ey, tp.s)), tr.s));
      ePerp = host.perpEz && (r === 0 || isAxisAngle(p));
    } else if (h.coords === 'alpha-lambda') {
      const a = num(h, 'alpha', ctx), l = num(h, 'lambda', ctx);
      const ta = trigDeg(a), tl = trigDeg(l);
      e = vec.vsub(vec.vscale(vec.vadd(vec.vscale(fr.ex, iv.mul(s, ta.c)), vec.vscale(fr.ey, ta.s)), tl.c), vec.vscale(fr.ez, tl.s));
      ePerp = host.perpEz && isAxisAngle(a);
    } else throw new InputError(`${ctx}: coords должен быть rho-psi или alpha-lambda`);
    const ddeg = num(h, 'delta', ctx);
    if (ePerp) ev.push({ rule: 'П-5', fact: `e ⊥ T хозяина (${name})`, objects: [host.name, name] });
    const lk = link(host, e, ePerp, ddeg, ctx);
    if (ddeg === 0) conv.push({ link: `RH${j + 1}`, mirror: true, status: MIRROR_STATUS });
    const ht = { name, A: lk.A2, T: lk.T2, host: host.name, tClass: lk.identity ? host.tClass : tClassN++, planeClass: lk.identity ? host.planeClass : planeN++ };
    tori.push(ht);
    if (lk.identity) ev.push({ rule: 'П-5', fact: `T(${name}) = T(${host.name})`, objects: [host.name, name] });
    rings.push(ringRecord({ name: `RH${j + 1}`, owner: name, threads: [name, host.name], free: false }, lk.ring));
    contacts.push({ pair: [host.name, name], cls: 'LINK', existence: 'IMPOSED',
      basis: { rule: 'П-8а', kind: 'linked-pair', form: lk.identity ? 'тождество d = 2' : 'закрытая форма зеркального звена' }, d: lk.d });
  });
  // П-6 и П-7 для всех пар: параллельность — общий класс оси; боковое касание — ещё и общий класс плоскости.
  const parallelEstablished = (a, b) => a.tClass === b.tClass;
  const sideByConstruction = (a, b) => a.tClass === b.tClass && a.planeClass === b.planeClass;
  return { tori, rings, contacts, evidence: ev, conventions: conv, parallelEstablished, sideByConstruction };
}

module.exports = { build, ringLM1, circleRing, ringWidths, frame, InputError, NotYet };
