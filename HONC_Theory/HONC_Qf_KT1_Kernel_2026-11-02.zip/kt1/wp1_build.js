'use strict';
// HONC / Qf / R1 / КТ-1 — WP-1: построение (G-1, G-2, G-3 зеркальное, G-7) и свидетельства П-1…П-8 (интерфейс v6, § 2–3).
// Запись кольца — интерфейс v6, § 6.5: вилки полей и обязательные ширины (поправка G-2 к спецификации, 02.11).
// Звенья нити и навесов: зеркальные (δ = 0, закрытая форма d) и незеркальные (δ ≠ 0, d — корень G-4 с доказанной
// единственностью). Уравнение касания (fix, § 4.2) — корень по свободному параметру с существованием и единственностью;
// построение при этом идёт на всей вилке корня. Не удостоверено — исключение Unresolved с причиной, а не приближение.
const iv = require('./wp0_interval');
const vec = require('./wp1_vec');
const { perimeter } = require('./wp0_cert');
const D = require('./wp1_dual');
const { linkDistance, solveContact } = require('./wp2_linkroot');
const NV = 2;

const MIRROR_STATUS = '[Г] конвенция модели, Раунд 3а § 1';
class InputError extends Error {}
class NotYet extends Error {}
// Построение не удостоверено (единственность корня не доказана и т. п.) — протокол получает UNRESOLVED с причиной.
class Unresolved extends Error {}
const I = iv.I;

function num(o, k, ctx) {
  if (typeof o[k] !== 'number' || !Number.isFinite(o[k])) throw new InputError(`${ctx}: нет числа «${k}»`);
  return o[k];
}
// sin/cos угла в градусах; кратные 90° — точно (это значения, а не приближения).
function trigDeg(deg) {
  if (Number.isInteger(deg)) {
    const m = ((deg % 360) + 360) % 360;
    if (m === 0) return { s: I(0), c: I(1) };
    if (m === 90) return { s: I(1), c: I(0) };
    if (m === 180) return { s: I(0), c: I(-1) };
    if (m === 270) return { s: I(-1), c: I(0) };
  }
  const r = iv.deg2rad(iv.fromInput(deg));
  return { s: iv.sin(r), c: iv.cos(r) };
}
const isAxisAngle = deg => Number.isInteger(deg) && deg % 180 === 0;   // sin = 0 точно

// Рамка узла (§ 2): e_y — нормированная часть T, перпендикулярная e_z; при установленном T ⊥ e_z — сама T.
function frame(t) {
  const ez = t.ezIn;
  const ey = t.perpEz ? t.T : vec.normalize(vec.vsub(t.T, vec.vscale(ez, vec.dot(t.T, ez))));
  return { ex: vec.cross(ey, ez), ey, ez };
}

// Кольцо-окружность по тождеству: зеркальное звено, u ⊥ T ⇒ d = 2, T_B = T_A, обе касательные ⊥ хорде ⇒
// окружность радиуса 1 с центром в середине хорды; её длина 2π точно.
function circleRing(A, u, T) {
  return { C: vec.vadd(A, u), E1: u, E2: T, s1: I(1), s2: I(1), length: iv.TWO_PI, residual: I(0),
    basis: 'тождество: зеркальное звено при u ⊥ T — окружность радиуса 1 (длина 2π точно)', completeness: 'EXACT' };
}

// Кольцо ЛМ1 общего вида (G-2): пучок коник L_A·L_B − μ·y² = 0 в плоскости (X = u, Y ⊥ u вдоль T_A).
// Внутренности эллипсов семейства вложены: Q_μ2 = Q_μ1 − (μ2 − μ1)·y² <= Q_μ1 при μ2 > μ1, поэтому длина
// строго растёт по μ на (−∞, μ*), и корень уравнения длины 2π единствен. Вилка корня — делением пополам по знаку.
function ringLM1(A, TA, u, d, TB) {
  const X = u;
  const Y = vec.normalize(vec.vsub(TA, vec.vscale(X, vec.dot(TA, X))));
  const tax = vec.dot(TA, X), tay = vec.dot(TA, Y);
  let tbx = vec.dot(TB, X), tby = vec.dot(TB, Y);
  if (tay[0] <= 0) throw new Error('кольцо: ось T_A неотделима от хорды');
  if (tby[1] < 0) { tbx = iv.neg(tbx); tby = iv.neg(tby); } else if (tby[0] <= 0) throw new Error('кольцо: ось T_B неотделима от хорды');
  const p1 = iv.neg(tay), q1 = tax, p2 = iv.neg(tby), q2 = tbx, r2 = iv.mul(d, tby);
  const cA = iv.mul(p1, p2), cB = iv.add(iv.mul(p1, q2), iv.mul(q1, p2)), cD = iv.mul(p1, r2), cE = iv.mul(q1, r2);
  const q1q2 = iv.mul(q1, q2);
  if (cA[0] <= 0) throw new Error('кольцо: вырожденный пучок');
  const muStar = iv.sub(q1q2, iv.div(iv.sqr(cB), iv.mul(I(4), cA)));
  function ell(mu) {
    const cC = iv.sub(q1q2, mu);
    const det = iv.sub(iv.mul(iv.mul(I(4), cA), cC), iv.sqr(cB));
    if (det[0] <= 0) return null;
    const xc = iv.div(iv.sub(iv.mul(cB, cE), iv.mul(iv.mul(I(2), cC), cD)), det);
    const yc = iv.div(iv.sub(iv.mul(cB, cD), iv.mul(iv.mul(I(2), cA), cE)), det);
    const Fc = iv.mul(I(0.5), iv.add(iv.mul(cD, xc), iv.mul(cE, yc)));
    if (Fc[1] >= 0) return null;
    const tr = iv.add(cA, cC);
    const dd = iv.sqrt(iv.add(iv.sqr(iv.sub(cA, cC)), iv.sqr(cB)));
    const l1 = iv.mul(I(0.5), iv.add(tr, dd)), l2 = iv.mul(I(0.5), iv.sub(tr, dd));
    if (l2[0] <= 0) return null;
    const mF = iv.neg(Fc);
    return { cC, xc, yc, s1: iv.sqrt(iv.div(mF, l1)), s2: iv.sqrt(iv.div(mF, l2)) };
  }
  const P = mu => { const e = ell(mu); return e ? perimeter(e.s1, e.s2).value : null; };
  const T2 = iv.TWO_PI, top = muStar[0], scale = Math.max(1, Math.abs(top));
  let hi = null, lo = null;
  for (let k = 1; k < 120 && hi === null; k++) { const m = top - scale * 2 ** -k; const p = P(I(m)); if (p && p[0] > T2[1]) hi = m; }
  for (let k = 0; k < 120 && lo === null; k++) { const m = top - scale * 2 ** k; const p = P(I(m)); if (p && p[1] < T2[0]) lo = m; }
  if (hi === null || lo === null) throw new Error('кольцо: не найдена вилка корня уравнения длины');
  // Сужение: lo — точка, где длина заведомо меньше 2π; hi — заведомо больше. Если в середине знак не определён,
  // поджимаем оба края пробами в четвертях, пока хоть один край сдвигается.
  const side = m => { const p = P(I(m)); return !p ? 0 : p[0] > T2[1] ? 1 : p[1] < T2[0] ? -1 : 0; };
  for (let k = 0; k < 600; k++) {
    const m = lo + (hi - lo) / 2;
    if (!(m > lo && m < hi)) break;
    const sm = side(m);
    if (sm === 1) { hi = m; continue; }
    if (sm === -1) { lo = m; continue; }
    const m1 = lo + (m - lo) / 2, m2 = m + (hi - m) / 2;
    let moved = false;
    if (m1 > lo && side(m1) === -1) { lo = m1; moved = true; }
    if (m2 < hi && side(m2) === 1) { hi = m2; moved = true; }
    if (!moved) break;
  }
  const muI = [lo, hi];
  const e = ell(muI);
  if (!e) throw new Error('кольцо: эллипс на вилке корня не построен');
  // Главные оси. Оба собственных вектора удовлетворяют tg 2θ = cB/(cA − cC). Угол берётся от того вектора,
  // для которого atan2 далёк от разреза: при cA − cC > 0 — вектор большего собственного значения l1
  // (вдоль него полуось s1), при cA − cC < 0 — вектор l2 (вдоль него s2). При cB ≈ 0 и cA ≈ cC (почти окружность)
  // ориентация не определена — кольцо заключается в кольцевую область: точка C + ρ(cos t·X + sin t·Y), ρ ∈ hull(s1, s2).
  const C = vec.vadd(A, vec.vadd(vec.vscale(X, e.xc), vec.vscale(Y, e.yc)));
  const amc = iv.sub(cA, e.cC);
  let E1, E2, s1 = e.s1, s2 = e.s2, annulus = false;
  if (amc[0] > 0 || amc[1] < 0) {
    const pos = amc[0] > 0;
    const th = iv.mul(I(0.5), (pos ? iv.atan2(cB, amc) : iv.atan2(iv.neg(cB), iv.neg(amc))).v);
    const ct = iv.cos(th), st = iv.sin(th);
    const Ea = vec.vadd(vec.vscale(X, ct), vec.vscale(Y, st));
    const Eb = vec.vadd(vec.vscale(X, iv.neg(st)), vec.vscale(Y, ct));
    if (pos) { E1 = Ea; E2 = Eb; } else { E2 = Ea; E1 = vec.vneg(Eb); }
  } else {
    annulus = true; E1 = X; E2 = Y; s1 = s2 = iv.hull(e.s1, e.s2);
  }
  const length = perimeter(e.s1, e.s2).value;
  return { C, E1, E2, s1, s2, X, Y, mu: muI, length, residual: iv.sub(length, T2), annulus,
    basis: 'корень уравнения длины (AGM); единственность — вложенность семейства', completeness: 'CERTIFIED' };
}

// Ширины вилок кольца (интерфейс v6, § 6.5). Ширина — hi − lo с округлением вверх: при округлении к ближайшему
// ошибка не больше половины единицы последнего разряда, и следующее вверх число её покрывает. Вилка из одного числа — 0.
const widthOf = a => (a == null ? null : a[0] === a[1] ? 0 : iv.nextUp(a[1] - a[0]));
const widthVec = v => Math.max(...v.map(widthOf));
function ringWidths(r) {
  const widths = { C: widthVec(r.C), E1: widthVec(r.E1), E2: widthVec(r.E2), s1: widthOf(r.s1), s2: widthOf(r.s2),
    length: widthOf(r.length), residual: widthOf(r.residual) };
  return { widths, width_max: Math.max(widths.C, widths.E1, widths.E2, widths.s1, widths.s2) };
}
const ringRecord = (head, ring) => ({ ...head, source: 'construction', ...ring, ...ringWidths(ring) });

// Ось следующего тора (интерфейс v6, § 2): T′ = T − 2(T·e)·e; поворот T′ на δ вокруг n = норм(e × T) по правилу
// правой руки. n ⊥ T′ (T′ лежит в плоскости e, T), поэтому формула Родрига сводится к T′·cos δ + (n × T′)·sin δ.
// Дуальная форма — для производных по свободному параметру (слот 1).
function axisDual(T, eD, td) {
  const TD = D.vlift(T, NV);
  const te = D.dot(TD, eD);
  const Tp = D.vsub(TD, D.vscale(eD, D.scale(te, I(2))));
  if (!td) return Tp;
  const n = D.normalize(D.cross(eD, TD));
  return D.vadd(D.vscaleI(Tp, td.c), D.vscaleI(D.cross(n, Tp), td.s));
}
function makeSpec(T, eDualFn, ddeg) {
  const td = ddeg === 0 ? null : trigDeg(ddeg);
  const geoDual = P => { const e = eDualFn(P); return { e, TH: axisDual(T, e, td) }; };
  return { geoDual, geo: P => { const g = geoDual(P); return { e: D.val(g.e), TH: D.val(g.TH) }; } };
}

// Звено из тора `from` в направлении u (вилка-вектор) с параметром δ.
//  δ = 0 — зеркальное: d по закрытой форме (G-3), конвенция [Г];
//  δ ≠ 0 — незеркальное: d — корень G-4 вдоль u, единственный на [0, ∞) (wp2_linkroot.js, WP2_Roots_Notes.md).
function link(from, u, uPerpT, delta, ctx) {
  const T = from.T;
  if (delta !== 0) {
    const spec = makeSpec(T, () => D.vlift(u, NV), delta);
    const r = linkDistance({ A: from.A, T }, spec);
    if (!r.ok) { if (r.kernelError) throw new Error(`${ctx}: ${r.reason}`); throw new Unresolved(`${ctx}: ${r.reason}`); }
    const TH = spec.geo([0, 0]).TH;
    const A2 = vec.vadd(from.A, vec.vscale(u, r.d));
    return { u, d: r.d, A2, T2: TH, ring: ringLM1(from.A, T, u, r.d, TH), identity: false,
      dBasis: { form: 'корень G-4 (незеркальное звено)', proof: r.proof, method: r.method } };
  }
  const Tn = uPerpT ? T : vec.vsub(T, vec.vscale(u, iv.mul(I(2), vec.dot(T, u))));
  let d;
  if (uPerpT) d = I(2);
  else { const c = vec.dot(T, u); let w = iv.sub(I(1), iv.sqr(c)); w = [Math.max(0, w[0]), Math.max(0, w[1])]; d = iv.add(iv.sqrt(w), I(1)); }
  const A2 = vec.vadd(from.A, vec.vscale(u, d));
  const ring = uPerpT ? circleRing(from.A, u, T) : ringLM1(from.A, T, u, d, Tn);
  return { u, d, A2, T2: Tn, ring, identity: uPerpT,
    dBasis: { form: uPerpT ? 'тождество d = 2' : 'закрытая форма зеркального звена' } };
}

// Направление навеса как дуальная функция свободного параметра (радианы, слот 1). Остальные параметры — числа входа.
function hangDirection(fr, side, h, free, ctx) {
  const s = I(side);
  const sc = name => {
    if (name === free) return P => { const x = D.X(P, 1, NV); return { s: D.sin(x), c: D.cos(x) }; };
    const t = trigDeg(num(h, name, ctx));
    return () => ({ s: D.C(t.s, NV), c: D.C(t.c, NV) });
  };
  const ex = D.vlift(fr.ex, NV), ey = D.vlift(fr.ey, NV), ez = D.vlift(fr.ez, NV);
  if (h.coords === 'rho-psi') {
    const R = sc('rho'), Ps = sc('psi');
    const rhoZero = free !== 'rho' && num(h, 'rho', ctx) === 0;
    const eD = P => {
      if (rhoZero) return D.vscaleI(ex, s);
      const r = R(P), p = Ps(P);
      const side1 = D.vscaleI(D.vscale(ex, r.c), s);
      const tilt = D.vadd(D.vscale(ez, D.neg(p.c)), D.vscale(ey, p.s));
      return D.vadd(side1, D.vscale(tilt, r.s));
    };
    // e ⊥ T при всех значениях свободного параметра — только из точных значений входа
    const perpAll = (free !== 'psi' && isAxisAngle(num(h, 'psi', ctx))) || (free !== 'rho' && num(h, 'rho', ctx) === 0);
    return { eD, perpAll };
  }
  if (h.coords === 'alpha-lambda') {
    const A = sc('alpha'), L = sc('lambda');
    const eD = P => {
      const a = A(P), l = L(P);
      const hor = D.vadd(D.vscaleI(D.vscale(ex, a.c), s), D.vscale(ey, a.s));
      return D.vsub(D.vscale(hor, l.c), D.vscale(ez, l.s));
    };
    const perpAll = free !== 'alpha' && isAxisAngle(num(h, 'alpha', ctx));
    return { eD, perpAll };
  }
  throw new InputError(`${ctx}: coords должен быть rho-psi или alpha-lambda`);
}
const FREE = { 'rho-psi': ['rho', 'psi'], 'alpha-lambda': ['alpha', 'lambda'] };

// Построение по описанию случая (интерфейс § 4.1).
function build(cs) {
  const ev = [], conv = [], tori = [], rings = [], contacts = [];
  let tClassN = 0, planeN = 0, ringPlaneN = 0, prevRingPlane = null, prevDelta = null;
  const th = cs.thread;
  if (!th || !Number.isInteger(th.n) || th.n < 1) throw new InputError('thread.n: нужно целое >= 1');
  if (!Array.isArray(th.links) || th.links.length !== th.n) throw new InputError(`thread.links: нужно ровно ${th.n} записей`);
  tori.push({ name: 'T0', A: vec.V(0, 0, 0), T: vec.V(0, 1, 0), ezIn: vec.V(0, 0, 1), perpEz: true, tClass: tClassN++, planeClass: planeN++ });
  ev.push({ rule: 'П-1', fact: 'T0 ⊥ e_z', objects: ['T0'] });
  const frames = [];
  for (let k = 0; k < th.n; k++) {
    const L = th.links[k], ctx = `звено ${k}`;
    const tdeg = num(L, 'theta', ctx), pdeg = num(L, 'phi', ctx), ddeg = num(L, 'delta', ctx);
    const t = tori[k], fr = frame(t); frames.push(fr);
    const tt = trigDeg(tdeg), tp = trigDeg(pdeg);
    const u = tdeg === 0 ? fr.ez : vec.vadd(vec.vscale(fr.ez, tt.c), vec.vscale(vec.vadd(vec.vscale(fr.ex, tp.c), vec.vscale(fr.ey, tp.s)), tt.s));
    const uPerpT = t.perpEz && (tdeg === 0 || isAxisAngle(pdeg));
    if (uPerpT) ev.push({ rule: 'П-2', fact: `u ⊥ T (звено ${k})`, objects: [t.name], premises: [t.perpEz ? 'T ⊥ e_z' : null, tdeg === 0 ? 'θ = 0' : 'φ ∈ {0°, 180°}'] });
    const lk = link(t, u, uPerpT, ddeg, ctx);
    if (ddeg === 0) conv.push({ link: `R${k}`, mirror: true, status: MIRROR_STATUS });
    const last = k === th.n - 1;
    // Плоскость кольца — A + span(u, T_A). При θ_k кратном 180° (u_k = ±u_{k−1}) и зеркальном звене k−1
    // (T_k ∈ span(T_{k−1}, u_{k−1})) она совпадает с плоскостью R_{k−1} — тождество построения (WP3_Rings_Notes.md, § 3).
    const samePlane = k > 0 && isAxisAngle(tdeg) && prevDelta === 0;
    const plane_class = samePlane ? prevRingPlane : ringPlaneN++;
    const plane_basis = samePlane
      ? { rule: 'одна плоскость с R' + (k - 1), premises: [`θ_${k} = ${tdeg}° кратно 180° (u_${k} = ±u_${k - 1})`, `звено ${k - 1} зеркальное, δ = 0 (T_${k} ∈ span(T_${k - 1}, u_${k - 1}))`] }
      : { rule: 'собственная плоскость', premises: [`A_${k} + span(u_${k}, T_${k})`] };
    prevRingPlane = plane_class; prevDelta = ddeg;
    rings.push(ringRecord({ name: `R${k}`, owner: t.name, threads: last ? [t.name] : [t.name, `T${k + 1}`], free: last, plane_class, plane_basis }, lk.ring));
    if (!last) {
      const same = lk.identity;     // П-3: T_{k+1} = T_k
      const nt = { name: `T${k + 1}`, A: lk.A2, T: lk.T2, ezIn: u, perpEz: same, tClass: same ? t.tClass : tClassN++, planeClass: same ? t.planeClass : planeN++ };
      tori.push(nt);
      if (same) { ev.push({ rule: 'П-3', fact: `T${k + 1} = T${k}`, objects: [t.name, nt.name] }); ev.push({ rule: 'П-4', fact: `T${k + 1} ⊥ e_z`, objects: [nt.name] }); }
      contacts.push({ pair: [t.name, nt.name], cls: 'LINK', existence: 'IMPOSED',
        basis: { rule: 'П-8а', kind: 'linked-pair', ...lk.dBasis }, d: lk.d });
    }
  }
  const nThread = tori.length;
  (cs.hangs || []).forEach((h, j) => {
    const ctx = `навес ${j + 1}`, name = `H${j + 1}`;
    if (!Number.isInteger(h.host) || h.host < 0 || h.host >= nThread) throw new InputError(`${ctx}: нет тора-хозяина ${h.host}`);
    if (h.side !== 1 && h.side !== -1) throw new InputError(`${ctx}: side должен быть 1 или −1`);
    if (!FREE[h.coords]) throw new InputError(`${ctx}: coords должен быть rho-psi или alpha-lambda`);
    const host = tori[h.host], fr = frames[h.host] || frame(host);
    const ddeg = num(h, 'delta', ctx);
    let free = null, fx = null;
    if (h.fix !== undefined) {
      fx = h.fix;
      if (!fx || fx.kind !== 'contact') throw new InputError(`${ctx}: fix.kind должен быть contact`);
      if (!FREE[h.coords].includes(fx.free)) throw new InputError(`${ctx}: fix.free для ${h.coords} — ${FREE[h.coords].join(' или ')}`);
      if (h[fx.free] !== null) throw new InputError(`${ctx}: свободный параметр ${fx.free} во входе должен быть null`);
      if (!Array.isArray(fx.bracket) || fx.bracket.length !== 2 || !(fx.bracket[0] < fx.bracket[1])) throw new InputError(`${ctx}: fix.bracket — [lo, hi], lo < hi`);
      free = fx.free;
    }
    const dir = hangDirection(fr, h.side, h, free, ctx);
    const ePerp = host.perpEz && dir.perpAll;
    const identity = ePerp && ddeg === 0;
    const spec = makeSpec(host.T, dir.eD, ddeg);
    let P = [0, 0], d, e, TH, dBasis, fixInfo = null;
    if (fx) {
      const withT = tori.find(t => t.name === fx.with);
      if (!withT) throw new InputError(`${ctx}: fix.with — нет тора ${fx.with}`);
      const br = [iv.deg2rad(iv.fromInput(fx.bracket[0]))[0], iv.deg2rad(iv.fromInput(fx.bracket[1]))[1]];
      const sol = solveContact({ host: { A: host.A, T: host.T }, withT: { A: withT.A, T: withT.T }, spec,
        kind: identity ? 'identity' : ddeg === 0 ? 'mirror' : 'general', bracket: br });
      if (!sol.ok) throw new Unresolved(`${ctx}: ${sol.reason}`);
      P = sol.p; d = sol.d;
      fixInfo = { free, with: fx.with, bracket_deg: fx.bracket, root_deg: iv.rad2deg(P), root_rad: P, uniqueness: sol.uniqueness, dProof: sol.dProof };
    }
    const g = spec.geo(P);
    e = g.e;
    if (identity) { d = I(2); TH = host.T; dBasis = { form: 'тождество d = 2' }; }
    else if (ddeg === 0) {
      TH = g.TH;
      if (!d) { const c = vec.dot(host.T, e); let w = iv.sub(I(1), iv.sqr(c)); w = [Math.max(0, w[0]), Math.max(0, w[1])]; d = iv.add(iv.sqrt(w), I(1)); }
      dBasis = { form: 'закрытая форма зеркального звена' };
    } else {
      TH = g.TH;
      if (!d) {
        const r = linkDistance({ A: host.A, T: host.T }, spec, P);
        if (!r.ok) { if (r.kernelError) throw new Error(`${ctx}: ${r.reason}`); throw new Unresolved(`${ctx}: ${r.reason}`); }
        d = r.d; dBasis = { form: 'корень G-4 (незеркальное звено)', proof: r.proof, method: r.method };
      } else dBasis = { form: 'корень G-4 (незеркальное звено)', proof: fixInfo.dProof };
    }
    const A2 = vec.vadd(host.A, vec.vscale(e, d));
    const ring = identity ? circleRing(host.A, e, host.T) : ringLM1(host.A, host.T, e, d, TH);
    if (ePerp) ev.push({ rule: 'П-5', fact: `e ⊥ T хозяина (${name})`, objects: [host.name, name] });
    if (ddeg === 0) conv.push({ link: `RH${j + 1}`, mirror: true, status: MIRROR_STATUS });
    const ht = { name, A: A2, T: TH, host: host.name, tClass: identity ? host.tClass : tClassN++, planeClass: identity ? host.planeClass : planeN++, fix: fixInfo };
    tori.push(ht);
    if (identity) ev.push({ rule: 'П-5', fact: `T(${name}) = T(${host.name})`, objects: [host.name, name] });
    rings.push(ringRecord({ name: `RH${j + 1}`, owner: name, threads: [name, host.name], free: false, plane_class: ringPlaneN++,
      plane_basis: { rule: 'собственная плоскость', premises: [`A(${host.name}) + span(e, T(${host.name}))`] } }, ring));
    contacts.push({ pair: [host.name, name], cls: 'LINK', existence: 'IMPOSED', basis: { rule: 'П-8а', kind: 'linked-pair', ...dBasis }, d });
    if (fixInfo) contacts.push({ pair: [fx.with, name], cls: 'CONTACT-ONLY', existence: 'IMPOSED',
      basis: { rule: 'П-8б', equation: `зазор G-4 (${fx.with}, ${name}) = 0`, free, bracket_deg: fx.bracket, root_deg: fixInfo.root_deg, uniqueness: fixInfo.uniqueness } });
  });
  // П-6 и П-7 для всех пар: параллельность — общий класс оси; боковое касание — ещё и общий класс плоскости.
  const parallelEstablished = (a, b) => a.tClass === b.tClass;
  const sideByConstruction = (a, b) => a.tClass === b.tClass && a.planeClass === b.planeClass;
  return { tori, rings, contacts, evidence: ev, conventions: conv, parallelEstablished, sideByConstruction };
}

module.exports = { build, ringLM1, circleRing, ringWidths, frame, makeSpec, axisDual, hangDirection, InputError, NotYet, Unresolved };
