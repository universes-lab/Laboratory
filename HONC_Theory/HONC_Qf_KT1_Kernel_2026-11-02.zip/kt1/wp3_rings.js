'use strict';
// HONC / Qf / R1 / КТ-1 — WP-3: кольца 1D–1D и топология сцепления (спецификация R-1…R-6, G-6; интерфейс v6, § 6.4).
// Статическая часть КТ-1. Обоснования — WP3_Rings_Notes.md.
//  Разбор пары — один и только один случай:
//   общий касп (R-1) → иначе одна плоскость по построению (R-4) → иначе угол плоскостей:
//   больше θ_min доказано — R-2; меньше θ_min доказано — R-5 near-parallel; иначе R-5 relation-undetermined.
//  R-3 (различные параллельные) в КТ-1 не входит: параллельность без тождества построения не устанавливается,
//  такие пары получают R-5 UNRESOLVED.
//  Все вычисления — на полных вилках полей кольца (правило полной вилки, интерфейс § 6.5).
const iv = require('./wp0_interval');
const vec = require('./wp1_vec');
const L = require('./wp0_labels');
const { ringAt, paramAt, ThreadError } = require('./wp2_ringtorus');

const I = iv.I, ONE = I(1), HALF = I(0.5), TWO = I(2);
// Объявленный наименьший угол между плоскостями колец для разбора R-2 (R-5, TB-3). Обоснование — WP3_Rings_Notes.md, § 4.
const THETA_MIN_DEG = 1;
const SIN_THETA_MIN = iv.sin(iv.deg2rad(I(THETA_MIN_DEG)));
const deg = r => iv.rad2deg(r);
const ringWidth = r => (r.width_max !== undefined ? r.width_max : 0);
const wtxt = (...rs) => (rs.some(ringWidth) ? `; ring-enclosure ${rs.map(r => `${r.name} ${ringWidth(r)}`).join(', ')}` : '');
const unitNormal = r => vec.normalize(vec.cross(r.E1, r.E2));
const halfWidth = x => (x[1] - x[0]) / 2;

// ---------------- общий касп: посылка и полуплоскость ----------------
// Посылка «кольцо проходит через A с касательной вдоль T, T в плоскости кольца» — совместимость вилок невязок с нулём.
// Несовместимость — ошибка входа (ThreadError), как в G-5б.
function cuspPremise(ring, cusp) {
  const n = vec.cross(ring.E1, ring.E2);
  const res = [vec.dot(cusp.T, n)];
  if (ring.annulus) {
    const w = vec.vsub(cusp.A, ring.C);
    res.push(vec.dot(w, n));
    const r2 = vec.norm2(w), s2 = iv.sqr(iv.hull(ring.s1, ring.s2));
    if (r2[1] < s2[0] || r2[0] > s2[1]) res.push(I(1));
  } else {
    const tA = paramAt(ring, cusp.A);
    if (!tA) return false;
    const g = ringAt(ring, tA);
    res.push(...vec.vsub(g.P, cusp.A), ...vec.cross(g.P1, cusp.T));
  }
  if (res.some(x => !iv.containsZero(x))) throw new ThreadError(`R-1: посылка «${ring.name} проходит через касп${cusp.name ? ' ' + cusp.name : ''}» несовместима с вилками (невязка отделена от 0)`);
  return true;
}
// Направление полуплоскости кольца в каспе: единичный ν ⊥ T в плоскости кольца, к центру эллипса.
// Кольцо касается прямой A + sT в A и выпукло, поэтому лежит в полуплоскости {A + sT + rν, r ≥ 0} и касается её края только в A.
function halfplaneDir(ring, cusp) {
  try {
    const T = vec.normalize(cusp.T);
    const w = vec.vsub(ring.C, cusp.A);
    return vec.normalize(vec.vsub(w, vec.vscale(T, vec.dot(w, T))));
  } catch (e) { return null; }
}
const angleBetween = (a, b) => iv.atan2(iv.sqrt(vec.norm2(vec.cross(a, b))), vec.dot(a, b)).v;   // ∈ [0, π]
// Абсолютный угол полуплоскости в рамке тора каспа: atan2(ν·e_z, ν·e_x). У разреза (±180°) — поворот на π: значение в (90°, 270°).
function absAngle(n, fr) {
  const y = vec.dot(n, fr.ez), x = vec.dot(n, fr.ex);
  let a = iv.atan2(y, x);
  if (!a.cut) return deg(a.v);
  a = iv.atan2(iv.neg(y), iv.neg(x));
  return a.cut ? null : deg(iv.add(a.v, iv.PI));
}

// ---------------- R-1 ----------------
function ringPairCusp(r1, r2, cusp, ids = {}, fr = null) {
  const id = ids.id || `RR:${r1.name}:${r2.name}`;
  const base = { id, req: 'R-1', objects: [r1.name, r2.name], quantity: 'halfplane_angle', case: 'shared-cusp', cusp: cusp.name || null };
  const prem = [cuspPremise(r1, cusp), cuspPremise(r2, cusp)];
  const n1 = halfplaneDir(r1, cusp), n2 = halfplaneDir(r2, cusp);
  if (prem.includes(false) || !n1 || !n2) return L.makeCheck({ ...base, value: [0, 180], completeness: 'UNRESOLVED', verdict: 'UNRESOLVED', level: 'L1', contact_class: 'UNRESOLVED CONTACT',
    reason: 'R-1: точка каспа на кольце или направление полуплоскости не определены' });
  const ang = deg(angleBetween(n1, n2));
  const halfplane_angles = fr ? [absAngle(n1, fr), absAngle(n2, fr)] : null;
  if (vec.dot(n1, n2)[1] < 1) {   // ν1 ≠ ν2 доказано
    return L.makeCheck({ ...base, value: ang, completeness: 'EXACT', verdict: 'PASSED', level: 'L2', contact_class: 'STRUCTURAL', halfplane_angles,
      basis: 'полуплоскости различны ⇒ встреча колец только в каспе (закрытая форма на полных вилках)' });
  }
  return L.makeCheck({ ...base, value: ang, completeness: 'UNRESOLVED', verdict: 'UNRESOLVED', level: 'L1', contact_class: 'UNRESOLVED CONTACT', halfplane_angles,
    reason: `R-1: полуплоскости колец не различены — встреча вне каспа не исключена, класс встречи в каспе не решён${wtxt(r1, r2)}` });
}

// ---------------- R-2 ----------------
// Кольцо на прямой x = p0 + λm: (β²+δ²)λ² + 2(αβ+γδ)λ + (α²+γ²−1) = 0, где X = α + βλ, Y = γ + δλ —
// нормированные координаты вдоль E1/s1, E2/s2. Используется в G-6 (прямая A + sν, p0 и m из вилок одного кольца).
function lineSet(ring, p0, m) {
  const w = vec.vsub(p0, ring.C);
  const al = iv.div(vec.dot(w, ring.E1), ring.s1), be = iv.div(vec.dot(m, ring.E1), ring.s1);
  const ga = iv.div(vec.dot(w, ring.E2), ring.s2), de = iv.div(vec.dot(m, ring.E2), ring.s2);
  const A = iv.add(iv.sqr(be), iv.sqr(de));
  const B = iv.add(iv.mul(al, be), iv.mul(ga, de));
  const Cc = iv.sub(iv.add(iv.sqr(al), iv.sqr(ga)), ONE);
  return { A, B, Cc, disc: iv.sub(iv.sqr(B), iv.mul(A, Cc)) };
}
// Точки кольца на ℓ = P ∩ Q (R-2) — в нормированных координатах самого кольца: x = C + s1·X·E1 + s2·Y·E2, X² + Y² = 1,
// и n·x = d — плоскость другого кольца. Тогда pX + qY = r, p = s1(n·E1), q = s2(n·E2), r = n·(C_other − C).
// Точки: (X, Y) = (r/D)(p, q) ± (√(D − r²)/D)(−q, p), D = p² + q².
// Координата на ℓ — λ = x·m̃, где m̃ — точный (числовой) вектор с m̃·(n1 × n2) > 0: на ℓ отображение x ↦ x·m̃ взаимно
// однозначно и сохраняет порядок вдоль n1 × n2. Общая точка p0 не нужна — нет зависимости вилок через неё.
// У кольцевой области (annulus) s1 = s2 = вилка радиусов: семейства «+» и «−» покрывают по одной точке истинного эллипса.
function ringOnLine(ring, n, Cother, mt) {
  const p = iv.mul(ring.s1, vec.dot(n, ring.E1)), q = iv.mul(ring.s2, vec.dot(n, ring.E2));
  const r = vec.dot(n, vec.vsub(Cother, ring.C));
  const D = iv.add(iv.sqr(p), iv.sqr(q));
  if (!(D[0] > 0)) return null;
  const disc = iv.sub(D, iv.sqr(r));                         // > 0 ⇔ ℓ проходит внутри кольца
  const disc_margin = iv.sub(iv.div(iv.sqr(r), D), ONE);     // (расстояние от центра до ℓ)² − 1 в нормированных координатах; > 0 ⇒ хорды нет
  if (disc[1] < 0) return { kind: 'none', disc, disc_margin, pts: [], xs: [] };
  const sq = iv.sqrt([Math.max(0, disc[0]), disc[1]]);
  const X0 = iv.div(iv.mul(r, p), D), Y0 = iv.div(iv.mul(r, q), D);
  const dX = iv.div(iv.mul(iv.neg(q), sq), D), dY = iv.div(iv.mul(p, sq), D);
  const at = sg => {
    const X = sg > 0 ? iv.add(X0, dX) : iv.sub(X0, dX), Y = sg > 0 ? iv.add(Y0, dY) : iv.sub(Y0, dY);
    const x = vec.vadd(ring.C, vec.vadd(vec.vscale(ring.E1, iv.mul(ring.s1, X)), vec.vscale(ring.E2, iv.mul(ring.s2, Y))));
    return { x, lam: vec.dot(x, mt) };
  };
  const u = at(1), v = at(-1);
  if (disc[0] > 0 && !overlap(u.lam, v.lam)) {
    const [lo, hi] = u.lam[1] < v.lam[0] ? [u, v] : [v, u];
    return { kind: 'chord', disc, disc_margin, pts: [lo.lam, hi.lam], xs: [lo.x, hi.x] };
  }
  // касание ℓ не исключено (или концы неразличимы): все точки кольца на ℓ — в одной вилке
  return { kind: 'tangent', disc, disc_margin, pts: [iv.hull(u.lam, v.lam)], xs: [u.x.map((c, k) => iv.hull(c, v.x[k]))] };
}
const overlap = (x, y) => !(x[1] < y[0] || y[1] < x[0]);
const boxOverlap = (p, q) => p.every((x, k) => overlap(x, q[k]));
// Точка x строго внутри хорды S: true / false / null (не решено). У хорды-касания и пустой — false
// (вызывается только вне встреч: тогда x не пересекается с вилкой касания).
function insideSet(x, S) {
  if (S.kind !== 'chord') return false;
  const [c0, c1] = S.pts;
  if (x[0] > c0[1] && x[1] < c1[0]) return true;
  if (x[1] < c0[0] || x[0] > c1[1]) return false;
  return null;
}
const crossingOf = S => (S.kind === 'chord' ? 'трансверсально' : 'касание ℓ не исключено');
function localTypes(S1, S2) {
  const t = [S1, S2].filter(S => S.kind === 'tangent').length;
  return t === 0 ? ['поперечная'] : t === 1 ? ['поперечная', 'полукасательная'] : ['поперечная', 'полукасательная', 'двукасательная'];
}
const fmtSet = S => ({ kind: S.kind, endpoints: S.kind === 'chord' ? S.pts : null, tangent_region: S.kind === 'tangent' ? S.pts[0] : null,
  points: S.xs, disc_margin: S.disc_margin });

function ringPairNonparallel(r1, r2, n1, n2, angle, ids, tmin = THETA_MIN_DEG) {
  const id = ids.id || `RR:${r1.name}:${r2.name}`;
  const nn = vec.cross(n1, n2);
  const mt = vec.vmid(vec.normalize(nn)).map(x => I(x));       // точный вектор вдоль ℓ
  const base = { id, req: 'R-2', objects: [r1.name, r2.name], quantity: 'meeting_margin', case: 'nonparallel', plane_angle_deg: angle, theta_min_deg: tmin,
    line_coordinate: mt.map(x => x[0]) };
  const S1 = vec.dot(mt, nn)[0] > 0 ? ringOnLine(r1, n2, r2.C, mt) : null;
  const S2 = S1 ? ringOnLine(r2, n1, r1.C, mt) : null;
  if (!S1 || !S2) return L.makeCheck({ ...base, value: [-Number.MAX_VALUE, Number.MAX_VALUE], completeness: 'UNRESOLVED', verdict: 'UNRESOLVED', level: 'L1',
    reason: 'R-2: координата на ℓ или проекция нормали не установлены' });
  base.chords = [fmtSet(S1), fmtSet(S2)];
  // Встреча колец ⇔ общая точка их множеств на ℓ (Раунд 3б, § 1): пересекаются вилки и по λ, и в пространстве.
  // ε_ℓ — сумма полуширин пересёкшихся вилок λ (интерфейс § 8).
  const meets = [];
  S1.pts.forEach((x, i) => S2.pts.forEach((y, j) => {
    if (!overlap(x, y) || !boxOverlap(S1.xs[i], S2.xs[j])) return;
    meets.push({ lambda: [x, y], point: S1.xs[i].map((c, k) => [Math.max(c[0], S2.xs[j][k][0]), Math.min(c[1], S2.xs[j][k][1])]), epsilon_l: halfWidth(x) + halfWidth(y), ends: [i, j] });
  }));
  // Функция запаса (ИФ-3): наименьшее расстояние по λ между точками колец на ℓ; если у кольца нет хорды — (расстояние до ℓ)² − 1.
  let value, margin_kind;
  if (S1.pts.length && S2.pts.length) {
    let lo = Infinity, hi = Infinity;
    for (const x of S1.pts) for (const y of S2.pts) { const s = iv.abs(iv.sub(x, y)); lo = Math.min(lo, s[0]); hi = Math.min(hi, s[1]); }
    value = [lo, hi]; margin_kind = 'chord_endpoints';
  } else {
    const ab = [S1, S2].filter(S => S.kind === 'none').sort((p, q) => q.disc_margin[0] - p.disc_margin[0])[0];
    value = ab.disc_margin; margin_kind = 'chord_absent';
  }
  if (meets.length) {
    const met1 = new Set(meets.map(m => m.ends[0])), met2 = new Set(meets.map(m => m.ends[1]));
    const ind = { pi: S1.pts.map((x, i) => (met1.has(i) ? null : insideSet(x, S2))), rho: S2.pts.map((y, j) => (met2.has(j) ? null : insideSet(y, S1))) };
    return L.makeCheck({ ...base, value, margin_kind, completeness: 'UNRESOLVED', verdict: 'UNRESOLVED', level: 'L1', contact_class: 'UNRESOLVED CONTACT', indicators: ind,
      meeting: { local_type: localTypes(S1, S2), crossing: [crossingOf(S1), crossingOf(S2)], at: meets.map(({ ends, ...m }) => m) },
      reason: `R-2: статическая встреча колец (вилки точек на ℓ пересекаются, ε_ℓ ${Math.max(...meets.map(x => x.epsilon_l))}): «до» и «после» нет — класс встречи не решается в статике${wtxt(r1, r2)}` });
  }
  // Встречи нет. Индикаторы — по λ; если вилки по λ пересекаются, а в пространстве нет, индикатор не решён.
  const indicators = { pi: S1.pts.map(x => insideSet(x, S2)), rho: S2.pts.map(y => insideSet(y, S1)) };
  const undecided = [...indicators.pi, ...indicators.rho].includes(null);
  let lk = 0, lk_basis;
  if (undecided) { lk = null; lk_basis = null; }
  else if (S1.kind === 'chord' && S2.kind === 'chord') {
    const nIn = indicators.rho.filter(Boolean).length;
    // Знак: в верхнем конце хорды (вдоль n1 × n2) касательная кольца 2 имеет положительную составляющую по n2 × m,
    // а (n2 × m)·n1 = |n1 × n2| > 0; поэтому прокол верхним концом даёт +1, нижним −1 (WP3_Rings_Notes.md, § 2.3).
    if (nIn === 1) { lk = indicators.rho[1] ? 1 : -1; lk_basis = 'хорды чередуются: ровно одна точка кольца 2 внутри диска 1'; }
    else lk_basis = nIn === 0 ? 'хорды не чередуются: кольцо 2 не прокалывает диск 1' : 'хорды не чередуются: кольцо 2 прокалывает диск 1 дважды';
  } else lk_basis = S1.kind === 'none' || S2.kind === 'none' ? 'одно из колец не пересекает ℓ' : 'касание ℓ вдали от точек другого кольца: проколов диска нет';
  if (undecided) return L.makeCheck({ ...base, value, margin_kind, completeness: 'UNRESOLVED', verdict: 'UNRESOLVED', level: 'L1', indicators, lk,
    reason: `R-2: встреча исключена в пространстве, но порядок точек на ℓ не решён — индикаторы и Lk не определены${wtxt(r1, r2)}` });
  return L.makeCheck({ ...base, value, margin_kind, completeness: 'EXACT', verdict: 'PASSED', level: 'L2', indicators, lk, lk_basis,
    lk_orientation: 'кольцо обходится по росту t (E1 → E2), диск ориентирован нормалью E1 × E2',
    basis: 'встречи нет: вилки точек колец на ℓ не пересекаются (закрытая форма на полных вилках)' });
}

// ---------------- R-4 ----------------
// Кольца в одной плоскости (установлено построением). Разделяющее направление d: max_1 d·x < min_2 d·x,
// max = d·C + √((d·E1)²s1² + (d·E2)²s2²) — опорная функция (верна при любом векторе d). Кандидаты d — числа (точные векторы);
// найденный d — доказательство разделения сам по себе, независимо от того, как он подобран.
function support(ring, d) {
  const w = iv.sqrt(iv.add(iv.sqr(iv.mul(vec.dot(d, ring.E1), ring.s1)), iv.sqr(iv.mul(vec.dot(d, ring.E2), ring.s2))));
  const c = vec.dot(d, ring.C);
  return { hi: iv.add(c, w), lo: iv.sub(c, w) };
}
function ringPairCoplanar(r1, r2, ids, plane_basis) {
  const id = ids.id || `RR:${r1.name}:${r2.name}`;
  const base = { id, req: 'R-4', objects: [r1.name, r2.name], quantity: 'separation', case: 'coplanar', plane_basis };
  const e1 = vec.vmid(r1.E1), e2 = vec.vmid(r1.E2), c1 = vec.vmid(r1.C), dc = vec.vmid(r2.C).map((x, k) => x - c1[k]);
  const dotf = (p, q) => p[0] * q[0] + p[1] * q[1] + p[2] * q[2];
  const phi0 = Math.atan2(dotf(dc, e2), dotf(dc, e1));
  let best = null;
  for (let k = 0; k < 72; k++) {
    const phi = phi0 + (k % 2 ? 1 : -1) * Math.ceil(k / 2) * (Math.PI / 36);
    const d = [0, 1, 2].map(j => I(Math.cos(phi) * e1[j] + Math.sin(phi) * e2[j]));
    const margin = iv.sub(support(r2, d).lo, support(r1, d).hi);
    if (!best || margin[0] > best.margin[0]) best = { d, margin };
    if (margin[0] > 0) return L.makeCheck({ ...base, value: margin, completeness: 'EXACT', verdict: 'PASSED', level: 'L2', separating_direction: d.map(x => x[0]),
      basis: 'разделяющее направление по опорным функциям: max по кольцу 1 < min по кольцу 2 (закрытая форма на полных вилках)' });
  }
  return L.makeCheck({ ...base, value: best.margin, completeness: 'UNRESOLVED', verdict: 'UNRESOLVED', level: 'L1', separating_direction: null,
    reason: `R-4: разделяющее направление не найдено (72 направления) — полная классификация соплоскостных коник отложена (R2, TB-4)${wtxt(r1, r2)}` });
}

// ---------------- разбор пары без общего каспа ----------------
function ringPairGeneral(r1, r2, ids = {}, opts = {}) {
  if (opts.coplanar) return ringPairCoplanar(r1, r2, ids, opts.coplanar);
  const id = ids.id || `RR:${r1.name}:${r2.name}`;
  const n1 = unitNormal(r1), n2 = unitNormal(r2);
  const s = iv.sqrt(vec.norm2(vec.cross(n1, n2)));   // синус угла между плоскостями, угол ∈ [0°, 90°]
  const angle = deg(iv.atan2(s, iv.abs(vec.dot(n1, n2))).v);
  // opts.thetaMinDeg — только для рабочих замеров обоснования θ_min; протокол использует объявленное значение.
  const tmin = opts.thetaMinDeg !== undefined ? opts.thetaMinDeg : THETA_MIN_DEG;
  const smin = tmin === THETA_MIN_DEG ? SIN_THETA_MIN : iv.sin(iv.deg2rad(iv.fromInput(tmin)));
  if (s[0] > smin[1]) return ringPairNonparallel(r1, r2, n1, n2, angle, ids, tmin);
  const near = s[1] < smin[0];
  return L.makeCheck({ id, req: 'R-5', objects: [r1.name, r2.name], quantity: 'plane_angle', value: angle, completeness: 'UNRESOLVED', verdict: 'UNRESOLVED', level: 'L1',
    case: near ? 'near-parallel' : 'relation-undetermined', theta_min_deg: tmin,
    reason: near ? `R-5: угол плоскостей меньше θ_min = ${tmin}° (вилка ${angle[0]}…${angle[1]}°); одна плоскость или параллельность построением не установлены`
      : `R-5: угол плоскостей не отделён от θ_min = ${tmin}° (вилка ${angle[0]}…${angle[1]}°)${wtxt(r1, r2)}` });
}

// Библиотечная точка (интерфейс § 7): K.ringRing(r1, r2, sharedCusp). sharedCusp = {A, T} (вилки) или null.
// Одна плоскость устанавливается только тождеством построения: у обоих колец одинаковый plane_class.
function ringRing(r1, r2, sharedCusp, opts = {}) {
  if (sharedCusp) return ringPairCusp(r1, r2, sharedCusp, opts.ids, opts.frame);
  const cop = r1.plane_class != null && r1.plane_class === r2.plane_class
    ? `одна плоскость по построению (plane_class ${r1.plane_class}): цепочка тождеств «θ кратно 180° и предыдущее звено зеркальное»` : null;
  return ringPairGeneral(r1, r2, opts.ids, { coplanar: cop });
}

// ---------------- G-6 ----------------
// Lk кольца с осевой окружностью продетого тора (окружность радиуса ½ вокруг A в плоскости ⊥ T) — по проколу её диска.
// Плоскость кольца содержит T, поэтому плоскость диска она пересекает по прямой A + sν. Кольцо встречает эту прямую
// в A (s = 0, трансверсально к диску: касательная вдоль T) и во второй точке s* = −2B/A (сумма корней; A на кольце).
// |s*| > ½ ⇒ прокол один ⇒ Lk = ±1; знак — касательная в A по T: в нижнем конце хорды вдоль ν она ∝ −(n × ν).
function ringAxialLk(ring, torus) {
  const id = `G6:${ring.name}:${torus.name}`;
  const base = { id, req: 'G-6', objects: [ring.name, torus.name], quantity: 'axial_disc_margin' };
  const cusp = { A: torus.A, T: torus.T, name: torus.name };
  const prem = cuspPremise(ring, cusp);
  const nu = halfplaneDir(ring, cusp);
  if (!prem || !nu) return L.makeCheck({ ...base, value: [-0.5, Number.MAX_VALUE], completeness: 'UNRESOLVED', verdict: 'UNRESOLVED', level: 'L1', lk: null, reason: 'G-6: точка каспа на кольце или полуплоскость не определены' });
  const q = lineSet(ring, torus.A, nu);
  const sStar = iv.div(iv.mul(TWO, iv.neg(q.B)), q.A);   // сумма корней −2B/A; корень s = 0 — сам касп
  const margin = iv.sub(iv.abs(sStar), HALF);
  const sg = iv.neg(vec.dot(vec.cross(vec.cross(ring.E1, ring.E2), nu), vec.normalize(torus.T)));
  const sign = sg[0] > 0 ? 1 : sg[1] < 0 ? -1 : null;
  const ext = { second_crossing: sStar, lk_orientation: 'кольцо — по росту t (E1 → E2); осевая окружность — против часовой стрелки вокруг T' };
  if (margin[0] > 0 && sStar[0] > 0 && sign !== null) return L.makeCheck({ ...base, value: margin, completeness: 'EXACT', verdict: 'PASSED', level: 'L2', lk: sign, ...ext,
    basis: 'один прокол диска осевой окружности — в каспе; вторая точка на прямой A + sν вне диска' });
  if (margin[1] < 0) return L.makeCheck({ ...base, value: margin, completeness: 'EXACT', verdict: 'UNRESOLVED', level: 'L1', lk: 0, ...ext,
    reason: 'G-6: вторая точка кольца в плоскости диска — внутри диска осевой окружности: Lk = 0, продевание не подтверждено' });
  return L.makeCheck({ ...base, value: margin, completeness: 'UNRESOLVED', verdict: 'UNRESOLVED', level: 'L1', lk: null, ...ext, reason: `G-6: вторая точка у края диска осевой окружности${wtxt(ring)}` });
}
// Граф продеваний: тор → кольца в его отверстии (по полю threads). A-15: не больше трёх колец в отверстии.
function threadingGraph(rings, tori) {
  const holes = {};
  for (const t of tori) holes[t.name] = [];
  for (const r of rings) for (const tn of r.threads || []) if (holes[tn]) holes[tn].push(r.name);
  const checks = [];
  for (const t of tori) {
    const n = holes[t.name].length;
    checks.push(L.makeCheck({ id: `A15:${t.name}`, req: 'G-6', objects: [t.name, ...holes[t.name]], quantity: 'rings_in_hole', value: [n, n], completeness: 'EXACT',
      verdict: n <= 3 ? 'PASSED' : 'FORBIDDEN', level: n <= 3 ? 'L2' : 'L1', rule: 'A-15', reason: n <= 3 ? null : `A-15: в отверстии ${t.name} ${n} колец (больше трёх)` }));
  }
  for (const r of rings) for (const tn of r.threads || []) { const t = tori.find(x => x.name === tn); if (t) checks.push(ringAxialLk(r, t)); }
  return { holes, edges: rings.flatMap(r => (r.threads || []).map(t => [r.name, t])), checks };
}

// ---------------- R-6 ----------------
// Три кольца и больше в одной точке вне каспа: попарно встречи R-2, вилки точек встречи пересекаются.
// Метка DEGENERATE MEETING; за событие защёлки не считается (Хранитель 01.11).
function degenerateMeetings(pairChecks) {
  const mt = pairChecks.filter(c => c.req === 'R-2' && c.meeting);
  const key = (a, b) => (a < b ? `${a}|${b}` : `${b}|${a}`);
  const by = new Map(mt.map(c => [key(...c.objects), c.meeting.at.map(x => x.point)]));
  const names = [...new Set(mt.flatMap(c => c.objects))].sort();
  const out = [];
  for (let i = 0; i < names.length; i++) for (let j = i + 1; j < names.length; j++) for (let k = j + 1; k < names.length; k++) {
    const [a, b, c] = [names[i], names[j], names[k]];
    const P = [by.get(key(a, b)), by.get(key(b, c)), by.get(key(a, c))];
    if (P.some(x => !x)) continue;
    let hit = null;
    for (const p of P[0]) for (const q of P[1]) for (const r of P[2]) if (boxOverlap(p, q) && boxOverlap(q, r) && boxOverlap(p, r)) hit = [p, q, r];
    if (!hit) continue;
    const diam = Math.max(...[0, 1, 2].map(t => Math.max(...hit.map(p => p[t][1])) - Math.min(...hit.map(p => p[t][0]))));
    out.push(L.makeCheck({ id: `R6:${a}:${b}:${c}`, req: 'R-6', objects: [a, b, c], quantity: 'meeting_spread', value: [0, iv.nextUp(diam)], completeness: 'UNRESOLVED', verdict: 'UNRESOLVED',
      level: 'L1', contact_class: 'DEGENERATE MEETING', meeting: { points: hit },
      reason: 'R-6: три кольца в одной точке вне каспа не исключены (попарные встречи R-2 в пересекающихся вилках); не событие защёлки' }));
  }
  return out;
}

// ---------------- все пары конфигурации ----------------
// conf — результат build (WP-1). frameOf(torus) — рамка тора для показа абсолютных углов полуплоскостей.
function ringChecks(conf, frameOf = null) {
  const { rings, tori } = conf;
  const pairs = [];
  for (let i = 0; i < rings.length; i++) for (let j = i + 1; j < rings.length; j++) {
    const r1 = rings[i], r2 = rings[j], ids = { id: `RR:${r1.name}:${r2.name}` };
    const shared = (r1.threads || []).filter(t => (r2.threads || []).includes(t));
    if (shared.length > 1) {
      pairs.push(L.makeCheck({ ...ids, req: 'R-1', objects: [r1.name, r2.name], quantity: 'halfplane_angle', value: [0, 180], completeness: 'UNRESOLVED', verdict: 'UNRESOLVED', level: 'L1',
        case: 'relation-undetermined', reason: `R-1: у колец два общих каспа (${shared.join(', ')}) — случай не предусмотрен` }));
      continue;
    }
    if (shared.length === 1) {
      const t = tori.find(x => x.name === shared[0]);
      let fr = null; try { fr = frameOf ? frameOf(t) : null; } catch (e) { fr = null; }
      pairs.push(ringPairCusp(r1, r2, { A: t.A, T: t.T, name: t.name }, ids, fr));
      continue;
    }
    pairs.push(ringRing(r1, r2, null, { ids }));
  }
  const g6 = threadingGraph(rings, tori);
  return { pairs, degenerate: degenerateMeetings(pairs), threading: { holes: g6.holes, edges: g6.edges }, threadingChecks: g6.checks };
}

module.exports = { ringRing, ringChecks, ringPairCusp, ringPairGeneral, ringPairCoplanar, threadingGraph, ringAxialLk, degenerateMeetings,
  halfplaneDir, lineSet, ringOnLine, THETA_MIN_DEG };
