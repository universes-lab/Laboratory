# Исполнитель КТ-1: переоценка 11 ключей вида contacts[0].<поле> по сохранённым протоколам — тот же смысл, что в rev4
# (путь 'contacts.0.<поле>'). Зафиксированный набор и его итог не меняются; это диагностика, а не результат набора.
import json, sys, zipfile, re
def load(zp):
    z = zipfile.ZipFile(zp)
    res = json.loads(z.read('work/d3_results.json'))
    exp = None
    protos = {n.split('/')[-1][:-5]: n for n in z.namelist() if n.startswith('work/protocols/') and n.endswith('.json')}
    return z, res, protos
def reeval(zp, expected):
    z, res, protos = load(zp)
    out = {}
    for r in res['results']:
        tid, st = r['id'], r['status']
        e = expected['tests'].get(tid, {}).get('expect', {})
        keys = [k for k in e if k.startswith('contacts[0].')]
        if not keys:
            out[tid] = (st, st, []); continue
        probs = [p for p in r.get('problems', []) if not re.match(r'contacts\[0\]\.\w+=undefined$', p)]
        notes = []
        if st == 'ERROR' or tid not in protos:
            out[tid] = (st, st, ['no protocol']); continue
        pr = json.loads(z.read(protos[tid]))
        c0 = (pr.get('contacts') or [None])[0] or {}
        for k in keys:
            f = k.split('.', 1)[1]
            v = c0.get(f)
            if v != e[k]: probs.append(f'{k}={v}')
            notes.append(f'{f}={v}')
        out[tid] = (st, 'PASS' if not probs else 'FAIL', probs or notes)
    return res, out
if __name__ == '__main__':
    expected = json.load(open(sys.argv[1]))
    for zp in sys.argv[2:]:
        res, out = reeval(zp, expected)
        offc = {s: sum(1 for v in out.values() if v[0] == s) for s in ('PASS', 'FAIL', 'ERROR')}
        cor = {s: sum(1 for v in out.values() if v[1] == s) for s in ('PASS', 'FAIL', 'ERROR')}
        print(zp.split('/')[-1], 'official', offc, 'reeval', cor)
        for t, (a, b, p) in out.items():
            if a != 'PASS' or b != 'PASS': print('  ', t, a, '->', b, p)
