#!/usr/bin/env python3
# Прогон зафиксированного набора Д-3 на мутанте ядра (план § 6.3, мутанты из истории Б0).
# Оболочка kt1_sandbox_run.py (ред. 3.2, sha256 1b8b07cd…5525) НЕ меняется: этот файл загружает её как модуль и подменяет
# только одно — сумму допустимого ядра: вместо замороженной — сумму мутанта из реестра. Песочница, пределы, упаковка — те же.
# Условия: метка прогона начинается с MUTANT-; сумма архива ядра совпадает с суммой мутанта в реестре и НЕ равна замороженной.
#   kt1_mutant_run.py --mutant-registry registry.json --mutant-id m4 <обычные аргументы kt1_sandbox_run.py, режим d3-run>
import hashlib, importlib.util, json, os, sys
HERE = os.path.dirname(os.path.realpath(__file__))
def take(opt):
    i = sys.argv.index(opt); v = sys.argv[i + 1]; del sys.argv[i:i + 2]; return v
reg = json.load(open(take('--mutant-registry'))); mid = take('--mutant-id')
kernel = sys.argv[sys.argv.index('--kernel') + 1]; label = sys.argv[sys.argv.index('--label') + 1]
if not label.startswith('MUTANT-'): sys.exit('ОТКАЗ: метка прогона мутанта должна начинаться с MUTANT-')
if sys.argv[sys.argv.index('--mode') + 1] != 'd3-run': sys.exit('ОТКАЗ: мутант — только режим d3-run')
m = [x for x in reg['mutants'] if x['id'] == mid]
if len(m) != 1: sys.exit(f'ОТКАЗ: мутанта {mid} нет в реестре')
ks = hashlib.sha256(open(kernel, 'rb').read()).hexdigest()
if ks != m[0]['sha256']: sys.exit(f'ОТКАЗ: сумма ядра {ks} не совпадает с реестром мутанта {mid}')
if ks == reg['frozen_kernel_sha256']: sys.exit('ОТКАЗ: это замороженное ядро, а не мутант')
spec = importlib.util.spec_from_file_location('kt1_sandbox_run', os.path.join(HERE, 'kt1_sandbox_run.py'))
R = importlib.util.module_from_spec(spec); spec.loader.exec_module(R)
R.FROZEN_KERNEL_SHA = ks                      # единственная подмена
R.main()
