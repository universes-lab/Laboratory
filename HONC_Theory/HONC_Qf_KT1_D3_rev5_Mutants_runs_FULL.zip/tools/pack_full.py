# Полный пакет прогонов rev5 на мутантах — Гроку и в архив: выходные архивы оболочки без изменений, реестр, сводка, сценарии.
import zipfile, sys, os
out, *items = sys.argv[1:]   # items: arcname=path
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as Z:
    for it in items:
        arc, p = it.split('=', 1)
        zi = zipfile.ZipInfo(arc, (2026, 11, 10, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
        Z.writestr(zi, open(p, 'rb').read())
print('ok', len(items))
