#!/bin/bash
W=/tmp/claude-0/-home-claude/6935880b-5ec3-55fe-acf8-346b2d2a291f/scratchpad/runs5
A=$W/HONC_Qf_KT1_D3_DeepSeek_2026-11-10_rev5.zip
for m in m1 m2a m2b m3v2 m4 m5 m8 m8b m12 m13 m14; do
  python3 -I $W/harness/kt1_mutant_run.py --mutant-registry $W/m8b/registry.json --mutant-id $m \
    --mode d3-run --label MUTANT-r5-$m --archive $A --sha dc200a00a149f9c00973e96eb683aec3400e43f9dcef0904083f4498094e0d29 \
    --entry d3/run.js --kernel $W/mk/HONC_Qf_KT1_Mutant_$m.zip > $W/run_$m.json 2> $W/run_$m.err
  rc=$?
  cp "$(python3 -I -c "import json;print(json.load(open('$W/run_$m.json'))['out_zip'])" 2>/dev/null)" $W/out/ 2>/dev/null
  echo "$m exit $rc $(date -u +%H:%M:%S)"
done
echo ALL_DONE
