# Пакет для DeepSeek: выходные архивы оболочки без work/protocols/A5.json (решение Интегратора 03.11); суммы удержанного — в HELD_A5.json.
import zipfile, hashlib, json, sys, os, re
out, *zips = sys.argv[1:]
held = []
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as Z:
    for zp in zips:
        base = os.path.basename(zp)[:-len('-out.zip')]
        z = zipfile.ZipFile(zp)
        for n in sorted(z.namelist()):
            if n.endswith('/'): continue
            data = z.read(n)
            if n == 'work/protocols/A5.json':
                held.append({'run': os.path.basename(zp), 'file': n, 'sha256': hashlib.sha256(data).hexdigest()}); continue
            zi = zipfile.ZipInfo(f'runs/{base}/{n}', (2026, 11, 10, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
            Z.writestr(zi, data)
    zi = zipfile.ZipInfo('HELD_A5.json', (2026, 11, 10, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
    Z.writestr(zi, json.dumps(held, ensure_ascii=False, indent=1) + '\n')
print(len(held), 'held')
