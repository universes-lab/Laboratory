// Исполнитель КТ-1: таблица «эталон набора ↔ вилка ядра» по сохранённым протоколам, функциями самого набора (lib/ops.js).
const fs = require('fs'), path = require('path');
const [opsPath, expPath, protoDir] = process.argv.slice(2);
const ops = require(opsPath); const E = JSON.parse(fs.readFileSync(expPath, 'utf8'));
const rows = [];
for (const [tid, spec] of Object.entries(E.tests)) {
  for (const nd of (spec.num || [])) {
    const pf = path.join(protoDir, tid + '.json');
    if (!fs.existsSync(pf)) { rows.push({ tid, id: nd.id, note: 'нет протокола (результат не K.run)' }); continue; }
    const pr = JSON.parse(fs.readFileSync(pf, 'utf8'));
    const ex = ops.extractNum(pr, pr, nd.extract);
    rows.push({ tid, id: nd.id, op: nd.op, v: nd.v, tol: nd.tol, half_open: nd.half_open, depends_on: nd.depends_on,
      fork: ex ? ex.fork : null, ctx: ex ? ex.ctx : null, entries: ex && ex.entries ? ex.entries : null, ok: ex ? ops.applyOp(nd, ex) : null });
  }
}
console.log(JSON.stringify(rows, null, 1));
