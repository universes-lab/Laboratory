#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cover master for «Хроники Промптера» / Chronicles of the Prompter /
Kronieken van de Prompter.

Palette sampled directly from Materials/Обложка2.jpg (the A.Tuin line):
cream stock, one vivid green ink, one ochre-gold ink, black type.

Metaphor: an occupied office that survives its occupant — an empty chair
facing a corridor of chat windows receding into the archive, with a single
luminous relay passing over the empty seat from the faintest, oldest window
to the nearest, living one.

Design grid is 600 x 900 CSS px (6 x 9 in); rendered at deviceScaleFactor 3
-> 1800 x 2700 px = 300 dpi.
"""
import json, math, random, pathlib, subprocess

OUT = pathlib.Path(__file__).parent
W, H = 600, 900
SCALE = 3

# ---- inks -------------------------------------------------------------
PAPER       = "#FFFFEB"
PAPER_EDGE  = "#F2EFD2"
GREEN       = "#0BA209"
GREEN_BRT   = "#32CE24"
GREEN_LUM   = "#7FE86B"
GREEN_DEEP  = "#06630A"
GOLD        = "#AC8013"
INK         = "#0A0A06"

rnd = random.Random(20261015)

# ---- geometry ---------------------------------------------------------
# The archive recedes along a diagonal: the living window is near, large and
# bleeds off the bottom edge; older windows cascade away to the upper right.
VP   = (556.0, 430.0)                      # vanishing point of the archive
NEAR = (106.0, 566.0, 584.0, 918.0)        # nearest / living window
N_FRAMES = 7
RATIO = 0.66


def lerp(a, b, t):
    return a + (b - a) * t


def frame(i):
    """Window plane i: 0 = nearest / living, N-1 = deepest / faded."""
    t = 1.0 - RATIO ** i
    x0 = lerp(NEAR[0], VP[0], t)
    y0 = lerp(NEAR[1], VP[1], t)
    x1 = lerp(NEAR[2], VP[0], t)
    y1 = lerp(NEAR[3], VP[1], t)
    return x0, y0, x1, y1


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


S = []          # svg fragments
def add(s):
    S.append(s)


# ---- defs -------------------------------------------------------------
add(f'''<defs>
  <filter id="grain" x="0" y="0" width="100%" height="100%">
    <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="3" seed="7"/>
    <feColorMatrix type="saturate" values="0"/>
    <feComponentTransfer><feFuncA type="linear" slope="0.14"/></feComponentTransfer>
  </filter>
  <filter id="soft"><feGaussianBlur stdDeviation="2.2"/></filter>
  <filter id="soft2"><feGaussianBlur stdDeviation="5.5"/></filter>
  <radialGradient id="screenglow" cx="0.52" cy="0.5" r="0.62">
    <stop offset="0"   stop-color="{GREEN_LUM}" stop-opacity="0.42"/>
    <stop offset="0.5" stop-color="{GREEN_BRT}" stop-opacity="0.16"/>
    <stop offset="1"   stop-color="{GREEN}"     stop-opacity="0"/>
  </radialGradient>
  <linearGradient id="vign" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0"    stop-color="{PAPER_EDGE}" stop-opacity="0.55"/>
    <stop offset="0.28" stop-color="{PAPER_EDGE}" stop-opacity="0"/>
    <stop offset="0.80" stop-color="{PAPER_EDGE}" stop-opacity="0"/>
    <stop offset="1"    stop-color="{PAPER_EDGE}" stop-opacity="0.50"/>
  </linearGradient>
  <clipPath id="plate"><rect x="0" y="300" width="600" height="600"/></clipPath>
</defs>''')

# ---- stock ------------------------------------------------------------
add(f'<rect width="{W}" height="{H}" fill="{PAPER}"/>')

# ---- tonal hatch field: the printed plate, densest lower-right ---------
add('<g clip-path="url(#plate)">')
y = 302.0
while y < 900:
    for seg in range(3):
        x0 = 150 + seg * 160 + rnd.uniform(-22, 22)
        x1 = x0 + rnd.uniform(110, 215)
        if x1 < 0 or x0 > 600:
            continue
        fx = (x0 + x1) * 0.5 / 600.0            # 0 left .. 1 right
        fy = (y - 300) / 600.0                  # 0 top  .. 1 bottom
        o = 0.012 + 0.090 * (fx ** 2.4) + 0.060 * (fy ** 2.4)
        o *= rnd.uniform(0.55, 1.25)
        if o < 0.016:
            continue
        add(f'<line x1="{x0:.1f}" y1="{y:.1f}" x2="{x1:.1f}" y2="{y:.1f}" '
            f'stroke="{GREEN}" stroke-width="0.9" opacity="{min(o,0.26):.3f}"/>')
    y += 2.6
add('</g>')

# ---- the corridor of windows -----------------------------------------
# deepest first so nearer frames overlay them
add('<g>')
for i in range(N_FRAMES - 1, -1, -1):
    x0, y0, x1, y1 = frame(i)
    d = i / (N_FRAMES - 1.0)                    # 0 near .. 1 deep
    op = 0.95 * (1 - d) ** 1.35 + 0.07
    col = GREEN_BRT if i == 0 else GREEN
    sw  = 1.9 if i == 0 else max(0.45, 1.5 - 0.26 * i)

    if i == 0:                                  # the living window glows
        add(f'<rect x="{x0-34:.1f}" y="{y0-34:.1f}" width="{x1-x0+68:.1f}" '
            f'height="{y1-y0+68:.1f}" fill="url(#screenglow)"/>')

    # each plane is opaque enough to occlude the ones behind it
    add(f'<rect x="{x0:.1f}" y="{y0:.1f}" width="{x1-x0:.1f}" height="{y1-y0:.1f}" '
        f'fill="{PAPER}" opacity="{0.70 - 0.22*d:.3f}"/>')
    if i == 0:                                  # the lit screen is a mass
        add(f'<rect x="{x0:.1f}" y="{y0:.1f}" width="{x1-x0:.1f}" '
            f'height="{y1-y0:.1f}" fill="{GREEN_LUM}" opacity="0.17"/>')
    add(f'<rect x="{x0:.1f}" y="{y0:.1f}" width="{x1-x0:.1f}" height="{y1-y0:.1f}" '
        f'fill="none" stroke="{col}" stroke-width="{sw:.2f}" opacity="{op:.3f}"/>')

    # title bar
    bar = max(3.0, 11.0 * (1 - d) + 2.5)
    add(f'<rect x="{x0:.1f}" y="{y0:.1f}" width="{x1-x0:.1f}" height="{bar:.1f}" '
        f'fill="{col}" opacity="{op*(0.34 if i else 0.88):.3f}"/>')
    for k in range(3):                          # window buttons
        cx = x0 + 6 + k * 6 * (1 - d * 0.5)
        if cx < x1 - 3 and bar > 5:
            add(f'<circle cx="{cx:.1f}" cy="{y0+bar/2:.1f}" r="{1.5*(1-d*0.45):.2f}" '
                f'fill="{PAPER}" opacity="{op*0.75:.3f}"/>')

    # lines of a transcript inside the pane
    ln, gap = y0 + bar + 7 * (1 - d) + 4, max(3.0, 9.0 * (1 - d) + 2.2)
    row = 0
    while ln < y1 - 4:
        wfrac = rnd.choice([0.86, 0.62, 0.74, 0.41, 0.93, 0.55])
        indent = 5 + (6 if row % 3 == 2 else 0)
        lx1 = x0 + indent
        lx2 = lx1 + (x1 - x0 - indent - 6) * wfrac
        o = op * (rnd.uniform(0.40, 0.80) if i == 0 else rnd.uniform(0.26, 0.60))
        add(f'<line x1="{lx1:.1f}" y1="{ln:.1f}" x2="{lx2:.1f}" y2="{ln:.1f}" '
            f'stroke="{col}" stroke-width="{max(0.5, 2.0*(1-d)):.2f}" opacity="{o:.3f}"/>')
        ln += gap
        row += 1
add('</g>')

# ---- traces of other participants: notes, nodes, a small diagram ------
# interfaces, marginal notes and relations - never faces, never robots
add(f'<g stroke="{GREEN}" fill="none" stroke-width="0.85" opacity="0.55">')
# a small relation diagram, high and to the left: the collaboration itself
add('<path d="M66 470 l0 -24 M66 446 l30 0 M96 446 l0 13 M96 459 l24 0 '
    'M96 446 l0 -13 l22 0" opacity="0.46"/>')
add('<circle cx="66" cy="470" r="2.3" opacity="0.70"/>')
add('<circle cx="120" cy="459" r="1.8" opacity="0.52"/>')
add('<circle cx="118" cy="433" r="1.8" opacity="0.40"/>')
# note brackets - somebody's margin, left in the archive
add('<path d="M64 556 l0 -18 l8 0 M106 556 l0 -18 l-8 0" opacity="0.42"/>')
add('<path d="M70 548 l30 0 M70 552 l20 0" opacity="0.30"/>')
add('<path d="M64 640 l0 -16 l8 0 M100 640 l0 -16 l-8 0" opacity="0.30"/>')
# two small closed panes, far back and nearly spent
add('<rect x="470" y="396" width="20" height="14" opacity="0.30"/>')
add('<rect x="496" y="396" width="20" height="14" opacity="0.18"/>')
add('</g>')
for (cx, cy, r, o) in [(372, 520, 1.7, .40), (448, 476, 1.4, .30),
                       (286, 598, 1.5, .34), (510, 452, 1.1, .22)]:
    add(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{GREEN}" opacity="{o}"/>')

# ---- numeral columns: the archive bleeding off the plate --------------
DIG = "0123456789"
add(f'<g font-family="DejaVu Sans Mono, monospace" fill="{GREEN}">')
for col in range(14):
    cx = 406 + col * 13.9 + rnd.uniform(-3, 3)
    if cx > 606:
        continue
    fs = rnd.choice([6.0, 6.8, 7.6])
    top = rnd.uniform(640, 790)
    base_o = 0.09 + 0.34 * ((cx - 396) / 210.0) ** 1.2
    yy = top
    while yy < 912:
        o = base_o * rnd.uniform(0.35, 1.3)
        if o > 0.07:
            add(f'<text x="{cx:.1f}" y="{yy:.1f}" font-size="{fs:.1f}" '
                f'opacity="{min(o,0.52):.3f}">{rnd.choice(DIG)}</text>')
        yy += fs * 1.28
# a thin colony at far left, lower edge
for col in range(4):
    cx = 34 + col * 11
    yy = 822 + rnd.uniform(0, 14)
    while yy < 906:
        add(f'<text x="{cx:.1f}" y="{yy:.1f}" font-size="6.2" '
            f'opacity="{rnd.uniform(0.07,0.22):.3f}">{rnd.choice(DIG)}</text>')
        yy += 8.0
add('</g>')

# ---- the chair: empty, seen from behind, facing the living window -----
# a plain institutional chair in profile, facing the living window
# seat plane: near edge A-B, far edge D-C (depth offset up and to the right)
A, B = (140.0, 806.0), (292.0, 806.0)
D, C = (176.0, 782.0), (328.0, 782.0)
seat_d = ("M%g %g L%g %g L%g %g L%g %g Z"
          % (A[0], A[1], B[0], B[1], C[0], C[1], D[0], D[1]))
SLAB = "M140 806 L140 814 L292 814 L328 790 L328 782 L292 806 Z"
BACK = "M140 806 L176 782 L182 556 L146 580 Z"

# light pooling on the floor under the chair, thrown by the living window
add(f'<ellipse cx="250" cy="898" rx="176" ry="30" fill="{GREEN_BRT}" '
    f'opacity="0.12" filter="url(#soft2)"/>')

add(f'<defs><clipPath id="seatclip"><path d="{seat_d}"/></clipPath></defs>')
add(f'<path d="{BACK}" fill="{PAPER}" opacity="0.72"/>')
add(f'<path d="{seat_d}" fill="{PAPER}" opacity="0.88"/>')
add(f'<path d="{seat_d}" fill="{GREEN_BRT}" opacity="0.10"/>')
add(f'<path d="{SLAB}" fill="{PAPER}" opacity="0.92"/>')
yy = 780.0
while yy < 808:
    add(f'<line x1="134" y1="{yy:.1f}" x2="336" y2="{yy:.1f}" stroke="{GREEN}" '
        f'stroke-width="0.8" opacity="{0.34 - 0.004*(yy-780):.3f}" '
        f'clip-path="url(#seatclip)"/>')
    yy += 2.4

CH = (f'stroke="{INK}" fill="none" stroke-width="2.9" stroke-linecap="round" '
      f'stroke-linejoin="round"')
add(f'<g {CH}>')
add('<path d="M140 806 L146 580"/>')                       # back upright, near
add('<path d="M146 580 L182 556"/>')                       # crest rail
add(f'<path d="{SLAB}"/>')                                 # seat slab
add('<path d="M176 782 L328 782"/>')                       # seat, far edge
add('<path d="M140 814 L130 930"/>')                       # legs, near pair
add('<path d="M292 814 L302 930"/>')
add('<path d="M135 872 L296 878"/>')                       # stretcher, near
add('</g>')
# the far side of the chair: same lines, thinner, so the depth reads
add(f'<g stroke="{INK}" fill="none" stroke-width="1.6" opacity="0.74" '
    f'stroke-linecap="round" stroke-linejoin="round">')
add('<path d="M176 782 L182 556"/>')                       # back upright, far
add('<path d="M142 718 L178 694"/>')                       # lower back rail
add('<path d="M176 782 L166 898"/>')                       # legs, far pair
add('<path d="M328 782 L338 898"/>')
add('<path d="M171 848 L332 854"/>')                       # stretcher, far
add('<path d="M133 880 L169 856" opacity="0.7"/>')         # side stretchers
add('<path d="M298 880 L334 856" opacity="0.7"/>')
add('</g>')

# green rim-light where the window reaches round the chair
add(f'<g stroke="{GREEN_BRT}" fill="none" stroke-width="1.5" opacity="0.72" '
    f'stroke-linecap="round">')
add('<path d="M176 782 L182 556"/>')
add('<path d="M328 782 L338 898"/>')
add('<path d="M176 782 L328 782"/>')
add('</g>')

# ---- the relay: one luminous thread over the empty seat ---------------
# from the faintest window deep in the archive, across the empty chair,
# into the window that is still lit
R_OLD = "M 538 452 C 468 500, 408 486, 334 512 C 256 540, 206 546, 164 568"
R_NEW = "M 164 568 C 250 596, 272 690, 402 742"
for d_ in (R_OLD, R_NEW):
    add(f'<path d="{d_}" fill="none" stroke="{GREEN_LUM}" stroke-width="8" '
        f'opacity="0.22" filter="url(#soft)"/>')
add(f'<path d="{R_OLD}" fill="none" stroke="{GREEN_BRT}" stroke-width="1.3" '
    f'opacity="0.68" stroke-linecap="round"/>')
add(f'<path d="{R_NEW}" fill="none" stroke="{GREEN_BRT}" stroke-width="2.2" '
    f'stroke-linecap="round"/>')
add(f'<circle cx="538" cy="452" r="2.8" fill="none" stroke="{GREEN}" '
    f'stroke-width="1" opacity="0.70"/>')
add(f'<circle cx="164" cy="568" r="7" fill="{GREEN_LUM}" opacity="0.28" '
    f'filter="url(#soft)"/>')
add(f'<circle cx="164" cy="568" r="2.5" fill="{GREEN_BRT}" opacity="0.90"/>')
add(f'<circle cx="402" cy="742" r="12" fill="{GREEN_LUM}" opacity="0.34" '
    f'filter="url(#soft)"/>')
add(f'<circle cx="402" cy="742" r="3.8" fill="{GREEN_BRT}"/>')

# ---- stock edge ------------------------------------------------------
add(f'<rect width="{W}" height="{H}" fill="url(#vign)"/>')
add(f'<rect width="{W}" height="{H}" filter="url(#grain)" opacity="0.55" '
    f'style="mix-blend-mode:multiply"/>')

ILLUS = ('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" '
         'viewBox="0 0 %d %d">%s</svg>' % (W, H, W, H, "".join(S)))
(OUT / "cover_illustration.svg").write_text(ILLUS, encoding="utf-8")

# ---- emblem motif: the four departments, very quiet -------------------
def shield(x, y, s):
    return (f'<path d="M{x} {y} h{s} v{s*0.52:.1f} q0 {s*0.40:.1f} {-s/2:.1f} {s*0.48:.1f} '
            f'q{-s/2:.1f} {-s*0.08:.1f} {-s/2:.1f} {-s*0.48:.1f} Z"/>')

EMBLEM = (f'<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">'
          f'<g fill="none" stroke="{GREEN}" stroke-width="0.9" opacity="0.72">'
          + shield(1.5, 1.5, 12) + shield(16.5, 1.5, 12)
          + shield(1.5, 16.5, 12) + shield(16.5, 16.5, 12)
          + '</g></svg>')

# ---- typography ------------------------------------------------------
VARIANTS = {
    "MASTER": None,
    "RU": dict(t1="Хроники", t2="Промптера",
               a1="Промптер — авторский голос ИИ", a2="А.Туин — куратор"),
    "EN": dict(t1="Chronicles", t2="of the Prompter",
               a1="Prompter — authorial AI voice", a2="A.Tuin — curator"),
    "NL": dict(t1="Kronieken", t2="van de Prompter",
               a1="Prompter — auteursstem van de AI", a2="A.Tuin — curator"),
}

HEAD = "AI-COLLAB · ARCHIVE · 2025—2026"
TERMS = ["ZOV · ZOR · METSUKE", "SUCCESSION · DRIFT · HANDOFF", "PROVENANCE · ARCHIVE"]

PAGE = """<!doctype html><meta charset="utf-8"><style>
*{{margin:0;padding:0;box-sizing:border-box}}
html,body{{width:{W}px;height:{H}px;overflow:hidden;background:{PAPER}}}
.stage{{position:relative;width:{W}px;height:{H}px}}
.art{{position:absolute;inset:0}}
.type{{position:absolute;left:54px;top:50px;width:510px}}
.head{{font:600 8.4px/1 'Inter',sans-serif;letter-spacing:2.45px;color:{INK};
      opacity:.78;text-transform:uppercase}}
.rule{{width:84px;height:1px;background:{INK};opacity:.55;margin:13px 0 0}}
.title{{font-family:'Lora',serif;font-weight:700;color:{GOLD};
       line-height:1.015;margin-top:26px;letter-spacing:-0.012em}}
.title span{{display:block;white-space:nowrap}}
.grule{{width:132px;height:1.6px;background:{GREEN};margin:24px 0 0;opacity:.92}}
.attr{{margin-top:19px;color:{INK}}}
.attr .a1{{font:600 11.4px/1.52 'Inter',sans-serif}}
.attr .a2{{font:400 11.4px/1.52 'Inter',sans-serif;opacity:.80}}
.terms{{margin-top:27px;font:700 8.1px/2.05 'Inter',sans-serif;letter-spacing:2.25px;
       color:{INK};opacity:.62;text-transform:uppercase}}
.emb{{position:absolute;left:54px;top:838px;opacity:.9}}
</style>
<div class="stage">
  <div class="art">{ART}</div>
  {TYPE}
</div>
<script>
(function(){{
  var t=document.querySelector('.title'); if(!t) return;
  var max=510, fs={FS};
  t.style.fontSize=fs+'px';
  function widest(){{var w=0;t.querySelectorAll('span').forEach(function(s){{
      w=Math.max(w, s.scrollWidth);}});return w;}}
  var guard=0;
  while(widest()>max && fs>28 && guard++<200){{fs-=0.5;t.style.fontSize=fs+'px';}}
  document.title='fit:'+fs;
}})();
</script>"""

TYPE_TMPL = """<div class="type">
    <div class="head">{HEAD}</div>
    <div class="rule"></div>
    <div class="title"><span>{T1}</span><span>{T2}</span></div>
    <div class="grule"></div>
    <div class="attr"><div class="a1">{A1}</div><div class="a2">{A2}</div></div>
    <div class="terms">{TERMS}</div>
  </div>
  <div class="emb">{EMBLEM}</div>"""


def build(name, v):
    if v is None:
        typ = ""
    else:
        typ = TYPE_TMPL.format(HEAD=esc(HEAD), T1=esc(v["t1"]), T2=esc(v["t2"]),
                               A1=esc(v["a1"]), A2=esc(v["a2"]),
                               TERMS="<br>".join(esc(t) for t in TERMS),
                               EMBLEM=EMBLEM)
    html = PAGE.format(W=W, H=H, PAPER=PAPER, INK=INK, GOLD=GOLD, GREEN=GREEN,
                       ART=ILLUS, TYPE=typ, FS=72)
    p = OUT / f"src_cover_{name}.html"
    p.write_text(html, encoding="utf-8")
    return p


pages = {k: build(k, v) for k, v in VARIANTS.items()}

# ---- render ----------------------------------------------------------
from playwright.sync_api import sync_playwright

STEM = "Chronicles_of_the_Prompter_COVER"
made = []
with sync_playwright() as p:
    b = p.chromium.launch()
    for name, path in pages.items():
        pg = b.new_page(viewport={"width": W, "height": H}, device_scale_factor=SCALE)
        pg.goto(path.as_uri())
        pg.wait_for_timeout(700)
        fit = pg.title()
        png = OUT / (f"{STEM}_MASTER_no-text.png" if name == "MASTER" else f"{STEM}_{name}.png")
        pg.screenshot(path=str(png))
        made.append((name, png, fit))
        pg.close()
    b.close()

from PIL import Image
for name, png, fit in made:
    im = Image.open(png).convert("RGB")
    jpg = png.with_suffix(".jpg")
    im.save(jpg, "JPEG", quality=94, subsampling=0, dpi=(300, 300))
    print(f"{name:7} {im.size[0]}x{im.size[1]}  {png.name}  +jpg   {fit}")
